import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

const db = {
  init: async (table, obj) => {
    let auxSchema = [];
    for (const [key, value] of Object.entries(obj.schema)) {
      let aux_type = value.type;
      if (value.type == "SELECT") {
        aux_type = "STRING";
      }
      auxSchema.push(`${key} ${aux_type} ${value.extra || ""} ${value.null ? "" : "NOT NULL"}`);
    }
    const str = `
          CREATE TABLE IF NOT EXISTS ${table}
          (${auxSchema.join(",")})
        `;
    const data = await $fetch("/api/dbservices", {
      method: "PUT",
      body: JSON.stringify({ str })
    });
    console.log("return data: ", data);
    return data;
  },
  get: async (sql) => {
    const data = await $fetch("/api/dbservices?sql=" + sql);
    console.log("getTodos data: ", data);
    return data;
  },
  insert: async (obj) => {
    const data = await $fetch("/api/dbservices", {
      method: "POST",
      body: JSON.stringify({ table: obj.table, data: obj.data })
    });
    console.log("data:", data);
    return data;
  },
  update: async (obj) => {
    const data = await $fetch("/api/dbservices", {
      method: "PATCH",
      body: JSON.stringify({ table: obj.table, data: obj.data, where: obj.where })
    });
    return data;
  },
  delete: async (obj) => {
    const data = await $fetch("/api/dbservices", {
      method: "DELETE",
      body: JSON.stringify({ table: obj.table, where: obj.where })
    });
    return data;
  }
};

function generateToken(n) {
  var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var token = "";
  for (var i = 0; i < n; i++) {
    token += chars[Math.floor(Math.random() * chars.length)];
  }
  return token;
}
const login_do = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const type = body.type;
  const username = body.username;
  const password = body.password;
  console.log(`select * from ${type} where username like '${username}' and password like '${password}' `);
  const data = await db.get(`select * from ${type} where username like '${username}' and password like '${password}' `);
  console.log("db---------->", data);
  if (data.length > 0) {
    const userObj = {
      ...data[0],
      type,
      token: generateToken(360)
    };
    console.log("userObj:", userObj);
    return userObj;
  } else {
    return null;
  }
});

export { login_do as default };
//# sourceMappingURL=login_do.mjs.map
