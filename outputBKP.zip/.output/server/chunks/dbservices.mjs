import { d as defineEventHandler, r as readBody, g as getQuery } from './nitro/node-server.mjs';
import Database from 'better-sqlite3';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

const dbservices = defineEventHandler(async (event) => {
  const db = new Database("database.db");
  let req = null;
  const insertData = (table, newBrandData) => {
    const keyValues = [];
    const keyValues2 = [];
    const params = [];
    Object.keys(newBrandData).forEach((e) => {
      keyValues.push(`${e}`);
      keyValues2.push(`?`);
      params.push(newBrandData[e]);
    });
    console.log("keyValues:", keyValues);
    console.log("params:", params);
    console.log(`INSERT INTO ${table} (${keyValues}) VALUES (${keyValues2})`);
    const stmt = db.prepare(`INSERT INTO ${table} (${keyValues}) VALUES (${keyValues2})`);
    const insertions = stmt.run(params);
    return insertions;
  };
  const updateData = (table, newBrandData, where_) => {
    const keyValues = [];
    const params = [];
    Object.keys(newBrandData).forEach((e) => {
      keyValues.push(`${e} = ?`);
      params.push(newBrandData[e]);
    });
    console.log("keyValues:", keyValues);
    console.log("params:", params);
    console.log(`UPDATE ${table} SET ${keyValues} WHERE ${where_}`);
    const stmt = db.prepare(`UPDATE ${table} SET ${keyValues} WHERE ${where_}`);
    const updates = stmt.run(params);
    return updates;
  };
  const deleteData = (table, where_) => {
    const stmt = db.prepare(`DELETE FROM ${table} WHERE ${where_}`);
    const delete_ = stmt.run();
    return delete_;
  };
  const execSql = (sql) => {
    const ret2 = db.exec(sql);
    return ret2;
  };
  const getData = (sql) => {
    const selectData = db.prepare(sql).all();
    console.log("selectData:", selectData);
    return selectData;
  };
  if (event.node.req.method === "PUT") {
    req = await readBody(event);
    console.log("SCHEMA------**---------");
    console.log(req.str);
    execSql(req.str);
    return "retorno:" + req;
  }
  if (event.node.req.method === "GET") {
    req = getQuery(event);
    console.log("req.sql:", req.sql.trim());
    const ret2 = getData(req.sql.trim());
    return ret2;
  }
  if (event.node.req.method === "POST") {
    req = await readBody(event);
    const ret2 = insertData(req.table, req.data);
    console.log("ret:", ret2);
    return "retorno:" + ret2;
  }
  if (event.node.req.method === "PATCH") {
    req = await readBody(event);
    updateData(req.table, req.data, req.where);
    return "retorno:" + req;
  }
  if (event.node.req.method === "DELETE") {
    req = await readBody(event);
    deleteData(req.table, req.where);
    return "retorno:" + req;
  }
});

export { dbservices as default };
//# sourceMappingURL=dbservices.mjs.map
