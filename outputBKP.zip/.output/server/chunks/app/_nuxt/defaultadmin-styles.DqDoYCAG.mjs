import { p as primeflex } from './download-styles-1.mjs-Bj68gDig.mjs';
import { d as defaultadmin_vue_vue_type_style_index_0_scoped_6e6d68f4_lang } from './defaultadmin-styles-2.mjs-yjKXO7g2.mjs';

const defaultadminStyles_DqDoYCAG = [primeflex, defaultadmin_vue_vue_type_style_index_0_scoped_6e6d68f4_lang];

export { defaultadminStyles_DqDoYCAG as default };
//# sourceMappingURL=defaultadmin-styles.DqDoYCAG.mjs.map
