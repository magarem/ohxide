import { x as primebus } from '../server.mjs';

var OverlayEventBus = primebus();

export { OverlayEventBus as O };
//# sourceMappingURL=overlayeventbus.esm-BmXQsB7e.mjs.map
