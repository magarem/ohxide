import { _ as __nuxt_component_0 } from './Magacrud-DdUgYriv.mjs';
import { u as useRouter, b as useCookie, e as useAuthStore, s as storeToRefs } from '../server.mjs';
import { mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';
import './toast.esm-Di1eVOG7.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import './index.esm-Bq_5RDja.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dg68Fgcm.mjs';
import './index.esm-20913B80.mjs';
import './index.esm-iPGlXaLT.mjs';
import './datatable.esm-CbTG6Zy3.mjs';
import './index.esm-Dp-7Az-D.mjs';
import './paginator.esm-DB7J9-Tz.mjs';
import './index.esm-BZBBIaQ0.mjs';
import './dropdown.esm-BpN7Uydi.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-jRTkyN61.mjs';
import './overlayeventbus.esm-BmXQsB7e.mjs';
import './virtualscroller.esm-BLdBM0im.mjs';
import './inputnumber.esm-4TYMEebL.mjs';
import './button.esm-sSHPs3W5.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './index.esm-CpjI3C5Z.mjs';
import './index.esm-CB9yXpcc.mjs';
import './inputtext.esm-CY1MGtqk.mjs';
import './index.esm-UuuQr2TF.mjs';
import './index.esm-uE8Xa7qf.mjs';
import './index.esm-DPIQtQ_I.mjs';
import './checkbox.esm-BRtMjhaa.mjs';
import './radiobutton.esm-Dy5m1Rk5.mjs';
import './index.esm-CaP80Tc5.mjs';
import './index.esm-BOTt2uTe.mjs';
import './column.esm-D_9bkwGs.mjs';
import './dialog.esm-DF58ccWn.mjs';
import './textarea.esm-wrpH6U21.mjs';
import './multiselect.esm-Bv8rNR12.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "index_res",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    if (!authenticated.value) {
      router.push("/login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-5" }, _attrs))}><div class="flex">`);
      if (unref(dataUser).status == "root") {
        _push(`<div class="p-1" style="${ssrRenderStyle({ "width": "520px", "max-height": "500px", "margin-right": "20px", "overflow": "auto" })}">`);
        _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/users.json" }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-1" style="${ssrRenderStyle({ "width": "520px", "max-height": "500px", "margin-right": "20px", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/clients.json" }, null, _parent));
      _push(`</div><div class="p-1" style="${ssrRenderStyle({ "width": "500px", "height": "500px", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/reports.json" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index_res.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index_res-DikO0xt2.mjs.map
