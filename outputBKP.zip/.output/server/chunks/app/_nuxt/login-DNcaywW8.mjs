import { useSSRContext, defineComponent, ref, mergeProps, unref } from 'vue';
import { e as useAuthStore, s as storeToRefs, u as useRouter, j as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrInterpolate } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-BTo1DBng.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    useAuthStore();
    storeToRefs(useAuthStore());
    let msg = ref("");
    const user = ref({
      type: "clients",
      username: "",
      password: ""
    });
    useRouter();
    useRoute();
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "body" }, _attrs))} data-v-e75ee519><div id="container1" data-v-e75ee519><div class="flex" data-v-e75ee519><img${ssrRenderAttr("src", _imports_0)} style="${ssrRenderStyle({ "width": "150px", "margin-right": "30px" })}" data-v-e75ee519><h1 style="${ssrRenderStyle({ "margin-top": "39px", "margin-left": "15px" })}" data-v-e75ee519>WReport</h1></div><div id="login-container" data-v-e75ee519><form data-v-e75ee519><input${ssrRenderAttr("value", unref(user).type)} type="hidden" class="input" placeholder="tipo" name="uname" autocomplete="off" data-v-e75ee519><input${ssrRenderAttr("value", unref(user).username)} type="text" class="input" placeholder="Usu\xE1rio" name="uname" autocomplete="off" required data-v-e75ee519><input${ssrRenderAttr("value", unref(user).password)} type="password" class="input" placeholder="Senha" name="psw" autocomplete="off" required data-v-e75ee519><button data-v-e75ee519>Entrar</button><div class="msg mt-3" data-v-e75ee519>${ssrInterpolate(unref(msg))}</div></form></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const login = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e75ee519"]]);

export { login as default };
//# sourceMappingURL=login-DNcaywW8.mjs.map
