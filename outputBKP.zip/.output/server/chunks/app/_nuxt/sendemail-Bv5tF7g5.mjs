import script from './toast.esm-BKV23R5p.mjs';
import script$1 from './confirmdialog.esm-B3fnkt7x.mjs';
import script$2 from './card.esm-DGg-uDiM.mjs';
import script$3 from './multiselect.esm-B65gFVu2.mjs';
import script$4 from './button.esm-BF_RjID0.mjs';
import { ref, withAsyncContext, withCtx, unref, createVNode, withDirectives, vModelText, useSSRContext } from 'vue';
import { u as useRouter, e as useCookie, f as useAuthStore, s as storeToRefs, d as db, g as useToast } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-B0Mha2q3.mjs';
import './index.esm-D94sOlgY.mjs';
import './baseicon.esm-Cy2FoSiq.mjs';
import './index.esm-CIJ2jzyK.mjs';
import './index.esm-Do8-MTsn.mjs';
import './index.esm-CubdsAVt.mjs';
import './dialog.esm-CEP5tmQi.mjs';
import './checkbox.esm-D6d19euv.mjs';
import './index.esm-RNZSX7pe.mjs';
import './index.esm-CdM9LvbI.mjs';
import './index.esm-By_6gZSM.mjs';
import './overlayeventbus.esm-BcDW6nGW.mjs';
import './virtualscroller.esm-D3fYAFU7.mjs';
import './badge.esm-xka9JVxi.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "sendemail",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    useCookie("dataUser");
    useAuthStore();
    storeToRefs(useAuthStore());
    ref();
    ref(false);
    ref(false);
    const clients = ref(([__temp, __restore] = withAsyncContext(() => db.get("select * from clients")), __temp = await __temp, __restore(), __temp));
    const toast = useToast();
    const ret = ([__temp, __restore] = withAsyncContext(() => db.get("select * from config where id like 'config_emailsend'")), __temp = await __temp, __restore(), __temp);
    const emailSendData = JSON.parse(ret[0].data);
    console.log("emailSendData:", emailSendData);
    const sendEmailForm = ref({
      year: (/* @__PURE__ */ new Date()).getFullYear(),
      month: (/* @__PURE__ */ new Date()).getMonth() + 1,
      subject: emailSendData.subject,
      message: emailSendData.body,
      linktext: emailSendData.linkTxt,
      clients: []
    });
    const sendMails = async () => {
      console.log("sendmails");
      if (sendEmailForm.value.clients.length > 0) {
        const ret2 = await $fetch("/api/sendemail", {
          method: "POST",
          body: sendEmailForm.value
        });
        if (ret2) {
          toast.add({ severity: "secondary", summary: "E-mails", detail: ret2 || "".join(", "), life: 3e3 });
        }
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Toast = script;
      const _component_ConfirmDialog = script$1;
      const _component_Card = script$2;
      const _component_MultiSelect = script$3;
      const _component_Button = script$4;
      _push(`<!--[--><h3>Enviar emails</h3>`);
      _push(ssrRenderComponent(_component_Toast, null, null, _parent));
      _push(ssrRenderComponent(_component_ConfirmDialog, null, null, _parent));
      _push(ssrRenderComponent(_component_Card, {
        style: { "width": "31rem", "overflow": "hidden" },
        class: "mt-0"
      }, {
        content: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="formgrid grid"${_scopeId}><div class="field col-12 md:col-3"${_scopeId}><label for="firstname6"${_scopeId}>Ano</label><input id="firstname6"${ssrRenderAttr("value", unref(sendEmailForm).year)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId}></div><div class="field col-12 md:col-3"${_scopeId}><label for="lastname6"${_scopeId}>M\xEAs</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).month)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId}></div><div class="field col-12 md:col-6"${_scopeId}><label for="lastname6"${_scopeId}>Assunto</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).subject)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId}></div><div class="field col-12"${_scopeId}><label for="address"${_scopeId}>Mensagem</label><textarea id="address" type="text" rows="4" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId}>${ssrInterpolate(unref(sendEmailForm).message)}</textarea></div><div class="field col-12"${_scopeId}><label for="lastname6"${_scopeId}>Texto do link</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).linktext)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId}></div><div class="field col-12 md:col-3"${_scopeId}><label for="state"${_scopeId}>Clientes</label>`);
            _push2(ssrRenderComponent(_component_MultiSelect, {
              modelValue: unref(sendEmailForm).clients,
              "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
              display: "chip",
              options: unref(clients),
              optionLabel: "name",
              optionValue: "id",
              placeholder: "Selecione os clientes",
              maxSelectedLabels: 3,
              class: "w-full md:w-28rem"
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "formgrid grid" }, [
                createVNode("div", { class: "field col-12 md:col-3" }, [
                  createVNode("label", { for: "firstname6" }, "Ano"),
                  withDirectives(createVNode("input", {
                    id: "firstname6",
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).year = $event,
                    type: "text",
                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(sendEmailForm).year]
                  ])
                ]),
                createVNode("div", { class: "field col-12 md:col-3" }, [
                  createVNode("label", { for: "lastname6" }, "M\xEAs"),
                  withDirectives(createVNode("input", {
                    id: "lastname6",
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).month = $event,
                    type: "text",
                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(sendEmailForm).month]
                  ])
                ]),
                createVNode("div", { class: "field col-12 md:col-6" }, [
                  createVNode("label", { for: "lastname6" }, "Assunto"),
                  withDirectives(createVNode("input", {
                    id: "lastname6",
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).subject = $event,
                    type: "text",
                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(sendEmailForm).subject]
                  ])
                ]),
                createVNode("div", { class: "field col-12" }, [
                  createVNode("label", { for: "address" }, "Mensagem"),
                  withDirectives(createVNode("textarea", {
                    id: "address",
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).message = $event,
                    type: "text",
                    rows: "4",
                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(sendEmailForm).message]
                  ])
                ]),
                createVNode("div", { class: "field col-12" }, [
                  createVNode("label", { for: "lastname6" }, "Texto do link"),
                  withDirectives(createVNode("input", {
                    id: "lastname6",
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).linktext = $event,
                    type: "text",
                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(sendEmailForm).linktext]
                  ])
                ]),
                createVNode("div", { class: "field col-12 md:col-3" }, [
                  createVNode("label", { for: "state" }, "Clientes"),
                  createVNode(_component_MultiSelect, {
                    modelValue: unref(sendEmailForm).clients,
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                    display: "chip",
                    options: unref(clients),
                    optionLabel: "name",
                    optionValue: "id",
                    placeholder: "Selecione os clientes",
                    maxSelectedLabels: 3,
                    class: "w-full md:w-28rem"
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                ])
              ])
            ];
          }
        }),
        footer: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex gap-3 mt-1"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Button, {
              onClick: sendMails,
              disabled: !unref(sendEmailForm).clients.length,
              label: "Enviar",
              class: "w-full"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex gap-3 mt-1" }, [
                createVNode(_component_Button, {
                  onClick: sendMails,
                  disabled: !unref(sendEmailForm).clients.length,
                  label: "Enviar",
                  class: "w-full"
                }, null, 8, ["disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/sendemail.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sendemail-Bv5tF7g5.mjs.map
