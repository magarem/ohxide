import { p as primeflex } from './download-styles-1.mjs-Bj68gDig.mjs';

const downloadStyles_C0SNoOW_ = [primeflex];

export { downloadStyles_C0SNoOW_ as default };
//# sourceMappingURL=download-styles.C0SNoOW_.mjs.map
