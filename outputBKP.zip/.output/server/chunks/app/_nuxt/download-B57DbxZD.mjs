import script from './progressspinner.esm-CfCiaDRL.mjs';
import script$1 from './button.esm-BF_RjID0.mjs';
import { ref, withAsyncContext, resolveComponent, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { u as useRouter, f as useAuthStore, s as storeToRefs, e as useCookie, k as useRoute, d as db } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrInterpolate, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-BTo1DBng.mjs';
import './basecomponent.esm-B0Mha2q3.mjs';
import './badge.esm-xka9JVxi.mjs';
import './index.esm-By_6gZSM.mjs';
import './baseicon.esm-Cy2FoSiq.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "download",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    ref("products");
    useRouter();
    const { logUserOut, authenticateUser } = useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    useCookie("dataUser");
    let data = ref();
    const route = useRoute();
    const year = route.query.year;
    const month = route.query.month;
    const client = route.query.client;
    const userData = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from clients where id like '${client}'`)), __temp = await __temp, __restore(), __temp);
    const login = async () => {
      console.log({
        type: "clients",
        username: userData[0].username,
        password: userData[0].password.toString()
      });
      const r = await authenticateUser({
        type: "clients",
        username: userData[0].username,
        password: userData[0].password.toString()
      });
      console.log("r:", r);
      console.log("authenticated:", authenticated.value);
      if (authenticated.value) {
        console.log("Usuario identificado!!");
        download();
      } else {
        console.log("erro login!!");
      }
    };
    const download = async () => {
      const sql = `
  select 
      COUNT(reports.id), 
      reports.year, 
      reports.month, 
      GROUP_CONCAT(reports.name) as nome, 
      GROUP_CONCAT(reports.file) as files, 
      GROUP_CONCAT(products.name) as tags 
  from 
      reports, 
      products, 
      clients 
  where 
      reports.tag = products.id AND 
      instr(clients.tags, reports.tag) > 0 AND
      clients.id like '${userData[0].id}'
  GROUP BY 
      reports.year, 
      reports.month 
  order by 
      year DESC, 
      month DESC 
`;
      let data_ = await $fetch("/api/dbservices?sql=" + sql.replace(/\s+/g, " ").trim());
      data_ = data_.filter((x) => x.year == year && x.month == month);
      data.value = await $fetch(`/api/shell?year=${year}&month=${month}&client=${JSON.stringify(userData[0])}&files=${data_[0].files}`);
    };
    login();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ProgressSpinner = script;
      const _component_router_link = resolveComponent("router-link");
      const _component_Button = script$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "text-center",
        style: { "margin-top": "80px" }
      }, _attrs))}><img${ssrRenderAttr("src", _imports_0)} style="${ssrRenderStyle({ "width": "200px" })}"><h3>Download relat\xF3rio ${ssrInterpolate(unref(month))}/${ssrInterpolate(unref(year))}</h3>`);
      if (!unref(data)) {
        _push(ssrRenderComponent(_component_ProgressSpinner, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(data)) {
        _push(ssrRenderComponent(_component_router_link, {
          to: "/upload/reports/" + unref(data),
          target: "_blank",
          rel: "noopener"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                style: { "margin-top": "20px" },
                label: "Baixar relat\xF3rio",
                icon: "pi pi-cloud-download"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  style: { "margin-top": "20px" },
                  label: "Baixar relat\xF3rio",
                  icon: "pi pi-cloud-download"
                })
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/download.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=download-B57DbxZD.mjs.map
