import script from './inputtext.esm-sApbRJtn.mjs';
import { useSSRContext, defineComponent, ref, mergeProps, unref } from 'vue';
import { f as useAuthStore, s as storeToRefs, u as useRouter } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderStyle, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-BTo1DBng.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './basecomponent.esm-B0Mha2q3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "login",
  __ssrInlineRender: true,
  setup(__props) {
    useAuthStore();
    storeToRefs(useAuthStore());
    let msg = ref("");
    const user = ref({
      type: "users",
      username: "",
      password: ""
    });
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_InputText = script;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "body" }, _attrs))} data-v-b71d23d2><div id="container1" data-v-b71d23d2><div class="flex" data-v-b71d23d2><img${ssrRenderAttr("src", _imports_0)} style="${ssrRenderStyle({ "width": "150px", "margin-right": "30px" })}" data-v-b71d23d2><div data-v-b71d23d2><h1 style="${ssrRenderStyle({ "margin-top": "12px", "margin-left": "15px" })}" data-v-b71d23d2>WReport</h1><h3 style="${ssrRenderStyle({ "margin-top": "15px", "margin-left": "15px" })}" data-v-b71d23d2>Admin</h3></div></div><div id="login-container" data-v-b71d23d2><form data-v-b71d23d2><input${ssrRenderAttr("value", unref(user).type)} type="hidden" class="input" placeholder="Type" name="uname" autocomplete="off" required data-v-b71d23d2>`);
      _push(ssrRenderComponent(_component_InputText, {
        name: "fidelis",
        modelValue: unref(user).username,
        "onUpdate:modelValue": ($event) => unref(user).username = $event,
        type: "text",
        class: "input",
        placeholder: "Usu\xE1rio",
        autocomplete: "username",
        required: ""
      }, null, _parent));
      _push(ssrRenderComponent(_component_InputText, {
        modelValue: unref(user).password,
        "onUpdate:modelValue": ($event) => unref(user).password = $event,
        type: "password",
        class: "input",
        placeholder: "Senha",
        name: "psw",
        autocomplete: "off",
        required: ""
      }, null, _parent));
      _push(`<button data-v-b71d23d2>Entrar</button><div class="msg mt-3" data-v-b71d23d2>${ssrInterpolate(unref(msg))}</div></form></div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const login = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-b71d23d2"]]);

export { login as default };
//# sourceMappingURL=login-LUJ_nShd.mjs.map
