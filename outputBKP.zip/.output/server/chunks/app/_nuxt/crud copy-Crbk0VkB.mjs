import script from './toast.esm-Di1eVOG7.mjs';
import script$1 from './toolbar.esm-HDwT8J3K.mjs';
import script$2 from './button.esm-sSHPs3W5.mjs';
import script$3 from './fileupload.esm-C3sebSU2.mjs';
import script$4 from './datatable.esm-CbTG6Zy3.mjs';
import script$5 from './inputtext.esm-CY1MGtqk.mjs';
import script$6 from './column.esm-D_9bkwGs.mjs';
import script$7 from './rating.esm-z-z8oDYl.mjs';
import script$8 from './dialog.esm-DF58ccWn.mjs';
import script$9 from './textarea.esm-wrpH6U21.mjs';
import script$a from './dropdown.esm-BpN7Uydi.mjs';
import script$b from './radiobutton.esm-Dy5m1Rk5.mjs';
import script$c from './inputnumber.esm-4TYMEebL.mjs';
import { ref, unref, mergeProps, withCtx, createVNode, isRef, createTextVNode, toDisplayString, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import { f as useToast } from '../server.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import './index.esm-Bq_5RDja.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dg68Fgcm.mjs';
import './index.esm-20913B80.mjs';
import './index.esm-iPGlXaLT.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './index.esm-Dp-7Az-D.mjs';
import './index.esm-CaP80Tc5.mjs';
import './message.esm-q5Zy7R3n.mjs';
import './progressbar.esm-BfqxA279.mjs';
import './paginator.esm-DB7J9-Tz.mjs';
import './index.esm-BZBBIaQ0.mjs';
import './index.esm-UuuQr2TF.mjs';
import './virtualscroller.esm-BLdBM0im.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-uE8Xa7qf.mjs';
import './index.esm-DPIQtQ_I.mjs';
import './overlayeventbus.esm-BmXQsB7e.mjs';
import './checkbox.esm-BRtMjhaa.mjs';
import './index.esm-BOTt2uTe.mjs';
import './index.esm-jRTkyN61.mjs';
import './index.esm-CpjI3C5Z.mjs';
import './index.esm-CB9yXpcc.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "crud copy",
  __ssrInlineRender: true,
  setup(__props) {
    const toast = useToast();
    const products = ref(null);
    const productDialog = ref(false);
    const deleteProductDialog = ref(false);
    const deleteProductsDialog = ref(false);
    const product = ref({});
    const selectedProducts = ref(null);
    const dt = ref(null);
    const filters = ref({});
    const submitted = ref(false);
    const statuses = ref([
      { label: "INSTOCK", value: "instock" },
      { label: "LOWSTOCK", value: "lowstock" },
      { label: "OUTOFSTOCK", value: "outofstock" }
    ]);
    const formatCurrency = (value) => {
      return value.toLocaleString("en-US", { style: "currency", currency: "USD" });
    };
    const openNew = () => {
      product.value = {};
      submitted.value = false;
      productDialog.value = true;
    };
    const hideDialog = () => {
      productDialog.value = false;
      submitted.value = false;
    };
    const saveProduct = () => {
      submitted.value = true;
      if (product.value.name && product.value.name.trim() && product.value.price) {
        if (product.value.id) {
          product.value.inventoryStatus = product.value.inventoryStatus.value ? product.value.inventoryStatus.value : product.value.inventoryStatus;
          products.value[findIndexById(product.value.id)] = product.value;
          toast.add({ severity: "success", summary: "Successful", detail: "Product Updated", life: 3e3 });
        } else {
          product.value.id = createId();
          product.value.code = createId();
          product.value.image = "product-placeholder.svg";
          product.value.inventoryStatus = product.value.inventoryStatus ? product.value.inventoryStatus.value : "INSTOCK";
          products.value.push(product.value);
          toast.add({ severity: "success", summary: "Successful", detail: "Product Created", life: 3e3 });
        }
        productDialog.value = false;
        product.value = {};
      }
    };
    const editProduct = (editProduct2) => {
      product.value = { ...editProduct2 };
      console.log(product);
      productDialog.value = true;
    };
    const confirmDeleteProduct = (editProduct2) => {
      product.value = editProduct2;
      deleteProductDialog.value = true;
    };
    const deleteProduct = () => {
      products.value = products.value.filter((val) => val.id !== product.value.id);
      deleteProductDialog.value = false;
      product.value = {};
      toast.add({ severity: "success", summary: "Successful", detail: "Product Deleted", life: 3e3 });
    };
    const findIndexById = (id) => {
      let index = -1;
      for (let i = 0; i < products.value.length; i++) {
        if (products.value[i].id === id) {
          index = i;
          break;
        }
      }
      return index;
    };
    const createId = () => {
      let id = "";
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      for (let i = 0; i < 5; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return id;
    };
    const exportCSV = () => {
      dt.value.exportCSV();
    };
    const confirmDeleteSelected = () => {
      deleteProductsDialog.value = true;
    };
    const deleteSelectedProducts = () => {
      products.value = products.value.filter((val) => !selectedProducts.value.includes(val));
      deleteProductsDialog.value = false;
      selectedProducts.value = null;
      toast.add({ severity: "success", summary: "Successful", detail: "Products Deleted", life: 3e3 });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Toast = script;
      const _component_Toolbar = script$1;
      const _component_Button = script$2;
      const _component_FileUpload = script$3;
      const _component_DataTable = script$4;
      const _component_InputText = script$5;
      const _component_Column = script$6;
      const _component_Rating = script$7;
      const _component_Dialog = script$8;
      const _component_Textarea = script$9;
      const _component_Dropdown = script$a;
      const _component_RadioButton = script$b;
      const _component_InputNumber = script$c;
      if (unref(products)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid" }, _attrs))}><div class="col-12"><div class="card">`);
        _push(ssrRenderComponent(_component_Toast, null, null, _parent));
        _push(ssrRenderComponent(_component_Toolbar, { class: "mb-4" }, {
          start: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="my-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Button, {
                label: "New",
                icon: "pi pi-plus",
                class: "p-button-success mr-2",
                onClick: openNew
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Delete",
                icon: "pi pi-trash",
                class: "p-button-danger",
                onClick: confirmDeleteSelected,
                disabled: !unref(selectedProducts) || !unref(selectedProducts).length
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "my-2" }, [
                  createVNode(_component_Button, {
                    label: "New",
                    icon: "pi pi-plus",
                    class: "p-button-success mr-2",
                    onClick: openNew
                  }),
                  createVNode(_component_Button, {
                    label: "Delete",
                    icon: "pi pi-trash",
                    class: "p-button-danger",
                    onClick: confirmDeleteSelected,
                    disabled: !unref(selectedProducts) || !unref(selectedProducts).length
                  }, null, 8, ["disabled"])
                ])
              ];
            }
          }),
          end: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_FileUpload, {
                mode: "basic",
                accept: "image/*",
                maxFileSize: 1e6,
                label: "Import",
                chooseLabel: "Import",
                class: "mr-2 inline-block"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Export",
                icon: "pi pi-upload",
                class: "p-button-help",
                onClick: ($event) => exportCSV()
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_FileUpload, {
                  mode: "basic",
                  accept: "image/*",
                  maxFileSize: 1e6,
                  label: "Import",
                  chooseLabel: "Import",
                  class: "mr-2 inline-block"
                }),
                createVNode(_component_Button, {
                  label: "Export",
                  icon: "pi pi-upload",
                  class: "p-button-help",
                  onClick: ($event) => exportCSV()
                }, null, 8, ["onClick"])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_DataTable, {
          ref_key: "dt",
          ref: dt,
          value: unref(products),
          selection: unref(selectedProducts),
          "onUpdate:selection": ($event) => isRef(selectedProducts) ? selectedProducts.value = $event : null,
          dataKey: "id",
          paginator: true,
          rows: 10,
          filters: unref(filters),
          paginatorTemplate: "FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown",
          rowsPerPageOptions: [5, 10, 25],
          currentPageReportTemplate: "Showing {first} to {last} of {totalRecords} products",
          responsiveLayout: "scroll"
        }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex flex-column md:flex-row md:justify-content-between md:align-items-center"${_scopeId}><h5 class="m-0"${_scopeId}>Manage Products ninja!</h5><span class="block mt-2 md:mt-0 p-input-icon-left"${_scopeId}><i class="pi pi-search"${_scopeId}></i>`);
              _push2(ssrRenderComponent(_component_InputText, {
                modelValue: unref(filters)["global"].value,
                "onUpdate:modelValue": ($event) => unref(filters)["global"].value = $event,
                placeholder: "Search..."
              }, null, _parent2, _scopeId));
              _push2(`</span></div>`);
            } else {
              return [
                createVNode("div", { class: "flex flex-column md:flex-row md:justify-content-between md:align-items-center" }, [
                  createVNode("h5", { class: "m-0" }, "Manage Products ninja!"),
                  createVNode("span", { class: "block mt-2 md:mt-0 p-input-icon-left" }, [
                    createVNode("i", { class: "pi pi-search" }),
                    createVNode(_component_InputText, {
                      modelValue: unref(filters)["global"].value,
                      "onUpdate:modelValue": ($event) => unref(filters)["global"].value = $event,
                      placeholder: "Search..."
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Column, {
                selectionMode: "multiple",
                headerStyle: "width: 3rem"
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                field: "code",
                header: "Code",
                sortable: true,
                headerStyle: "width:14%; min-width:10rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Code</span> ${ssrInterpolate(slotProps.data.code)}`);
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Code"),
                      createTextVNode(" " + toDisplayString(slotProps.data.code), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                field: "name",
                header: "Name",
                sortable: true,
                headerStyle: "width:14%; min-width:10rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Name</span> ${ssrInterpolate(slotProps.data.name)}`);
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Name"),
                      createTextVNode(" " + toDisplayString(slotProps.data.name), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                header: "Image",
                headerStyle: "width:14%; min-width:10rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Image</span><img${ssrRenderAttr("src", "demo/images/product/" + slotProps.data.image)}${ssrRenderAttr("alt", slotProps.data.image)} class="shadow-2" width="100"${_scopeId2}>`);
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Image"),
                      createVNode("img", {
                        src: "demo/images/product/" + slotProps.data.image,
                        alt: slotProps.data.image,
                        class: "shadow-2",
                        width: "100"
                      }, null, 8, ["src", "alt"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                field: "price",
                header: "Price",
                sortable: true,
                headerStyle: "width:14%; min-width:8rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Price</span> ${ssrInterpolate(formatCurrency(slotProps.data.price))}`);
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Price"),
                      createTextVNode(" " + toDisplayString(formatCurrency(slotProps.data.price)), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                field: "category",
                header: "Category",
                sortable: true,
                headerStyle: "width:14%; min-width:10rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Category</span> ${ssrInterpolate(slotProps.data.category)}`);
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Category"),
                      createTextVNode(" " + toDisplayString(slotProps.data.category), 1)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                field: "rating",
                header: "Reviews",
                sortable: true,
                headerStyle: "width:14%; min-width:10rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Rating</span>`);
                    _push3(ssrRenderComponent(_component_Rating, {
                      modelValue: slotProps.data.rating,
                      readonly: true,
                      cancel: false
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Rating"),
                      createVNode(_component_Rating, {
                        modelValue: slotProps.data.rating,
                        readonly: true,
                        cancel: false
                      }, null, 8, ["modelValue"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, {
                field: "inventoryStatus",
                header: "Status",
                sortable: true,
                headerStyle: "width:14%; min-width:10rem;"
              }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<span class="p-column-title"${_scopeId2}>Status</span><span class="${ssrRenderClass("product-badge status-" + (slotProps.data.inventoryStatus ? slotProps.data.inventoryStatus.toLowerCase() : ""))}"${_scopeId2}>${ssrInterpolate(slotProps.data.inventoryStatus)}</span>`);
                  } else {
                    return [
                      createVNode("span", { class: "p-column-title" }, "Status"),
                      createVNode("span", {
                        class: "product-badge status-" + (slotProps.data.inventoryStatus ? slotProps.data.inventoryStatus.toLowerCase() : "")
                      }, toDisplayString(slotProps.data.inventoryStatus), 3)
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Column, { headerStyle: "min-width:10rem;" }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-pencil",
                      class: "p-button-rounded p-button-success mr-2",
                      onClick: ($event) => editProduct(slotProps.data)
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-trash",
                      class: "p-button-rounded p-button-warning mt-2",
                      onClick: ($event) => confirmDeleteProduct(slotProps.data)
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_Button, {
                        icon: "pi pi-pencil",
                        class: "p-button-rounded p-button-success mr-2",
                        onClick: ($event) => editProduct(slotProps.data)
                      }, null, 8, ["onClick"]),
                      createVNode(_component_Button, {
                        icon: "pi pi-trash",
                        class: "p-button-rounded p-button-warning mt-2",
                        onClick: ($event) => confirmDeleteProduct(slotProps.data)
                      }, null, 8, ["onClick"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Column, {
                  selectionMode: "multiple",
                  headerStyle: "width: 3rem"
                }),
                createVNode(_component_Column, {
                  field: "code",
                  header: "Code",
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Code"),
                    createTextVNode(" " + toDisplayString(slotProps.data.code), 1)
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, {
                  field: "name",
                  header: "Name",
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Name"),
                    createTextVNode(" " + toDisplayString(slotProps.data.name), 1)
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, {
                  header: "Image",
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Image"),
                    createVNode("img", {
                      src: "demo/images/product/" + slotProps.data.image,
                      alt: slotProps.data.image,
                      class: "shadow-2",
                      width: "100"
                    }, null, 8, ["src", "alt"])
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, {
                  field: "price",
                  header: "Price",
                  sortable: true,
                  headerStyle: "width:14%; min-width:8rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Price"),
                    createTextVNode(" " + toDisplayString(formatCurrency(slotProps.data.price)), 1)
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, {
                  field: "category",
                  header: "Category",
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Category"),
                    createTextVNode(" " + toDisplayString(slotProps.data.category), 1)
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, {
                  field: "rating",
                  header: "Reviews",
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Rating"),
                    createVNode(_component_Rating, {
                      modelValue: slotProps.data.rating,
                      readonly: true,
                      cancel: false
                    }, null, 8, ["modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, {
                  field: "inventoryStatus",
                  header: "Status",
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps) => [
                    createVNode("span", { class: "p-column-title" }, "Status"),
                    createVNode("span", {
                      class: "product-badge status-" + (slotProps.data.inventoryStatus ? slotProps.data.inventoryStatus.toLowerCase() : "")
                    }, toDisplayString(slotProps.data.inventoryStatus), 3)
                  ]),
                  _: 1
                }),
                createVNode(_component_Column, { headerStyle: "min-width:10rem;" }, {
                  body: withCtx((slotProps) => [
                    createVNode(_component_Button, {
                      icon: "pi pi-pencil",
                      class: "p-button-rounded p-button-success mr-2",
                      onClick: ($event) => editProduct(slotProps.data)
                    }, null, 8, ["onClick"]),
                    createVNode(_component_Button, {
                      icon: "pi pi-trash",
                      class: "p-button-rounded p-button-warning mt-2",
                      onClick: ($event) => confirmDeleteProduct(slotProps.data)
                    }, null, 8, ["onClick"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(productDialog),
          "onUpdate:visible": ($event) => isRef(productDialog) ? productDialog.value = $event : null,
          style: { width: "450px" },
          header: "Product Details",
          modal: true,
          class: "p-fluid"
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "Cancel",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: hideDialog
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Save",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: saveProduct
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "Cancel",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: hideDialog
                }),
                createVNode(_component_Button, {
                  label: "Save",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: saveProduct
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (unref(product).image) {
                _push2(`<img${ssrRenderAttr("src", "demo/images/product/" + unref(product).image)}${ssrRenderAttr("alt", unref(product).image)} width="150" class="mt-0 mx-auto mb-5 block shadow-2"${_scopeId}>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`<div class="field"${_scopeId}><label for="name"${_scopeId}>Name</label>`);
              _push2(ssrRenderComponent(_component_InputText, {
                id: "name",
                modelValue: unref(product).name,
                "onUpdate:modelValue": ($event) => unref(product).name = $event,
                modelModifiers: { trim: true },
                required: "true",
                autofocus: "",
                class: { "p-invalid": unref(submitted) && !unref(product).name }
              }, null, _parent2, _scopeId));
              if (unref(submitted) && !unref(product).name) {
                _push2(`<small class="p-invalid"${_scopeId}>Name is required.</small>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="field"${_scopeId}><label for="description"${_scopeId}>Description</label>`);
              _push2(ssrRenderComponent(_component_Textarea, {
                id: "description",
                modelValue: unref(product).description,
                "onUpdate:modelValue": ($event) => unref(product).description = $event,
                required: "true",
                rows: "3",
                cols: "20"
              }, null, _parent2, _scopeId));
              _push2(`</div><div class="field"${_scopeId}><label for="inventoryStatus" class="mb-3"${_scopeId}>Inventory Status</label>`);
              _push2(ssrRenderComponent(_component_Dropdown, {
                id: "inventoryStatus",
                modelValue: unref(product).inventoryStatus,
                "onUpdate:modelValue": ($event) => unref(product).inventoryStatus = $event,
                options: unref(statuses),
                optionLabel: "label",
                placeholder: "Select a Status"
              }, {
                value: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    if (slotProps.value && slotProps.value.value) {
                      _push3(`<div${_scopeId2}><span class="${ssrRenderClass("product-badge status-" + slotProps.value.value)}"${_scopeId2}>${ssrInterpolate(slotProps.value.label)}</span></div>`);
                    } else if (slotProps.value && !slotProps.value.value) {
                      _push3(`<div${_scopeId2}><span class="${ssrRenderClass("product-badge status-" + slotProps.value.toLowerCase())}"${_scopeId2}>${ssrInterpolate(slotProps.value)}</span></div>`);
                    } else {
                      _push3(`<span${_scopeId2}>${ssrInterpolate(slotProps.placeholder)}</span>`);
                    }
                  } else {
                    return [
                      slotProps.value && slotProps.value.value ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("span", {
                          class: "product-badge status-" + slotProps.value.value
                        }, toDisplayString(slotProps.value.label), 3)
                      ])) : slotProps.value && !slotProps.value.value ? (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("span", {
                          class: "product-badge status-" + slotProps.value.toLowerCase()
                        }, toDisplayString(slotProps.value), 3)
                      ])) : (openBlock(), createBlock("span", { key: 2 }, toDisplayString(slotProps.placeholder), 1))
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
              _push2(`</div><div class="field"${_scopeId}><label class="mb-3"${_scopeId}>Category</label><div class="formgrid grid"${_scopeId}><div class="field-radiobutton col-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_RadioButton, {
                id: "category1",
                name: "category",
                value: "Accessories",
                modelValue: unref(product).category,
                "onUpdate:modelValue": ($event) => unref(product).category = $event
              }, null, _parent2, _scopeId));
              _push2(`<label for="category1"${_scopeId}>Accessories</label></div><div class="field-radiobutton col-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_RadioButton, {
                id: "category2",
                name: "category",
                value: "Clothing",
                modelValue: unref(product).category,
                "onUpdate:modelValue": ($event) => unref(product).category = $event
              }, null, _parent2, _scopeId));
              _push2(`<label for="category2"${_scopeId}>Clothing</label></div><div class="field-radiobutton col-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_RadioButton, {
                id: "category3",
                name: "category",
                value: "Electronics",
                modelValue: unref(product).category,
                "onUpdate:modelValue": ($event) => unref(product).category = $event
              }, null, _parent2, _scopeId));
              _push2(`<label for="category3"${_scopeId}>Electronics</label></div><div class="field-radiobutton col-6"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_RadioButton, {
                id: "category4",
                name: "category",
                value: "Fitness",
                modelValue: unref(product).category,
                "onUpdate:modelValue": ($event) => unref(product).category = $event
              }, null, _parent2, _scopeId));
              _push2(`<label for="category4"${_scopeId}>Fitness</label></div></div></div><div class="formgrid grid"${_scopeId}><div class="field col"${_scopeId}><label for="price"${_scopeId}>Price</label>`);
              _push2(ssrRenderComponent(_component_InputNumber, {
                id: "price",
                modelValue: unref(product).price,
                "onUpdate:modelValue": ($event) => unref(product).price = $event,
                mode: "currency",
                currency: "USD",
                locale: "en-US",
                class: { "p-invalid": unref(submitted) && !unref(product).price },
                required: true
              }, null, _parent2, _scopeId));
              if (unref(submitted) && !unref(product).price) {
                _push2(`<small class="p-invalid"${_scopeId}>Price is required.</small>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div><div class="field col"${_scopeId}><label for="quantity"${_scopeId}>Quantity</label>`);
              _push2(ssrRenderComponent(_component_InputNumber, {
                id: "quantity",
                modelValue: unref(product).quantity,
                "onUpdate:modelValue": ($event) => unref(product).quantity = $event,
                integeronly: ""
              }, null, _parent2, _scopeId));
              _push2(`</div></div>`);
            } else {
              return [
                unref(product).image ? (openBlock(), createBlock("img", {
                  key: 0,
                  src: "demo/images/product/" + unref(product).image,
                  alt: unref(product).image,
                  width: "150",
                  class: "mt-0 mx-auto mb-5 block shadow-2"
                }, null, 8, ["src", "alt"])) : createCommentVNode("", true),
                createVNode("div", { class: "field" }, [
                  createVNode("label", { for: "name" }, "Name"),
                  createVNode(_component_InputText, {
                    id: "name",
                    modelValue: unref(product).name,
                    "onUpdate:modelValue": ($event) => unref(product).name = $event,
                    modelModifiers: { trim: true },
                    required: "true",
                    autofocus: "",
                    class: { "p-invalid": unref(submitted) && !unref(product).name }
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                  unref(submitted) && !unref(product).name ? (openBlock(), createBlock("small", {
                    key: 0,
                    class: "p-invalid"
                  }, "Name is required.")) : createCommentVNode("", true)
                ]),
                createVNode("div", { class: "field" }, [
                  createVNode("label", { for: "description" }, "Description"),
                  createVNode(_component_Textarea, {
                    id: "description",
                    modelValue: unref(product).description,
                    "onUpdate:modelValue": ($event) => unref(product).description = $event,
                    required: "true",
                    rows: "3",
                    cols: "20"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "field" }, [
                  createVNode("label", {
                    for: "inventoryStatus",
                    class: "mb-3"
                  }, "Inventory Status"),
                  createVNode(_component_Dropdown, {
                    id: "inventoryStatus",
                    modelValue: unref(product).inventoryStatus,
                    "onUpdate:modelValue": ($event) => unref(product).inventoryStatus = $event,
                    options: unref(statuses),
                    optionLabel: "label",
                    placeholder: "Select a Status"
                  }, {
                    value: withCtx((slotProps) => [
                      slotProps.value && slotProps.value.value ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("span", {
                          class: "product-badge status-" + slotProps.value.value
                        }, toDisplayString(slotProps.value.label), 3)
                      ])) : slotProps.value && !slotProps.value.value ? (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("span", {
                          class: "product-badge status-" + slotProps.value.toLowerCase()
                        }, toDisplayString(slotProps.value), 3)
                      ])) : (openBlock(), createBlock("span", { key: 2 }, toDisplayString(slotProps.placeholder), 1))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue", "options"])
                ]),
                createVNode("div", { class: "field" }, [
                  createVNode("label", { class: "mb-3" }, "Category"),
                  createVNode("div", { class: "formgrid grid" }, [
                    createVNode("div", { class: "field-radiobutton col-6" }, [
                      createVNode(_component_RadioButton, {
                        id: "category1",
                        name: "category",
                        value: "Accessories",
                        modelValue: unref(product).category,
                        "onUpdate:modelValue": ($event) => unref(product).category = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("label", { for: "category1" }, "Accessories")
                    ]),
                    createVNode("div", { class: "field-radiobutton col-6" }, [
                      createVNode(_component_RadioButton, {
                        id: "category2",
                        name: "category",
                        value: "Clothing",
                        modelValue: unref(product).category,
                        "onUpdate:modelValue": ($event) => unref(product).category = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("label", { for: "category2" }, "Clothing")
                    ]),
                    createVNode("div", { class: "field-radiobutton col-6" }, [
                      createVNode(_component_RadioButton, {
                        id: "category3",
                        name: "category",
                        value: "Electronics",
                        modelValue: unref(product).category,
                        "onUpdate:modelValue": ($event) => unref(product).category = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("label", { for: "category3" }, "Electronics")
                    ]),
                    createVNode("div", { class: "field-radiobutton col-6" }, [
                      createVNode(_component_RadioButton, {
                        id: "category4",
                        name: "category",
                        value: "Fitness",
                        modelValue: unref(product).category,
                        "onUpdate:modelValue": ($event) => unref(product).category = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("label", { for: "category4" }, "Fitness")
                    ])
                  ])
                ]),
                createVNode("div", { class: "formgrid grid" }, [
                  createVNode("div", { class: "field col" }, [
                    createVNode("label", { for: "price" }, "Price"),
                    createVNode(_component_InputNumber, {
                      id: "price",
                      modelValue: unref(product).price,
                      "onUpdate:modelValue": ($event) => unref(product).price = $event,
                      mode: "currency",
                      currency: "USD",
                      locale: "en-US",
                      class: { "p-invalid": unref(submitted) && !unref(product).price },
                      required: true
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                    unref(submitted) && !unref(product).price ? (openBlock(), createBlock("small", {
                      key: 0,
                      class: "p-invalid"
                    }, "Price is required.")) : createCommentVNode("", true)
                  ]),
                  createVNode("div", { class: "field col" }, [
                    createVNode("label", { for: "quantity" }, "Quantity"),
                    createVNode(_component_InputNumber, {
                      id: "quantity",
                      modelValue: unref(product).quantity,
                      "onUpdate:modelValue": ($event) => unref(product).quantity = $event,
                      integeronly: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(deleteProductDialog),
          "onUpdate:visible": ($event) => isRef(deleteProductDialog) ? deleteProductDialog.value = $event : null,
          style: { width: "450px" },
          header: "Confirm",
          modal: true
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "No",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: ($event) => deleteProductDialog.value = false
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Yes",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: deleteProduct
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "No",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: ($event) => deleteProductDialog.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_Button, {
                  label: "Yes",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: deleteProduct
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex align-items-center justify-content-center"${_scopeId}><i class="pi pi-exclamation-triangle mr-3" style="${ssrRenderStyle({ "font-size": "2rem" })}"${_scopeId}></i>`);
              if (unref(product)) {
                _push2(`<span${_scopeId}>Are you sure you want to delete <b${_scopeId}>${ssrInterpolate(unref(product).name)}</b>?</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex align-items-center justify-content-center" }, [
                  createVNode("i", {
                    class: "pi pi-exclamation-triangle mr-3",
                    style: { "font-size": "2rem" }
                  }),
                  unref(product) ? (openBlock(), createBlock("span", { key: 0 }, [
                    createTextVNode("Are you sure you want to delete "),
                    createVNode("b", null, toDisplayString(unref(product).name), 1),
                    createTextVNode("?")
                  ])) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(deleteProductsDialog),
          "onUpdate:visible": ($event) => isRef(deleteProductsDialog) ? deleteProductsDialog.value = $event : null,
          style: { width: "450px" },
          header: "Confirm",
          modal: true
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "No",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: ($event) => deleteProductsDialog.value = false
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Yes",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: deleteSelectedProducts
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "No",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: ($event) => deleteProductsDialog.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_Button, {
                  label: "Yes",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: deleteSelectedProducts
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex align-items-center justify-content-center"${_scopeId}><i class="pi pi-exclamation-triangle mr-3" style="${ssrRenderStyle({ "font-size": "2rem" })}"${_scopeId}></i>`);
              if (unref(product)) {
                _push2(`<span${_scopeId}>Are you sure you want to delete the selected products?</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex align-items-center justify-content-center" }, [
                  createVNode("i", {
                    class: "pi pi-exclamation-triangle mr-3",
                    style: { "font-size": "2rem" }
                  }),
                  unref(product) ? (openBlock(), createBlock("span", { key: 0 }, "Are you sure you want to delete the selected products?")) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/crud copy.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=crud copy-Crbk0VkB.mjs.map
