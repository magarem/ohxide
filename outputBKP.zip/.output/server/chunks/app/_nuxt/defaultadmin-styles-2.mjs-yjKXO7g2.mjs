const defaultadmin_vue_vue_type_style_index_0_scoped_6e6d68f4_lang = ".menulink[data-v-6e6d68f4]{color:#f5f5f5}";

export { defaultadmin_vue_vue_type_style_index_0_scoped_6e6d68f4_lang as d };
//# sourceMappingURL=defaultadmin-styles-2.mjs-yjKXO7g2.mjs.map
