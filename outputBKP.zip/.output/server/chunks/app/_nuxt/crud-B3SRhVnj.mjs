import script from './toast.esm-Di1eVOG7.mjs';
import script$1 from './toolbar.esm-HDwT8J3K.mjs';
import script$2 from './button.esm-sSHPs3W5.mjs';
import script$3 from './datatable.esm-CbTG6Zy3.mjs';
import script$4 from './inputtext.esm-CY1MGtqk.mjs';
import script$5 from './column.esm-D_9bkwGs.mjs';
import script$6 from './dialog.esm-DF58ccWn.mjs';
import { ref, unref, mergeProps, withCtx, createVNode, isRef, toDisplayString, createTextVNode, openBlock, createBlock, Fragment, renderList, createCommentVNode, useSSRContext } from 'vue';
import { f as useToast, j as useRoute } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import './index.esm-Bq_5RDja.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dg68Fgcm.mjs';
import './index.esm-20913B80.mjs';
import './index.esm-iPGlXaLT.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './index.esm-Dp-7Az-D.mjs';
import './paginator.esm-DB7J9-Tz.mjs';
import './index.esm-BZBBIaQ0.mjs';
import './dropdown.esm-BpN7Uydi.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-jRTkyN61.mjs';
import './overlayeventbus.esm-BmXQsB7e.mjs';
import './virtualscroller.esm-BLdBM0im.mjs';
import './inputnumber.esm-4TYMEebL.mjs';
import './index.esm-CpjI3C5Z.mjs';
import './index.esm-CB9yXpcc.mjs';
import './index.esm-UuuQr2TF.mjs';
import './index.esm-uE8Xa7qf.mjs';
import './index.esm-DPIQtQ_I.mjs';
import './checkbox.esm-BRtMjhaa.mjs';
import './radiobutton.esm-Dy5m1Rk5.mjs';
import './index.esm-CaP80Tc5.mjs';
import './index.esm-BOTt2uTe.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "crud",
  __ssrInlineRender: true,
  setup(__props) {
    const toast = useToast();
    const dataItems = ref(null);
    const dataItemDialog = ref(false);
    const deleteDataItemDialog = ref(false);
    const deleteDataItemsDialog = ref(false);
    const dataItem = ref({});
    const selectedDataItems = ref(null);
    const dt = ref(null);
    const filters = ref({});
    const submitted = ref(false);
    const dataGridColumns = ref([]);
    const route = useRoute();
    const source = route.query.source;
    const openNew = () => {
      dataItem.value = {};
      submitted.value = false;
      dataItemDialog.value = true;
    };
    const hideDialog = () => {
      dataItemDialog.value = false;
      submitted.value = false;
    };
    const saveDataItem = async () => {
      submitted.value = true;
      if (dataItem.value.id) {
        dataItems.value[findIndexById(dataItem.value.id)] = dataItem.value;
        toast.add({ severity: "success", summary: "Successful", detail: "DataItem Updated", life: 3e3 });
      } else {
        dataItem.value.id = createId();
        dataItem.value.code = createId();
        dataItems.value.push(dataItem.value);
        toast.add({ severity: "success", summary: "Successful", detail: "DataItem Created", life: 3e3 });
      }
      dataItemDialog.value = false;
      dataItem.value = {};
      try {
        const txt = {
          schema: dataGridColumns.value,
          data: dataItems.value
        };
        const config = {
          method: "POST",
          headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ filename: source, txt: JSON.stringify(txt, null, 2) })
        };
        const response = await fetch("/api/save", config);
      } catch (error) {
        console.log("save api error");
      }
    };
    const editDataItem = (editDataItem2) => {
      dataItem.value = { ...editDataItem2 };
      console.log(dataItem);
      dataItemDialog.value = true;
    };
    const confirmDeleteDataItem = (editDataItem2) => {
      dataItem.value = editDataItem2;
      deleteDataItemDialog.value = true;
    };
    const deleteDataItem = async () => {
      dataItems.value = dataItems.value.filter((val) => val.id !== dataItem.value.id);
      deleteDataItemDialog.value = false;
      dataItem.value = {};
      try {
        const txt = {
          schema: dataGridColumns.value,
          data: dataItems.value
        };
        const config = {
          method: "POST",
          headers: {
            "Accept": "application/json",
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ filename: source, txt: JSON.stringify(txt, null, 2) })
        };
        const response = await fetch("/api/save", config);
      } catch (error) {
        console.log("save api error");
      }
      toast.add({ severity: "success", summary: "Successful", detail: "DataItem Deleted", life: 3e3 });
    };
    const findIndexById = (id) => {
      let index = -1;
      for (let i = 0; i < dataItems.value.length; i++) {
        if (dataItems.value[i].id === id) {
          index = i;
          break;
        }
      }
      return index;
    };
    const createId = () => {
      let id = "";
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      for (let i = 0; i < 5; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return id;
    };
    const confirmDeleteSelected = () => {
      deleteDataItemsDialog.value = true;
    };
    const deleteSelectedDataItems = () => {
      dataItems.value = dataItems.value.filter((val) => !selectedDataItems.value.includes(val));
      deleteDataItemsDialog.value = false;
      selectedDataItems.value = null;
      toast.add({ severity: "success", summary: "Successful", detail: "DataItems Deleted", life: 3e3 });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Toast = script;
      const _component_Toolbar = script$1;
      const _component_Button = script$2;
      const _component_DataTable = script$3;
      const _component_InputText = script$4;
      const _component_Column = script$5;
      const _component_Dialog = script$6;
      if (unref(dataItems)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid" }, _attrs))}><div class="col-12"><div class="card">`);
        _push(ssrRenderComponent(_component_Toast, null, null, _parent));
        _push(ssrRenderComponent(_component_Toolbar, { class: "mb-4" }, {
          start: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="my-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Button, {
                label: "Novo",
                icon: "pi pi-plus",
                class: "p-button-success mr-2",
                onClick: openNew
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Excluir",
                icon: "pi pi-trash",
                class: "p-button-danger",
                onClick: confirmDeleteSelected,
                disabled: !unref(selectedDataItems) || !unref(selectedDataItems).length
              }, null, _parent2, _scopeId));
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "my-2" }, [
                  createVNode(_component_Button, {
                    label: "Novo",
                    icon: "pi pi-plus",
                    class: "p-button-success mr-2",
                    onClick: openNew
                  }),
                  createVNode(_component_Button, {
                    label: "Excluir",
                    icon: "pi pi-trash",
                    class: "p-button-danger",
                    onClick: confirmDeleteSelected,
                    disabled: !unref(selectedDataItems) || !unref(selectedDataItems).length
                  }, null, 8, ["disabled"])
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_DataTable, {
          ref_key: "dt",
          ref: dt,
          value: unref(dataItems),
          selection: unref(selectedDataItems),
          "onUpdate:selection": ($event) => isRef(selectedDataItems) ? selectedDataItems.value = $event : null,
          dataKey: "id",
          paginator: true,
          rows: 10,
          filters: unref(filters),
          paginatorTemplate: "FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown",
          rowsPerPageOptions: [5, 10, 25],
          currentPageReportTemplate: "Showing {first} to {last} of {totalRecords} dataItems",
          responsiveLayout: "scroll"
        }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex flex-column md:flex-row md:justify-content-between md:align-items-center"${_scopeId}><h5 class="m-0"${_scopeId}>Items</h5><span class="block mt-2 md:mt-0 p-input-icon-left"${_scopeId}><i class="pi pi-search"${_scopeId}></i>`);
              _push2(ssrRenderComponent(_component_InputText, {
                modelValue: unref(filters)["global"].value,
                "onUpdate:modelValue": ($event) => unref(filters)["global"].value = $event,
                placeholder: "Buscar..."
              }, null, _parent2, _scopeId));
              _push2(`</span></div>`);
            } else {
              return [
                createVNode("div", { class: "flex flex-column md:flex-row md:justify-content-between md:align-items-center" }, [
                  createVNode("h5", { class: "m-0" }, "Items"),
                  createVNode("span", { class: "block mt-2 md:mt-0 p-input-icon-left" }, [
                    createVNode("i", { class: "pi pi-search" }),
                    createVNode(_component_InputText, {
                      modelValue: unref(filters)["global"].value,
                      "onUpdate:modelValue": ($event) => unref(filters)["global"].value = $event,
                      placeholder: "Buscar..."
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Column, {
                selectionMode: "multiple",
                headerStyle: "width: 3rem"
              }, null, _parent2, _scopeId));
              _push2(`<!--[-->`);
              ssrRenderList(unref(dataGridColumns), (item) => {
                _push2(ssrRenderComponent(_component_Column, {
                  field: item[0],
                  header: item[1],
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<span class="p-column-title"${_scopeId2}>${ssrInterpolate(item[1])}</span> ${ssrInterpolate(slotProps.data[item[0]])}`);
                    } else {
                      return [
                        createVNode("span", { class: "p-column-title" }, toDisplayString(item[1]), 1),
                        createTextVNode(" " + toDisplayString(slotProps.data[item[0]]), 1)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              _push2(ssrRenderComponent(_component_Column, { headerStyle: "min-width:10rem;" }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-pencil",
                      class: "p-button-rounded p-button-success mr-2",
                      onClick: ($event) => editDataItem(slotProps.data)
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-trash",
                      class: "p-button-rounded p-button-warning mt-2",
                      onClick: ($event) => confirmDeleteDataItem(slotProps.data)
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_Button, {
                        icon: "pi pi-pencil",
                        class: "p-button-rounded p-button-success mr-2",
                        onClick: ($event) => editDataItem(slotProps.data)
                      }, null, 8, ["onClick"]),
                      createVNode(_component_Button, {
                        icon: "pi pi-trash",
                        class: "p-button-rounded p-button-warning mt-2",
                        onClick: ($event) => confirmDeleteDataItem(slotProps.data)
                      }, null, 8, ["onClick"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Column, {
                  selectionMode: "multiple",
                  headerStyle: "width: 3rem"
                }),
                (openBlock(true), createBlock(Fragment, null, renderList(unref(dataGridColumns), (item) => {
                  return openBlock(), createBlock(_component_Column, {
                    field: item[0],
                    header: item[1],
                    sortable: true,
                    headerStyle: "width:14%; min-width:10rem;"
                  }, {
                    body: withCtx((slotProps) => [
                      createVNode("span", { class: "p-column-title" }, toDisplayString(item[1]), 1),
                      createTextVNode(" " + toDisplayString(slotProps.data[item[0]]), 1)
                    ]),
                    _: 2
                  }, 1032, ["field", "header"]);
                }), 256)),
                createVNode(_component_Column, { headerStyle: "min-width:10rem;" }, {
                  body: withCtx((slotProps) => [
                    createVNode(_component_Button, {
                      icon: "pi pi-pencil",
                      class: "p-button-rounded p-button-success mr-2",
                      onClick: ($event) => editDataItem(slotProps.data)
                    }, null, 8, ["onClick"]),
                    createVNode(_component_Button, {
                      icon: "pi pi-trash",
                      class: "p-button-rounded p-button-warning mt-2",
                      onClick: ($event) => confirmDeleteDataItem(slotProps.data)
                    }, null, 8, ["onClick"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(dataItemDialog),
          "onUpdate:visible": ($event) => isRef(dataItemDialog) ? dataItemDialog.value = $event : null,
          style: { width: "450px" },
          header: "DataItem Details",
          modal: true,
          class: "p-fluid"
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "Cancel",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: hideDialog
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Save",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: saveDataItem
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "Cancel",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: hideDialog
                }),
                createVNode(_component_Button, {
                  label: "Save",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: saveDataItem
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(dataGridColumns), (item) => {
                _push2(`<div class="field"${_scopeId}><label for="name"${_scopeId}>${ssrInterpolate(item[1])}</label>`);
                _push2(ssrRenderComponent(_component_InputText, {
                  id: "name",
                  modelValue: unref(dataItem)[item[0]],
                  "onUpdate:modelValue": ($event) => unref(dataItem)[item[0]] = $event,
                  modelModifiers: { trim: true },
                  required: "true",
                  autofocus: "",
                  class: { "p-invalid": unref(submitted) && !unref(dataItem).name }
                }, null, _parent2, _scopeId));
                if (unref(submitted) && !unref(dataItem).name) {
                  _push2(`<small class="p-invalid"${_scopeId}>Preencha ${ssrInterpolate(item[1])}</small>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]-->`);
            } else {
              return [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(dataGridColumns), (item) => {
                  return openBlock(), createBlock("div", { class: "field" }, [
                    createVNode("label", { for: "name" }, toDisplayString(item[1]), 1),
                    createVNode(_component_InputText, {
                      id: "name",
                      modelValue: unref(dataItem)[item[0]],
                      "onUpdate:modelValue": ($event) => unref(dataItem)[item[0]] = $event,
                      modelModifiers: { trim: true },
                      required: "true",
                      autofocus: "",
                      class: { "p-invalid": unref(submitted) && !unref(dataItem).name }
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "class"]),
                    unref(submitted) && !unref(dataItem).name ? (openBlock(), createBlock("small", {
                      key: 0,
                      class: "p-invalid"
                    }, "Preencha " + toDisplayString(item[1]), 1)) : createCommentVNode("", true)
                  ]);
                }), 256))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(deleteDataItemDialog),
          "onUpdate:visible": ($event) => isRef(deleteDataItemDialog) ? deleteDataItemDialog.value = $event : null,
          style: { width: "450px" },
          header: "Confirm",
          modal: true
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "No",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: ($event) => deleteDataItemDialog.value = false
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Yes",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: deleteDataItem
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "No",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: ($event) => deleteDataItemDialog.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_Button, {
                  label: "Yes",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: deleteDataItem
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex align-items-center justify-content-center"${_scopeId}><i class="pi pi-exclamation-triangle mr-3" style="${ssrRenderStyle({ "font-size": "2rem" })}"${_scopeId}></i>`);
              if (unref(dataItem)) {
                _push2(`<span${_scopeId}>Are you sure you want to delete <b${_scopeId}>${ssrInterpolate(unref(dataItem).name)}</b>?</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex align-items-center justify-content-center" }, [
                  createVNode("i", {
                    class: "pi pi-exclamation-triangle mr-3",
                    style: { "font-size": "2rem" }
                  }),
                  unref(dataItem) ? (openBlock(), createBlock("span", { key: 0 }, [
                    createTextVNode("Are you sure you want to delete "),
                    createVNode("b", null, toDisplayString(unref(dataItem).name), 1),
                    createTextVNode("?")
                  ])) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(deleteDataItemsDialog),
          "onUpdate:visible": ($event) => isRef(deleteDataItemsDialog) ? deleteDataItemsDialog.value = $event : null,
          style: { width: "450px" },
          header: "Confirm",
          modal: true
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "No",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: ($event) => deleteDataItemsDialog.value = false
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Yes",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: deleteSelectedDataItems
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "No",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: ($event) => deleteDataItemsDialog.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_Button, {
                  label: "Yes",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: deleteSelectedDataItems
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex align-items-center justify-content-center"${_scopeId}><i class="pi pi-exclamation-triangle mr-3" style="${ssrRenderStyle({ "font-size": "2rem" })}"${_scopeId}></i>`);
              if (unref(dataItem)) {
                _push2(`<span${_scopeId}>Are you sure you want to delete the selected dataItems?</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex align-items-center justify-content-center" }, [
                  createVNode("i", {
                    class: "pi pi-exclamation-triangle mr-3",
                    style: { "font-size": "2rem" }
                  }),
                  unref(dataItem) ? (openBlock(), createBlock("span", { key: 0 }, "Are you sure you want to delete the selected dataItems?")) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/crud.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=crud-B3SRhVnj.mjs.map
