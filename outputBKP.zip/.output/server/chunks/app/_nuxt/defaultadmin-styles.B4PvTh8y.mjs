import { d as defaultadmin_vue_vue_type_style_index_0_scoped_6e6d68f4_lang } from './defaultadmin-styles-2.mjs-yjKXO7g2.mjs';

const defaultadminStyles_B4PvTh8y = [defaultadmin_vue_vue_type_style_index_0_scoped_6e6d68f4_lang];

export { defaultadminStyles_B4PvTh8y as default };
//# sourceMappingURL=defaultadmin-styles.B4PvTh8y.mjs.map
