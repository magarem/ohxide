import script from './card.esm-BpnvnFjb.mjs';
import script$1 from './datatable.esm-CbTG6Zy3.mjs';
import script$2 from './inputtext.esm-CY1MGtqk.mjs';
import script$3 from './button.esm-sSHPs3W5.mjs';
import script$4 from './column.esm-D_9bkwGs.mjs';
import { u as useRouter, e as useAuthStore, s as storeToRefs, b as useCookie, d as db } from '../server.mjs';
import { ref, reactive, withAsyncContext, computed, unref, mergeProps, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import './basecomponent.esm-DLeZPnJV.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dp-7Az-D.mjs';
import './paginator.esm-DB7J9-Tz.mjs';
import './index.esm-BZBBIaQ0.mjs';
import './dropdown.esm-BpN7Uydi.mjs';
import './index.esm-Bq_5RDja.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-jRTkyN61.mjs';
import './index.esm-20913B80.mjs';
import './overlayeventbus.esm-BmXQsB7e.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './virtualscroller.esm-BLdBM0im.mjs';
import './inputnumber.esm-4TYMEebL.mjs';
import './index.esm-CpjI3C5Z.mjs';
import './index.esm-CB9yXpcc.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './index.esm-UuuQr2TF.mjs';
import './index.esm-uE8Xa7qf.mjs';
import './index.esm-DPIQtQ_I.mjs';
import './checkbox.esm-BRtMjhaa.mjs';
import './radiobutton.esm-Dy5m1Rk5.mjs';
import './index.esm-CaP80Tc5.mjs';
import './index.esm-BOTt2uTe.mjs';

const _sfc_main = {
  __name: "teste",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const { logUserOut } = useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    const dataUser = useCookie("dataUser");
    console.log("dataUser---->:", dataUser.value);
    const tableFilter = ref({
      year: null,
      month: null
    });
    if (dataUser.type !== "clients") {
      logUserOut();
    }
    if (!authenticated.value) {
      router.push("/login");
    }
    reactive({
      isLoading: false,
      columns: [
        {
          label: "ID",
          field: "id",
          width: "3%",
          sortable: true,
          isKey: true
        },
        {
          label: "Ano",
          field: "year",
          width: "10%",
          sortable: true
        },
        {
          label: "M\xEAs",
          field: "month",
          width: "10%",
          sortable: true
        },
        {
          label: "T\xEDtulo",
          field: "title",
          width: "10%",
          sortable: true
        },
        {
          label: "Arquivo",
          field: "file",
          width: "10%",
          sortable: true
        },
        {
          label: "Etiquetas",
          field: "tags",
          width: "15%",
          sortable: true
        }
      ],
      rows: [],
      totalRecordCount: 0,
      sortable: {
        order: "id",
        sort: "asc"
      }
    });
    const data = ([__temp, __restore] = withAsyncContext(() => db.get(`select reports.year, reports.month, reports.name, reports.desc, reports.file, products.name as tag from reports, products where reports.tag = products.id`)), __temp = await __temp, __restore(), __temp);
    console.log("data:", data);
    const aaa = computed(() => {
      return data.filter((x) => x.year == (tableFilter.value.year || x.year) & x.month == (tableFilter.value.month || x.month));
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Card = script;
      const _component_DataTable = script$1;
      const _component_InputText = script$2;
      const _component_Button = script$3;
      const _component_Column = script$4;
      if (unref(dataUser)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "m-0" }, _attrs))}>`);
        _push(ssrRenderComponent(_component_Card, {
          class: "m-5",
          style: { "width": "80%" }
        }, {
          title: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Relat\xF3rios`);
            } else {
              return [
                createTextVNode("Relat\xF3rios")
              ];
            }
          }),
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_DataTable, {
                value: unref(aaa),
                stripedRows: "",
                tableStyle: "width: 100%"
              }, {
                header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="mb-3"${_scopeId2}> Buscar: `);
                    _push3(ssrRenderComponent(_component_InputText, {
                      id: "tableFilter",
                      modelValue: unref(tableFilter).year,
                      "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                      autofocus: "",
                      placeholder: "Ano",
                      style: { "width": "100px" },
                      class: "mx-1"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_InputText, {
                      id: "tableFilter",
                      modelValue: unref(tableFilter).month,
                      "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                      autofocus: "",
                      placeholder: "M\xEAs",
                      style: { "width": "100px" },
                      class: "mx-1"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-times",
                      onClick: ($event) => tableFilter.value = {},
                      severity: "danger",
                      text: "",
                      rounded: "",
                      "aria-label": "Cancel"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                  } else {
                    return [
                      createVNode("div", { class: "mb-3" }, [
                        createTextVNode(" Buscar: "),
                        createVNode(_component_InputText, {
                          id: "tableFilter",
                          modelValue: unref(tableFilter).year,
                          "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                          autofocus: "",
                          placeholder: "Ano",
                          style: { "width": "100px" },
                          class: "mx-1"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_InputText, {
                          id: "tableFilter",
                          modelValue: unref(tableFilter).month,
                          "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                          autofocus: "",
                          placeholder: "M\xEAs",
                          style: { "width": "100px" },
                          class: "mx-1"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_Button, {
                          icon: "pi pi-times",
                          onClick: ($event) => tableFilter.value = {},
                          severity: "danger",
                          text: "",
                          rounded: "",
                          "aria-label": "Cancel"
                        }, null, 8, ["onClick"])
                      ])
                    ];
                  }
                }),
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "year",
                      header: "Ano"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "month",
                      header: "M\xEAs"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "title",
                      header: "T\xEDtulo"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "desc",
                      header: "Descri\xE7\xE3o"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "file",
                      header: "Relat\xF3rio"
                    }, {
                      body: withCtx((slotProps, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<a${ssrRenderAttr("href", "file/" + slotProps.data.file)} target="_blank"${_scopeId3}>Baixar</a>`);
                        } else {
                          return [
                            createVNode("a", {
                              href: "file/" + slotProps.data.file,
                              target: "_blank"
                            }, "Baixar", 8, ["href"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "tag",
                      header: "R\xF3tulos"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_Column, {
                        field: "year",
                        header: "Ano"
                      }),
                      createVNode(_component_Column, {
                        field: "month",
                        header: "M\xEAs"
                      }),
                      createVNode(_component_Column, {
                        field: "title",
                        header: "T\xEDtulo"
                      }),
                      createVNode(_component_Column, {
                        field: "desc",
                        header: "Descri\xE7\xE3o"
                      }),
                      createVNode(_component_Column, {
                        field: "file",
                        header: "Relat\xF3rio"
                      }, {
                        body: withCtx((slotProps) => [
                          createVNode("a", {
                            href: "file/" + slotProps.data.file,
                            target: "_blank"
                          }, "Baixar", 8, ["href"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_Column, {
                        field: "tag",
                        header: "R\xF3tulos"
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_DataTable, {
                  value: unref(aaa),
                  stripedRows: "",
                  tableStyle: "width: 100%"
                }, {
                  header: withCtx(() => [
                    createVNode("div", { class: "mb-3" }, [
                      createTextVNode(" Buscar: "),
                      createVNode(_component_InputText, {
                        id: "tableFilter",
                        modelValue: unref(tableFilter).year,
                        "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                        autofocus: "",
                        placeholder: "Ano",
                        style: { "width": "100px" },
                        class: "mx-1"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_component_InputText, {
                        id: "tableFilter",
                        modelValue: unref(tableFilter).month,
                        "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                        autofocus: "",
                        placeholder: "M\xEAs",
                        style: { "width": "100px" },
                        class: "mx-1"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_component_Button, {
                        icon: "pi pi-times",
                        onClick: ($event) => tableFilter.value = {},
                        severity: "danger",
                        text: "",
                        rounded: "",
                        "aria-label": "Cancel"
                      }, null, 8, ["onClick"])
                    ])
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_Column, {
                      field: "year",
                      header: "Ano"
                    }),
                    createVNode(_component_Column, {
                      field: "month",
                      header: "M\xEAs"
                    }),
                    createVNode(_component_Column, {
                      field: "title",
                      header: "T\xEDtulo"
                    }),
                    createVNode(_component_Column, {
                      field: "desc",
                      header: "Descri\xE7\xE3o"
                    }),
                    createVNode(_component_Column, {
                      field: "file",
                      header: "Relat\xF3rio"
                    }, {
                      body: withCtx((slotProps) => [
                        createVNode("a", {
                          href: "file/" + slotProps.data.file,
                          target: "_blank"
                        }, "Baixar", 8, ["href"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_Column, {
                      field: "tag",
                      header: "R\xF3tulos"
                    })
                  ]),
                  _: 1
                }, 8, ["value"])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/teste.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=teste-UKe5Gg7z.mjs.map
