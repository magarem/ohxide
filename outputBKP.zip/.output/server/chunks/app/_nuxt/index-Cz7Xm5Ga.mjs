import script from './toast.esm-Di1eVOG7.mjs';
import script$1 from './confirmdialog.esm-CvnMV9Ah.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-DIGsyTgU.mjs';
import script$2 from './dialog.esm-DF58ccWn.mjs';
import script$3 from './card.esm-BpnvnFjb.mjs';
import script$4 from './multiselect.esm-Bv8rNR12.mjs';
import script$5 from './button.esm-sSHPs3W5.mjs';
import { ref, withAsyncContext, unref, withCtx, createTextVNode, isRef, createVNode, withDirectives, vModelText, useSSRContext } from 'vue';
import { u as useRouter, b as useCookie, e as useAuthStore, s as storeToRefs, d as db, f as useToast } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import './index.esm-Bq_5RDja.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dg68Fgcm.mjs';
import './index.esm-20913B80.mjs';
import './index.esm-iPGlXaLT.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './checkbox.esm-BRtMjhaa.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-jRTkyN61.mjs';
import './index.esm-Dp-7Az-D.mjs';
import './overlayeventbus.esm-BmXQsB7e.mjs';
import './virtualscroller.esm-BLdBM0im.mjs';
import './badge.esm-W3lzGlw9.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    let retorno = ref();
    const visible = ref(false);
    const clients = ref(([__temp, __restore] = withAsyncContext(() => db.get("select * from clients")), __temp = await __temp, __restore(), __temp));
    const toast = useToast();
    const sendEmailForm = ref({
      year: (/* @__PURE__ */ new Date()).getFullYear(),
      month: (/* @__PURE__ */ new Date()).getMonth() + 1,
      subject: "Novo relat\xF3rio dispon\xEDvel",
      message: "Ol\xE1!\nSeu relat\xF3rio est\xE1 pronto no link abaixo.",
      linktext: "Baixar relat\xF3rio"
    });
    const sendMails = async () => {
      if (sendEmailForm.value.clients.length > 0) {
        const ret = await $fetch("/api/sendemail", {
          method: "POST",
          body: JSON.stringify(sendEmailForm.value)
        });
        if (ret) {
          visible.value = false;
          toast.add({ severity: "secondary", summary: "E-mails", detail: ret.join(", "), life: 3e3 });
        }
      }
    };
    if (!authenticated.value) {
      router.push("/admin/login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_Toast = script;
      const _component_ConfirmDialog = script$1;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Dialog = script$2;
      const _component_Card = script$3;
      const _component_MultiSelect = script$4;
      const _component_Button = script$5;
      _push(`<!--[--><div class="p-5"><div _class="flex">`);
      _push(ssrRenderComponent(_component_Toast, null, null, _parent));
      _push(ssrRenderComponent(_component_ConfirmDialog, null, null, _parent));
      if (((_a = unref(dataUser)) == null ? void 0 : _a.status) == "root") {
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
          to: "/admin/users"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Usu\xE1rios`);
            } else {
              return [
                createTextVNode("Usu\xE1rios")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
        to: "/admin/clients"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Clientes`);
          } else {
            return [
              createTextVNode("Clientes")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
        to: "/admin/products"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Produtos`);
          } else {
            return [
              createTextVNode("Produtos")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
        to: "/admin/reports"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Relat\xF3rios`);
          } else {
            return [
              createTextVNode("Relat\xF3rios")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<br> ${ssrInterpolate(unref(retorno))}</div></div>`);
      _push(ssrRenderComponent(_component_Dialog, {
        visible: unref(visible),
        "onUpdate:visible": ($event) => isRef(visible) ? visible.value = $event : null,
        header: "Envio de mensagens",
        style: { width: "35rem" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Card, {
              style: { "width": "31rem", "overflow": "hidden" },
              class: "mt-0"
            }, {
              content: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="formgrid grid"${_scopeId2}><div class="field col-12 md:col-3"${_scopeId2}><label for="firstname6"${_scopeId2}>Ano</label><input id="firstname6"${ssrRenderAttr("value", unref(sendEmailForm).year)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12 md:col-3"${_scopeId2}><label for="lastname6"${_scopeId2}>M\xEAs</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).month)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12 md:col-6"${_scopeId2}><label for="lastname6"${_scopeId2}>Assunto</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).subject)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12"${_scopeId2}><label for="address"${_scopeId2}>Mensagem</label><textarea id="address" type="text" rows="4" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}>${ssrInterpolate(unref(sendEmailForm).message)}</textarea></div><div class="field col-12"${_scopeId2}><label for="lastname6"${_scopeId2}>Texto do link</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).linktext)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12 md:col-3"${_scopeId2}><label for="state"${_scopeId2}>Clientes</label>`);
                  _push3(ssrRenderComponent(_component_MultiSelect, {
                    modelValue: unref(sendEmailForm).clients,
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                    display: "chip",
                    options: unref(clients),
                    optionLabel: "name",
                    optionValue: "id",
                    placeholder: "Selecione os clientes",
                    maxSelectedLabels: 3,
                    class: "w-full md:w-28rem"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "formgrid grid" }, [
                      createVNode("div", { class: "field col-12 md:col-3" }, [
                        createVNode("label", { for: "firstname6" }, "Ano"),
                        withDirectives(createVNode("input", {
                          id: "firstname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).year = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).year]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12 md:col-3" }, [
                        createVNode("label", { for: "lastname6" }, "M\xEAs"),
                        withDirectives(createVNode("input", {
                          id: "lastname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).month = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).month]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12 md:col-6" }, [
                        createVNode("label", { for: "lastname6" }, "Assunto"),
                        withDirectives(createVNode("input", {
                          id: "lastname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).subject = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).subject]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12" }, [
                        createVNode("label", { for: "address" }, "Mensagem"),
                        withDirectives(createVNode("textarea", {
                          id: "address",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).message = $event,
                          type: "text",
                          rows: "4",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).message]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12" }, [
                        createVNode("label", { for: "lastname6" }, "Texto do link"),
                        withDirectives(createVNode("input", {
                          id: "lastname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).linktext = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).linktext]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12 md:col-3" }, [
                        createVNode("label", { for: "state" }, "Clientes"),
                        createVNode(_component_MultiSelect, {
                          modelValue: unref(sendEmailForm).clients,
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                          display: "chip",
                          options: unref(clients),
                          optionLabel: "name",
                          optionValue: "id",
                          placeholder: "Selecione os clientes",
                          maxSelectedLabels: 3,
                          class: "w-full md:w-28rem"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                      ])
                    ])
                  ];
                }
              }),
              footer: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex gap-3 mt-1"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => visible.value = false,
                    label: "Cancel",
                    severity: "secondary",
                    outlined: "",
                    class: "w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: sendMails,
                    label: "Enviar",
                    class: "w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex gap-3 mt-1" }, [
                      createVNode(_component_Button, {
                        onClick: ($event) => visible.value = false,
                        label: "Cancel",
                        severity: "secondary",
                        outlined: "",
                        class: "w-full"
                      }, null, 8, ["onClick"]),
                      createVNode(_component_Button, {
                        onClick: sendMails,
                        label: "Enviar",
                        class: "w-full"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Card, {
                style: { "width": "31rem", "overflow": "hidden" },
                class: "mt-0"
              }, {
                content: withCtx(() => [
                  createVNode("div", { class: "formgrid grid" }, [
                    createVNode("div", { class: "field col-12 md:col-3" }, [
                      createVNode("label", { for: "firstname6" }, "Ano"),
                      withDirectives(createVNode("input", {
                        id: "firstname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).year = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).year]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12 md:col-3" }, [
                      createVNode("label", { for: "lastname6" }, "M\xEAs"),
                      withDirectives(createVNode("input", {
                        id: "lastname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).month = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).month]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12 md:col-6" }, [
                      createVNode("label", { for: "lastname6" }, "Assunto"),
                      withDirectives(createVNode("input", {
                        id: "lastname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).subject = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).subject]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12" }, [
                      createVNode("label", { for: "address" }, "Mensagem"),
                      withDirectives(createVNode("textarea", {
                        id: "address",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).message = $event,
                        type: "text",
                        rows: "4",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).message]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12" }, [
                      createVNode("label", { for: "lastname6" }, "Texto do link"),
                      withDirectives(createVNode("input", {
                        id: "lastname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).linktext = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).linktext]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12 md:col-3" }, [
                      createVNode("label", { for: "state" }, "Clientes"),
                      createVNode(_component_MultiSelect, {
                        modelValue: unref(sendEmailForm).clients,
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                        display: "chip",
                        options: unref(clients),
                        optionLabel: "name",
                        optionValue: "id",
                        placeholder: "Selecione os clientes",
                        maxSelectedLabels: 3,
                        class: "w-full md:w-28rem"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                    ])
                  ])
                ]),
                footer: withCtx(() => [
                  createVNode("div", { class: "flex gap-3 mt-1" }, [
                    createVNode(_component_Button, {
                      onClick: ($event) => visible.value = false,
                      label: "Cancel",
                      severity: "secondary",
                      outlined: "",
                      class: "w-full"
                    }, null, 8, ["onClick"]),
                    createVNode(_component_Button, {
                      onClick: sendMails,
                      label: "Enviar",
                      class: "w-full"
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-Cz7Xm5Ga.mjs.map
