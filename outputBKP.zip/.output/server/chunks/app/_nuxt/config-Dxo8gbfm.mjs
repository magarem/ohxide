import script from './toast.esm-Di1eVOG7.mjs';
import script$1 from './confirmdialog.esm-CvnMV9Ah.mjs';
import script$2 from './accordion.esm-UXPmnmO_.mjs';
import script$3 from './accordiontab.esm-BjyoavaM.mjs';
import script$4 from './card.esm-BpnvnFjb.mjs';
import script$5 from './textarea.esm-wrpH6U21.mjs';
import script$6 from './button.esm-sSHPs3W5.mjs';
import { ref, withAsyncContext, withCtx, unref, createVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, withDirectives, vModelText, createCommentVNode, useSSRContext } from 'vue';
import { u as useRouter, b as useCookie, e as useAuthStore, s as storeToRefs, d as db, f as useToast } from '../server.mjs';
import { ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import './index.esm-Bq_5RDja.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dg68Fgcm.mjs';
import './index.esm-20913B80.mjs';
import './index.esm-iPGlXaLT.mjs';
import './dialog.esm-DF58ccWn.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-uE8Xa7qf.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './index.esm-Dp-7Az-D.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "config",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    useCookie("dataUser");
    useAuthStore();
    storeToRefs(useAuthStore());
    ref();
    ref(false);
    const isDesabled = ref(false);
    ref(([__temp, __restore] = withAsyncContext(() => db.get("select * from clients")), __temp = await __temp, __restore(), __temp));
    const toast = useToast();
    const config_report = ref({
      meta: {
        id: "config_report",
        name: "Relat\xF3rio - marca d'agua",
        table: "config"
      },
      schema: {
        x: { name: "Posi\xE7\xE3o x", type: "text" },
        y: { name: "Posi\xE7\xE3o y", type: "text" },
        size: { name: "Tamanho", type: "text" },
        color: { name: "Cor", type: "text", help: "Ex: #0000FF" },
        rotate: { name: "Rota\xE7\xE3o", type: "text", help: "0% - 100%" },
        opacity: { name: "Densidade", type: "text" }
      },
      bkpData: {
        x: "",
        y: "",
        size: "",
        rotate: "",
        txt: ""
      },
      data: {
        x: 100,
        y: "",
        size: "",
        rotate: "",
        txt: ""
      }
    });
    const config_emailsend = ref({
      meta: {
        id: "config_emailsend",
        name: "Envio de mensagem - dados do email",
        table: "config"
      },
      schema: {
        subject: { name: "Assunto", type: "text" },
        body: { name: "Texto", type: "textarea" },
        linkTxt: { name: "Texto do link", type: "text" }
      },
      bkpData: {
        subject: "",
        body: "",
        linkTxt: ""
      },
      data: {
        subject: "",
        body: "",
        linkTxt: ""
      }
    });
    const reset = (id) => {
      console.log("id:", id);
      eval(id).value.data = { ...eval(id).value.bkpData };
    };
    const save = async (id) => {
      console.log("id:", id);
      await db.update({
        table: eval(id).value.meta.table,
        data: {
          // id: eval(id).value.meta.id,
          data: JSON.stringify(eval(id).value.data)
        },
        where: "id LIKE '" + eval(id).value.meta.id + "'"
      });
      toast.add({ severity: "secondary", summary: "Configura\xE7\xE3o", detail: "Arquivo salvo com sucesso!", life: 3e3 });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Toast = script;
      const _component_ConfirmDialog = script$1;
      const _component_Accordion = script$2;
      const _component_AccordionTab = script$3;
      const _component_Card = script$4;
      const _component_Textarea = script$5;
      const _component_Button = script$6;
      _push(`<!--[--><h3>Configura\xE7\xF5es</h3>`);
      _push(ssrRenderComponent(_component_Toast, null, null, _parent));
      _push(ssrRenderComponent(_component_ConfirmDialog, null, null, _parent));
      _push(ssrRenderComponent(_component_Accordion, {
        activeIndex: 0,
        expandIcon: "pi pi-plus",
        collapseIcon: "pi pi-minus"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_AccordionTab, null, {
              header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="flex align-items-center gap-2 w-full"${_scopeId2}><span class="font-bold white-space-nowrap" style="${ssrRenderStyle({ "font-size": "20px" })}"${_scopeId2}>${ssrInterpolate(unref(config_report).meta.name)}</span></span>`);
                } else {
                  return [
                    createVNode("span", { class: "flex align-items-center gap-2 w-full" }, [
                      createVNode("span", {
                        class: "font-bold white-space-nowrap",
                        style: { "font-size": "20px" }
                      }, toDisplayString(unref(config_report).meta.name), 1)
                    ])
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Card, {
                    style: { "width": "100%", "overflow": "hidden" },
                    class: "mt-0"
                  }, {
                    content: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="formgrid grid"${_scopeId3}><table style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId3}><!--[-->`);
                        ssrRenderList(Object.entries(unref(config_report).schema), (item) => {
                          _push4(`<tr style="${ssrRenderStyle({ "width": "100%" })}" _class="field col-12"${_scopeId3}><td style="${ssrRenderStyle({ "width": "20%", "text-align": "right", "padding-right": "10px" })}"${_scopeId3}><label style="${ssrRenderStyle({ "font-size": "17px", "font-weight": "350" })}"${ssrRenderAttr("for", item[1].name)}${_scopeId3}>${ssrInterpolate(item[1].name)}</label></td><td style="${ssrRenderStyle({ "width": "30%" })}"${_scopeId3}>`);
                          if (item[1].type == "text") {
                            _push4(`<input${ssrRenderAttr("id", item[1].name)}${ssrRenderAttr("value", unref(config_report).data[item[0]])} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId3}>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (item[1].type == "textarea") {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_component_Textarea, {
                              modelValue: unref(config_report).data[item[0]],
                              "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                              rows: "5",
                              style: { "width": "100%" }
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</td><td style="${ssrRenderStyle({ "width": "50%" })}"${_scopeId3}><span style="${ssrRenderStyle({ "padding-left": "10px", "font-style": "italic" })}"${_scopeId3}>${ssrInterpolate(item[1].help)}</span></td></tr>`);
                        });
                        _push4(`<!--]--><tr${_scopeId3}><td${_scopeId3}></td><td colspan="2" class="pt-3"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Button, {
                          class: "mr-2",
                          style: { "width": "200px" },
                          onClick: ($event) => save("config_report"),
                          disabled: unref(isDesabled),
                          label: "Salvar",
                          _class: "w-50"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_Button, {
                          style: { "width": "200px" },
                          onClick: ($event) => reset("config_report"),
                          label: "Cancel",
                          severity: "secondary",
                          outlined: "",
                          _class: "w-50"
                        }, null, _parent4, _scopeId3));
                        _push4(`</td></tr></table></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "formgrid grid" }, [
                            createVNode("table", { style: { "width": "100%" } }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(Object.entries(unref(config_report).schema), (item) => {
                                return openBlock(), createBlock("tr", {
                                  style: { "width": "100%" },
                                  _class: "field col-12",
                                  key: item[0]
                                }, [
                                  createVNode("td", { style: { "width": "20%", "text-align": "right", "padding-right": "10px" } }, [
                                    createVNode("label", {
                                      style: { "font-size": "17px", "font-weight": "350" },
                                      for: item[1].name
                                    }, toDisplayString(item[1].name), 9, ["for"])
                                  ]),
                                  createVNode("td", { style: { "width": "30%" } }, [
                                    item[1].type == "text" ? withDirectives((openBlock(), createBlock("input", {
                                      key: 0,
                                      id: item[1].name,
                                      "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                                      type: "text",
                                      class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                                    }, null, 8, ["id", "onUpdate:modelValue"])), [
                                      [vModelText, unref(config_report).data[item[0]]]
                                    ]) : createCommentVNode("", true),
                                    item[1].type == "textarea" ? (openBlock(), createBlock("div", { key: 1 }, [
                                      createVNode(_component_Textarea, {
                                        modelValue: unref(config_report).data[item[0]],
                                        "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                                        rows: "5",
                                        style: { "width": "100%" }
                                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                    ])) : createCommentVNode("", true)
                                  ]),
                                  createVNode("td", { style: { "width": "50%" } }, [
                                    createVNode("span", { style: { "padding-left": "10px", "font-style": "italic" } }, toDisplayString(item[1].help), 1)
                                  ])
                                ]);
                              }), 128)),
                              createVNode("tr", null, [
                                createVNode("td"),
                                createVNode("td", {
                                  colspan: "2",
                                  class: "pt-3"
                                }, [
                                  createVNode(_component_Button, {
                                    class: "mr-2",
                                    style: { "width": "200px" },
                                    onClick: ($event) => save("config_report"),
                                    disabled: unref(isDesabled),
                                    label: "Salvar",
                                    _class: "w-50"
                                  }, null, 8, ["onClick", "disabled"]),
                                  createVNode(_component_Button, {
                                    style: { "width": "200px" },
                                    onClick: ($event) => reset("config_report"),
                                    label: "Cancel",
                                    severity: "secondary",
                                    outlined: "",
                                    _class: "w-50"
                                  }, null, 8, ["onClick"])
                                ])
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Card, {
                      style: { "width": "100%", "overflow": "hidden" },
                      class: "mt-0"
                    }, {
                      content: withCtx(() => [
                        createVNode("div", { class: "formgrid grid" }, [
                          createVNode("table", { style: { "width": "100%" } }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(Object.entries(unref(config_report).schema), (item) => {
                              return openBlock(), createBlock("tr", {
                                style: { "width": "100%" },
                                _class: "field col-12",
                                key: item[0]
                              }, [
                                createVNode("td", { style: { "width": "20%", "text-align": "right", "padding-right": "10px" } }, [
                                  createVNode("label", {
                                    style: { "font-size": "17px", "font-weight": "350" },
                                    for: item[1].name
                                  }, toDisplayString(item[1].name), 9, ["for"])
                                ]),
                                createVNode("td", { style: { "width": "30%" } }, [
                                  item[1].type == "text" ? withDirectives((openBlock(), createBlock("input", {
                                    key: 0,
                                    id: item[1].name,
                                    "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                                    type: "text",
                                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                                  }, null, 8, ["id", "onUpdate:modelValue"])), [
                                    [vModelText, unref(config_report).data[item[0]]]
                                  ]) : createCommentVNode("", true),
                                  item[1].type == "textarea" ? (openBlock(), createBlock("div", { key: 1 }, [
                                    createVNode(_component_Textarea, {
                                      modelValue: unref(config_report).data[item[0]],
                                      "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                                      rows: "5",
                                      style: { "width": "100%" }
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ])) : createCommentVNode("", true)
                                ]),
                                createVNode("td", { style: { "width": "50%" } }, [
                                  createVNode("span", { style: { "padding-left": "10px", "font-style": "italic" } }, toDisplayString(item[1].help), 1)
                                ])
                              ]);
                            }), 128)),
                            createVNode("tr", null, [
                              createVNode("td"),
                              createVNode("td", {
                                colspan: "2",
                                class: "pt-3"
                              }, [
                                createVNode(_component_Button, {
                                  class: "mr-2",
                                  style: { "width": "200px" },
                                  onClick: ($event) => save("config_report"),
                                  disabled: unref(isDesabled),
                                  label: "Salvar",
                                  _class: "w-50"
                                }, null, 8, ["onClick", "disabled"]),
                                createVNode(_component_Button, {
                                  style: { "width": "200px" },
                                  onClick: ($event) => reset("config_report"),
                                  label: "Cancel",
                                  severity: "secondary",
                                  outlined: "",
                                  _class: "w-50"
                                }, null, 8, ["onClick"])
                              ])
                            ])
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_AccordionTab, null, {
              header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="flex align-items-center gap-2 w-full"${_scopeId2}><span class="font-bold white-space-nowrap" style="${ssrRenderStyle({ "font-size": "20px" })}"${_scopeId2}>${ssrInterpolate(unref(config_emailsend).meta.name)}</span></span>`);
                } else {
                  return [
                    createVNode("span", { class: "flex align-items-center gap-2 w-full" }, [
                      createVNode("span", {
                        class: "font-bold white-space-nowrap",
                        style: { "font-size": "20px" }
                      }, toDisplayString(unref(config_emailsend).meta.name), 1)
                    ])
                  ];
                }
              }),
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_Card, {
                    style: { "width": "100%", "overflow": "hidden" },
                    class: "mt-0"
                  }, {
                    content: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<div class="formgrid grid"${_scopeId3}><table style="${ssrRenderStyle({ "width": "100%" })}"${_scopeId3}><!--[-->`);
                        ssrRenderList(Object.entries(unref(config_emailsend).schema), (item) => {
                          _push4(`<tr style="${ssrRenderStyle({ "width": "100%" })}" _class="field col-12"${_scopeId3}><td style="${ssrRenderStyle({ "width": "20%", "text-align": "right", "padding-right": "10px" })}"${_scopeId3}><label style="${ssrRenderStyle({ "font-size": "17px", "font-weight": "350" })}"${ssrRenderAttr("for", item[1].name)}${_scopeId3}>${ssrInterpolate(item[1].name)}</label></td><td style="${ssrRenderStyle({ "width": "30%" })}"${_scopeId3}>`);
                          if (item[1].type == "text") {
                            _push4(`<input${ssrRenderAttr("id", item[1].name)}${ssrRenderAttr("value", unref(config_emailsend).data[item[0]])} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId3}>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          if (item[1].type == "textarea") {
                            _push4(`<div${_scopeId3}>`);
                            _push4(ssrRenderComponent(_component_Textarea, {
                              modelValue: unref(config_emailsend).data[item[0]],
                              "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                              rows: "5",
                              style: { "width": "100%" }
                            }, null, _parent4, _scopeId3));
                            _push4(`</div>`);
                          } else {
                            _push4(`<!---->`);
                          }
                          _push4(`</td><td style="${ssrRenderStyle({ "width": "50%" })}"${_scopeId3}><span style="${ssrRenderStyle({ "padding-left": "10px", "font-style": "italic" })}"${_scopeId3}>${ssrInterpolate(item[1].help)}</span></td></tr>`);
                        });
                        _push4(`<!--]--><tr${_scopeId3}><td${_scopeId3}></td><td colspan="2" class="pt-3"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_Button, {
                          class: "mr-2",
                          style: { "width": "200px" },
                          onClick: ($event) => save("config_emailsend"),
                          disabled: unref(isDesabled),
                          label: "Salvar",
                          _class: "w-50"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_Button, {
                          style: { "width": "200px" },
                          onClick: ($event) => reset("config_emailsend"),
                          label: "Cancel",
                          severity: "secondary",
                          outlined: "",
                          _class: "w-50"
                        }, null, _parent4, _scopeId3));
                        _push4(`</td></tr></table></div>`);
                      } else {
                        return [
                          createVNode("div", { class: "formgrid grid" }, [
                            createVNode("table", { style: { "width": "100%" } }, [
                              (openBlock(true), createBlock(Fragment, null, renderList(Object.entries(unref(config_emailsend).schema), (item) => {
                                return openBlock(), createBlock("tr", {
                                  style: { "width": "100%" },
                                  _class: "field col-12",
                                  key: item[0]
                                }, [
                                  createVNode("td", { style: { "width": "20%", "text-align": "right", "padding-right": "10px" } }, [
                                    createVNode("label", {
                                      style: { "font-size": "17px", "font-weight": "350" },
                                      for: item[1].name
                                    }, toDisplayString(item[1].name), 9, ["for"])
                                  ]),
                                  createVNode("td", { style: { "width": "30%" } }, [
                                    item[1].type == "text" ? withDirectives((openBlock(), createBlock("input", {
                                      key: 0,
                                      id: item[1].name,
                                      "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                                      type: "text",
                                      class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                                    }, null, 8, ["id", "onUpdate:modelValue"])), [
                                      [vModelText, unref(config_emailsend).data[item[0]]]
                                    ]) : createCommentVNode("", true),
                                    item[1].type == "textarea" ? (openBlock(), createBlock("div", { key: 1 }, [
                                      createVNode(_component_Textarea, {
                                        modelValue: unref(config_emailsend).data[item[0]],
                                        "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                                        rows: "5",
                                        style: { "width": "100%" }
                                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                    ])) : createCommentVNode("", true)
                                  ]),
                                  createVNode("td", { style: { "width": "50%" } }, [
                                    createVNode("span", { style: { "padding-left": "10px", "font-style": "italic" } }, toDisplayString(item[1].help), 1)
                                  ])
                                ]);
                              }), 128)),
                              createVNode("tr", null, [
                                createVNode("td"),
                                createVNode("td", {
                                  colspan: "2",
                                  class: "pt-3"
                                }, [
                                  createVNode(_component_Button, {
                                    class: "mr-2",
                                    style: { "width": "200px" },
                                    onClick: ($event) => save("config_emailsend"),
                                    disabled: unref(isDesabled),
                                    label: "Salvar",
                                    _class: "w-50"
                                  }, null, 8, ["onClick", "disabled"]),
                                  createVNode(_component_Button, {
                                    style: { "width": "200px" },
                                    onClick: ($event) => reset("config_emailsend"),
                                    label: "Cancel",
                                    severity: "secondary",
                                    outlined: "",
                                    _class: "w-50"
                                  }, null, 8, ["onClick"])
                                ])
                              ])
                            ])
                          ])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_Card, {
                      style: { "width": "100%", "overflow": "hidden" },
                      class: "mt-0"
                    }, {
                      content: withCtx(() => [
                        createVNode("div", { class: "formgrid grid" }, [
                          createVNode("table", { style: { "width": "100%" } }, [
                            (openBlock(true), createBlock(Fragment, null, renderList(Object.entries(unref(config_emailsend).schema), (item) => {
                              return openBlock(), createBlock("tr", {
                                style: { "width": "100%" },
                                _class: "field col-12",
                                key: item[0]
                              }, [
                                createVNode("td", { style: { "width": "20%", "text-align": "right", "padding-right": "10px" } }, [
                                  createVNode("label", {
                                    style: { "font-size": "17px", "font-weight": "350" },
                                    for: item[1].name
                                  }, toDisplayString(item[1].name), 9, ["for"])
                                ]),
                                createVNode("td", { style: { "width": "30%" } }, [
                                  item[1].type == "text" ? withDirectives((openBlock(), createBlock("input", {
                                    key: 0,
                                    id: item[1].name,
                                    "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                                    type: "text",
                                    class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                                  }, null, 8, ["id", "onUpdate:modelValue"])), [
                                    [vModelText, unref(config_emailsend).data[item[0]]]
                                  ]) : createCommentVNode("", true),
                                  item[1].type == "textarea" ? (openBlock(), createBlock("div", { key: 1 }, [
                                    createVNode(_component_Textarea, {
                                      modelValue: unref(config_emailsend).data[item[0]],
                                      "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                                      rows: "5",
                                      style: { "width": "100%" }
                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                  ])) : createCommentVNode("", true)
                                ]),
                                createVNode("td", { style: { "width": "50%" } }, [
                                  createVNode("span", { style: { "padding-left": "10px", "font-style": "italic" } }, toDisplayString(item[1].help), 1)
                                ])
                              ]);
                            }), 128)),
                            createVNode("tr", null, [
                              createVNode("td"),
                              createVNode("td", {
                                colspan: "2",
                                class: "pt-3"
                              }, [
                                createVNode(_component_Button, {
                                  class: "mr-2",
                                  style: { "width": "200px" },
                                  onClick: ($event) => save("config_emailsend"),
                                  disabled: unref(isDesabled),
                                  label: "Salvar",
                                  _class: "w-50"
                                }, null, 8, ["onClick", "disabled"]),
                                createVNode(_component_Button, {
                                  style: { "width": "200px" },
                                  onClick: ($event) => reset("config_emailsend"),
                                  label: "Cancel",
                                  severity: "secondary",
                                  outlined: "",
                                  _class: "w-50"
                                }, null, 8, ["onClick"])
                              ])
                            ])
                          ])
                        ])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_AccordionTab, null, {
                header: withCtx(() => [
                  createVNode("span", { class: "flex align-items-center gap-2 w-full" }, [
                    createVNode("span", {
                      class: "font-bold white-space-nowrap",
                      style: { "font-size": "20px" }
                    }, toDisplayString(unref(config_report).meta.name), 1)
                  ])
                ]),
                default: withCtx(() => [
                  createVNode(_component_Card, {
                    style: { "width": "100%", "overflow": "hidden" },
                    class: "mt-0"
                  }, {
                    content: withCtx(() => [
                      createVNode("div", { class: "formgrid grid" }, [
                        createVNode("table", { style: { "width": "100%" } }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(Object.entries(unref(config_report).schema), (item) => {
                            return openBlock(), createBlock("tr", {
                              style: { "width": "100%" },
                              _class: "field col-12",
                              key: item[0]
                            }, [
                              createVNode("td", { style: { "width": "20%", "text-align": "right", "padding-right": "10px" } }, [
                                createVNode("label", {
                                  style: { "font-size": "17px", "font-weight": "350" },
                                  for: item[1].name
                                }, toDisplayString(item[1].name), 9, ["for"])
                              ]),
                              createVNode("td", { style: { "width": "30%" } }, [
                                item[1].type == "text" ? withDirectives((openBlock(), createBlock("input", {
                                  key: 0,
                                  id: item[1].name,
                                  "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                                  type: "text",
                                  class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                                }, null, 8, ["id", "onUpdate:modelValue"])), [
                                  [vModelText, unref(config_report).data[item[0]]]
                                ]) : createCommentVNode("", true),
                                item[1].type == "textarea" ? (openBlock(), createBlock("div", { key: 1 }, [
                                  createVNode(_component_Textarea, {
                                    modelValue: unref(config_report).data[item[0]],
                                    "onUpdate:modelValue": ($event) => unref(config_report).data[item[0]] = $event,
                                    rows: "5",
                                    style: { "width": "100%" }
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ])) : createCommentVNode("", true)
                              ]),
                              createVNode("td", { style: { "width": "50%" } }, [
                                createVNode("span", { style: { "padding-left": "10px", "font-style": "italic" } }, toDisplayString(item[1].help), 1)
                              ])
                            ]);
                          }), 128)),
                          createVNode("tr", null, [
                            createVNode("td"),
                            createVNode("td", {
                              colspan: "2",
                              class: "pt-3"
                            }, [
                              createVNode(_component_Button, {
                                class: "mr-2",
                                style: { "width": "200px" },
                                onClick: ($event) => save("config_report"),
                                disabled: unref(isDesabled),
                                label: "Salvar",
                                _class: "w-50"
                              }, null, 8, ["onClick", "disabled"]),
                              createVNode(_component_Button, {
                                style: { "width": "200px" },
                                onClick: ($event) => reset("config_report"),
                                label: "Cancel",
                                severity: "secondary",
                                outlined: "",
                                _class: "w-50"
                              }, null, 8, ["onClick"])
                            ])
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_AccordionTab, null, {
                header: withCtx(() => [
                  createVNode("span", { class: "flex align-items-center gap-2 w-full" }, [
                    createVNode("span", {
                      class: "font-bold white-space-nowrap",
                      style: { "font-size": "20px" }
                    }, toDisplayString(unref(config_emailsend).meta.name), 1)
                  ])
                ]),
                default: withCtx(() => [
                  createVNode(_component_Card, {
                    style: { "width": "100%", "overflow": "hidden" },
                    class: "mt-0"
                  }, {
                    content: withCtx(() => [
                      createVNode("div", { class: "formgrid grid" }, [
                        createVNode("table", { style: { "width": "100%" } }, [
                          (openBlock(true), createBlock(Fragment, null, renderList(Object.entries(unref(config_emailsend).schema), (item) => {
                            return openBlock(), createBlock("tr", {
                              style: { "width": "100%" },
                              _class: "field col-12",
                              key: item[0]
                            }, [
                              createVNode("td", { style: { "width": "20%", "text-align": "right", "padding-right": "10px" } }, [
                                createVNode("label", {
                                  style: { "font-size": "17px", "font-weight": "350" },
                                  for: item[1].name
                                }, toDisplayString(item[1].name), 9, ["for"])
                              ]),
                              createVNode("td", { style: { "width": "30%" } }, [
                                item[1].type == "text" ? withDirectives((openBlock(), createBlock("input", {
                                  key: 0,
                                  id: item[1].name,
                                  "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                                  type: "text",
                                  class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                                }, null, 8, ["id", "onUpdate:modelValue"])), [
                                  [vModelText, unref(config_emailsend).data[item[0]]]
                                ]) : createCommentVNode("", true),
                                item[1].type == "textarea" ? (openBlock(), createBlock("div", { key: 1 }, [
                                  createVNode(_component_Textarea, {
                                    modelValue: unref(config_emailsend).data[item[0]],
                                    "onUpdate:modelValue": ($event) => unref(config_emailsend).data[item[0]] = $event,
                                    rows: "5",
                                    style: { "width": "100%" }
                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                ])) : createCommentVNode("", true)
                              ]),
                              createVNode("td", { style: { "width": "50%" } }, [
                                createVNode("span", { style: { "padding-left": "10px", "font-style": "italic" } }, toDisplayString(item[1].help), 1)
                              ])
                            ]);
                          }), 128)),
                          createVNode("tr", null, [
                            createVNode("td"),
                            createVNode("td", {
                              colspan: "2",
                              class: "pt-3"
                            }, [
                              createVNode(_component_Button, {
                                class: "mr-2",
                                style: { "width": "200px" },
                                onClick: ($event) => save("config_emailsend"),
                                disabled: unref(isDesabled),
                                label: "Salvar",
                                _class: "w-50"
                              }, null, 8, ["onClick", "disabled"]),
                              createVNode(_component_Button, {
                                style: { "width": "200px" },
                                onClick: ($event) => reset("config_emailsend"),
                                label: "Cancel",
                                severity: "secondary",
                                outlined: "",
                                _class: "w-50"
                              }, null, 8, ["onClick"])
                            ])
                          ])
                        ])
                      ])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/config.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=config-Dxo8gbfm.mjs.map
