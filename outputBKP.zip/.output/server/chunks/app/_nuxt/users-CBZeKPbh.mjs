import { _ as __nuxt_component_0 } from './Magacrud-7AHrzwIm.mjs';
import { withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { d as db, j as users } from '../server.mjs';
import './toast.esm-BKV23R5p.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-B0Mha2q3.mjs';
import './index.esm-D94sOlgY.mjs';
import './baseicon.esm-Cy2FoSiq.mjs';
import './index.esm-CIJ2jzyK.mjs';
import './index.esm-Do8-MTsn.mjs';
import './index.esm-CubdsAVt.mjs';
import './datatable.esm-D-j0vQ0j.mjs';
import './index.esm-By_6gZSM.mjs';
import './paginator.esm-COCE9vsc.mjs';
import './index.esm-CS7GSScE.mjs';
import './dropdown.esm-BKW57F2o.mjs';
import './index.esm-RNZSX7pe.mjs';
import './index.esm-CdM9LvbI.mjs';
import './overlayeventbus.esm-BcDW6nGW.mjs';
import './virtualscroller.esm-D3fYAFU7.mjs';
import './inputnumber.esm-sm91Uxkg.mjs';
import './button.esm-BF_RjID0.mjs';
import './badge.esm-xka9JVxi.mjs';
import './index.esm-NoH0xj4w.mjs';
import './index.esm-rWWN5_Ww.mjs';
import './inputtext.esm-sApbRJtn.mjs';
import './index.esm-Da6BvuXO.mjs';
import './index.esm-5hwuCqx5.mjs';
import './index.esm-qKGlvuIm.mjs';
import './checkbox.esm-D6d19euv.mjs';
import './radiobutton.esm-BkiUrXcW.mjs';
import './index.esm-Di5PhpuS.mjs';
import './index.esm-DsRQC5Mg.mjs';
import './column.esm-DnTi4bfm.mjs';
import './dialog.esm-CEP5tmQi.mjs';
import './textarea.esm-efz_AWOh.mjs';
import './multiselect.esm-B65gFVu2.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "users",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const data = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from users`)), __temp = await __temp, __restore(), __temp);
    const insertdata = async (data2) => {
      console.log("data:", data2);
      const ret = await db.insert({
        table: "users",
        data: data2
      });
      console.log("ret insert:", ret);
    };
    const updatedata = async (data2) => {
      const ret = await db.update({
        table: "users",
        data: data2,
        where: "id LIKE '" + data2.id + "'"
      });
      console.log("ret update:", ret);
    };
    const deletedata = async (data2) => {
      if (Array.isArray(data2)) {
        const ret = await db.delete({
          table: "users",
          where: "id in (" + data2.map((x) => `'${x.id}'`).join(",") + ")"
        });
        console.log("ret update:", ret);
      } else {
        const ret = await db.delete({
          table: "users",
          where: "id like '" + data2.id + "'"
        });
        console.log("ret update:", ret);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(ssrRenderComponent(_component_Magacrud, mergeProps({
        onInsertdata: insertdata,
        onUpdatedata: updatedata,
        onDeletedata: deletedata,
        schema: unref(users),
        data: unref(data)
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/users.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=users-CBZeKPbh.mjs.map
