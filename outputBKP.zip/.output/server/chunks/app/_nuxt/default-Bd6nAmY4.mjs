import script from './button.esm-sSHPs3W5.mjs';
import { u as useRouter, b as useCookie, e as useAuthStore, s as storeToRefs } from '../server.mjs';
import { unref, useSSRContext } from 'vue';
import { ssrRenderStyle, ssrRenderAttr, ssrInterpolate, ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-BTo1DBng.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './index.esm-Dp-7Az-D.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    console.log("dataUser:", !dataUser.value);
    const { logUserOut } = useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    const logOut = () => {
      logUserOut();
      router.push("/login");
    };
    if (!authenticated.value || !dataUser.value) {
      console.log("!!!!!!!!!");
      router.push("login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_Button = script;
      _push(`<!--[-->`);
      if (unref(dataUser)) {
        _push(`<nav class="flex items-center justify-between flex-wrap p-1" style="${ssrRenderStyle({ "background-color": "#73a1a5" })}" data-v-43dd54a7><div class="flex items-center flex-shrink-0 text-white mr-2" data-v-43dd54a7><img${ssrRenderAttr("src", _imports_0)} style="${ssrRenderStyle({ "width": "70px" })}" data-v-43dd54a7></div><div class="block lg:hidden" data-v-43dd54a7><button class="flex items-center px-3 py-2 border rounded text-teal-200 border-teal-400 hover:text-white hover:border-white" data-v-43dd54a7><svg class="fill-current h-3 w-3" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" data-v-43dd54a7><title data-v-43dd54a7>Menu</title><path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" data-v-43dd54a7></path></svg></button></div><div class="w-full block flex-grow lg:flex lg:items-center lg:w-auto" data-v-43dd54a7><div class="text-sm lg:flex-grow mt-0" data-v-43dd54a7><span class="text-[22px]" style="${ssrRenderStyle({ "color": "#514342", "font-size": "22px" })}" data-v-43dd54a7>WReport</span><br data-v-43dd54a7><div class="mt-1 ml-1" data-v-43dd54a7></div></div></div></nav>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(dataUser)) {
        _push(`<div class="p-2" style="${ssrRenderStyle({ "background-color": "#9f763a" })}" data-v-43dd54a7> Usu\xE1rio: ${ssrInterpolate((_a = unref(dataUser)) == null ? void 0 : _a.username)} - ${ssrInterpolate((_b = unref(dataUser)) == null ? void 0 : _b.name)} `);
        if ((_c = unref(dataUser)) == null ? void 0 : _c.products) {
          _push(`<span data-v-43dd54a7>| Produtos: ${ssrInterpolate((_d = unref(dataUser)) == null ? void 0 : _d.products.map((x) => x.name).join(","))}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(` | `);
        _push(ssrRenderComponent(_component_Button, {
          label: "Sair",
          onClick: logOut,
          severity: "contrast",
          text: "",
          class: "p-0"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-43dd54a7"]]);

export { _default as default };
//# sourceMappingURL=default-Bd6nAmY4.mjs.map
