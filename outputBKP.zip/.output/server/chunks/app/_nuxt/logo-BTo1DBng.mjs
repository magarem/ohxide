import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("img/logo.jpeg");

export { _imports_0 as _ };
//# sourceMappingURL=logo-BTo1DBng.mjs.map
