const default_vue_vue_type_style_index_0_scoped_43dd54a7_lang = "a[data-v-43dd54a7]{color:#0a0a3e}";

const defaultStyles_Te15DCUV = [default_vue_vue_type_style_index_0_scoped_43dd54a7_lang];

export { defaultStyles_Te15DCUV as default };
//# sourceMappingURL=default-styles.Te15DCUV.mjs.map
