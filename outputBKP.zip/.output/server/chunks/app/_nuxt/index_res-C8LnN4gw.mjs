import { _ as __nuxt_component_0 } from './Magacrud-7AHrzwIm.mjs';
import { u as useRouter, e as useCookie, f as useAuthStore, s as storeToRefs } from '../server.mjs';
import { mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';
import './toast.esm-BKV23R5p.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-B0Mha2q3.mjs';
import './index.esm-D94sOlgY.mjs';
import './baseicon.esm-Cy2FoSiq.mjs';
import './index.esm-CIJ2jzyK.mjs';
import './index.esm-Do8-MTsn.mjs';
import './index.esm-CubdsAVt.mjs';
import './datatable.esm-D-j0vQ0j.mjs';
import './index.esm-By_6gZSM.mjs';
import './paginator.esm-COCE9vsc.mjs';
import './index.esm-CS7GSScE.mjs';
import './dropdown.esm-BKW57F2o.mjs';
import './index.esm-RNZSX7pe.mjs';
import './index.esm-CdM9LvbI.mjs';
import './overlayeventbus.esm-BcDW6nGW.mjs';
import './virtualscroller.esm-D3fYAFU7.mjs';
import './inputnumber.esm-sm91Uxkg.mjs';
import './button.esm-BF_RjID0.mjs';
import './badge.esm-xka9JVxi.mjs';
import './index.esm-NoH0xj4w.mjs';
import './index.esm-rWWN5_Ww.mjs';
import './inputtext.esm-sApbRJtn.mjs';
import './index.esm-Da6BvuXO.mjs';
import './index.esm-5hwuCqx5.mjs';
import './index.esm-qKGlvuIm.mjs';
import './checkbox.esm-D6d19euv.mjs';
import './radiobutton.esm-BkiUrXcW.mjs';
import './index.esm-Di5PhpuS.mjs';
import './index.esm-DsRQC5Mg.mjs';
import './column.esm-DnTi4bfm.mjs';
import './dialog.esm-CEP5tmQi.mjs';
import './textarea.esm-efz_AWOh.mjs';
import './multiselect.esm-B65gFVu2.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "index_res",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    if (!authenticated.value) {
      router.push("/login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-5" }, _attrs))}><div class="flex">`);
      if (unref(dataUser).status == "root") {
        _push(`<div class="p-1" style="${ssrRenderStyle({ "width": "520px", "max-height": "500px", "margin-right": "20px", "overflow": "auto" })}">`);
        _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/users.json" }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-1" style="${ssrRenderStyle({ "width": "520px", "max-height": "500px", "margin-right": "20px", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/clients.json" }, null, _parent));
      _push(`</div><div class="p-1" style="${ssrRenderStyle({ "width": "500px", "height": "500px", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/reports.json" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index_res.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index_res-C8LnN4gw.mjs.map
