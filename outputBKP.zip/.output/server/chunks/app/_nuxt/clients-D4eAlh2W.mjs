import { _ as __nuxt_component_0 } from './Magacrud-DdUgYriv.mjs';
import { ref, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { d as db, a as clients } from '../server.mjs';
import './toast.esm-Di1eVOG7.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-DLeZPnJV.mjs';
import './index.esm-Bq_5RDja.mjs';
import './baseicon.esm-DeC65o2X.mjs';
import './index.esm-Dg68Fgcm.mjs';
import './index.esm-20913B80.mjs';
import './index.esm-iPGlXaLT.mjs';
import './datatable.esm-CbTG6Zy3.mjs';
import './index.esm-Dp-7Az-D.mjs';
import './paginator.esm-DB7J9-Tz.mjs';
import './index.esm-BZBBIaQ0.mjs';
import './dropdown.esm-BpN7Uydi.mjs';
import './index.esm-dgYu5hQp.mjs';
import './index.esm-jRTkyN61.mjs';
import './overlayeventbus.esm-BmXQsB7e.mjs';
import './virtualscroller.esm-BLdBM0im.mjs';
import './inputnumber.esm-4TYMEebL.mjs';
import './button.esm-sSHPs3W5.mjs';
import './badge.esm-W3lzGlw9.mjs';
import './index.esm-CpjI3C5Z.mjs';
import './index.esm-CB9yXpcc.mjs';
import './inputtext.esm-CY1MGtqk.mjs';
import './index.esm-UuuQr2TF.mjs';
import './index.esm-uE8Xa7qf.mjs';
import './index.esm-DPIQtQ_I.mjs';
import './checkbox.esm-BRtMjhaa.mjs';
import './radiobutton.esm-Dy5m1Rk5.mjs';
import './index.esm-CaP80Tc5.mjs';
import './index.esm-BOTt2uTe.mjs';
import './column.esm-D_9bkwGs.mjs';
import './dialog.esm-DF58ccWn.mjs';
import './textarea.esm-wrpH6U21.mjs';
import './multiselect.esm-Bv8rNR12.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "clients",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    let data = ref([]);
    let data2 = [];
    data.value = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from clients`)), __temp = await __temp, __restore(), __temp);
    console.log("xxxdataxx>", data.value);
    const insertdata = async (data_) => {
      data2 = { ...data_ };
      Object.entries(clients.schema).forEach((item) => {
        if (item[1].type.toLowerCase() == "multiselect") {
          data2[item[0]] = data2[item[0]].join(",");
          console.log("lll>>", data2[item[0]]);
        }
      });
      const ret = await db.insert({
        table: "clients",
        data: data2
      });
      console.log("ret insert:", ret);
    };
    const updatedata = async (data_) => {
      data2 = { ...data_ };
      Object.entries(clients.schema).forEach((item) => {
        if (item[1].type.toLowerCase() == "multiselect") {
          data2[item[0]] = data2[item[0]].join(",");
          console.log("lll>>", data2[item[0]]);
        }
      });
      const ret = await db.update({
        table: "clients",
        data: data2,
        where: "id LIKE '" + data2.id + "'"
      });
      console.log("ret update:", ret);
    };
    const deletedata = async (data3) => {
      if (Array.isArray(data3)) {
        const ret = await db.delete({
          table: "clients",
          where: "id in (" + data3.map((x) => `'${x.id}'`).join(",") + ")"
        });
        console.log("ret update:", ret);
      } else {
        const ret = await db.delete({
          table: "clients",
          where: "id like '" + data3.id + "'"
        });
        console.log("ret update:", ret);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(ssrRenderComponent(_component_Magacrud, mergeProps({
        onInsertdata: insertdata,
        onUpdatedata: updatedata,
        onDeletedata: deletedata,
        schema: unref(clients),
        data: unref(data)
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/clients.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=clients-D4eAlh2W.mjs.map
