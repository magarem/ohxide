const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.mX9XA2bS.mjs').then(interopDefault),
  "pages/download.vue": () => import('./_nuxt/download-styles.C0SNoOW_.mjs').then(interopDefault),
  "pages/admin/login.vue": () => import('./_nuxt/login-styles.C66ywLn7.mjs').then(interopDefault),
  "pages/login.vue": () => import('./_nuxt/login-styles.8nFoljvs.mjs').then(interopDefault),
  "pages/admin/login.vue?vue&type=style&index=0&scoped=b71d23d2&lang.css": () => import('./_nuxt/login-styles.C66ywLn7.mjs').then(interopDefault),
  "pages/login.vue?vue&type=style&index=0&scoped=e75ee519&lang.css": () => import('./_nuxt/login-styles.8nFoljvs.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue?vue&type=style&index=0&scoped=ccd3db62&lang.css": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue?vue&type=style&index=0&scoped=df79c84d&lang.css": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.Te15DCUV.mjs').then(interopDefault),
  "layouts/defaultadmin.vue": () => import('./_nuxt/defaultadmin-styles.BcnDOzPq.mjs').then(interopDefault),
  "layouts/default.vue?vue&type=style&index=0&scoped=43dd54a7&lang.css": () => import('./_nuxt/default-styles.Te15DCUV.mjs').then(interopDefault),
  "layouts/defaultadmin.vue?vue&type=style&index=0&scoped=c1a6b59e&lang.css": () => import('./_nuxt/defaultadmin-styles.CfjQxvY_.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
