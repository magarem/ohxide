import { d as defineEventHandler, g as getQuery } from './nitro/node-server.mjs';
import * as fs from 'node:fs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:url';

const read = defineEventHandler((event) => {
  const query = getQuery(event);
  console.log(111, query);
  const filename = query.filename;
  const read = (filename2) => {
    const data = fs.readFileSync(filename2, "utf-8");
    return data;
  };
  console.log("read_file:", read(filename));
  return read(filename);
});

export { read as default };
//# sourceMappingURL=read.mjs.map
