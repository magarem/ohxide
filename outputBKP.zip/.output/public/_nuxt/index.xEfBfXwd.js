import T from"./inputtext.esm.LqWHgC7I.js";import $ from"./button.esm.4CrTJpPv.js";import D from"./column.esm.CumjPrhI.js";import O from"./datatable.esm.CW3Gl77Z.js";import R from"./card.esm.DST29Bel.js";import{y as B,A as v,B as x,z as P,r as u,V as _,P as S,W as q,n as E,X as F,u as s,c as G,b as o,w as i,H as M,o as Y,d as b,a as I,Y as X}from"./entry.BDCQt7mr.js";import"./basecomponent.esm.BnaG-ql8.js";import"./badge.esm.BeN9gvkA.js";import"./index.esm.CiG9B_Mj.js";import"./baseicon.esm.Bk-6Ho8a.js";import"./paginator.esm.CBJ-C0D-.js";import"./index.esm.Dxms9N9S.js";import"./dropdown.esm.oK-sGTKN.js";import"./index.esm.B-7uas1D.js";import"./index.esm.B_VjgCw7.js";import"./index.esm.DhaFn_EB.js";import"./index.esm.DCQ7_AHb.js";import"./overlayeventbus.esm.DjPoDhSx.js";import"./portal.esm.B2XS6V8Q.js";import"./virtualscroller.esm.DUg1zSu3.js";import"./inputnumber.esm.B77sytFc.js";import"./index.esm.BMWThcTJ.js";import"./index.esm.CAXONVFG.js";import"./index.esm.COmwOyVw.js";import"./index.esm.kaH1U_f7.js";import"./index.esm.DWdVL1yE.js";import"./checkbox.esm.DLA8T_FQ.js";import"./radiobutton.esm.BLk3zg4k.js";import"./index.esm.rSUM7WR_.js";import"./index.esm.0p6e7xPh.js";const j={key:0,class:"m-0"},z={class:"mb-3"},Ue={__name:"index",async setup(H){let n,c;const f=B(),{logUserOut:w}=v(),{authenticated:p}=x(v()),r=P("dataUser");console.log("dataUser---->:",r.value);let g=u(!1);const C=u(null),a=u({year:null,month:null});console.log("authenticated.value:",p.value),p.value||_("/login"),S(()=>{(!r.value||r.value.type!="clients")&&(w(),f.push("/login")),p.value||f.push("/login")}),q({isLoading:!1,columns:[{label:"ID",field:"id",width:"3%",sortable:!0,isKey:!0},{label:"Ano",field:"year",width:"10%",sortable:!0},{label:"Mês",field:"month",width:"10%",sortable:!0},{label:"Título",field:"title",width:"10%",sortable:!0},{label:"Arquivo",field:"file",width:"10%",sortable:!0},{label:"Etiquetas",field:"tags",width:"15%",sortable:!0}],rows:[],totalRecordCount:0,sortable:{order:"id",sort:"asc"}});const A=`
select 
    COUNT(reports.id), 
    reports.year, 
    reports.month, 
    GROUP_CONCAT(reports.name) as nome, 
    GROUP_CONCAT(reports.file) as files, 
    GROUP_CONCAT(products.name) as tags 
from 
    reports, 
    products, 
    clients 
where 
    reports.tag = products.id AND 
    instr(clients.tags, reports.tag) > 0 AND
    clients.id like '${r.value.id}'
GROUP BY 
    reports.year, 
    reports.month 
order by 
    year DESC, 
    month DESC 
`;let h=([n,c]=E(()=>$fetch("/api/dbservices?sql="+A.replace(/\s+/g," ").trim())),n=await n,c(),n);const k=async t=>{const{data:e}=await X("/api/myproxy",{method:"post",body:{year:t.year,month:t.month,client:r.value,files:t.files.split(",").map(m=>"/home/maga/dev/ohxide/upload/"+m).join(",")}},"$PslAyef5YX");console.log("responseData.value//////////>",e.value),e.value&&(g.value=!0,await _(`file/${e.value}`,{open:{target:"_blank"}})),console.log("ret data:",h)},U=F(()=>h.filter(t=>t.year==(a.value.year||t.year)&t.month==(a.value.month||t.month)));return(t,e)=>{const m=T,y=$,d=D,V=O,N=R;return s(r)?(Y(),G("div",j,[o(N,{class:"m-5",style:{width:"80%"}},{title:i(()=>[b("Relatórios")]),content:i(()=>[o(V,{value:s(U),stripedRows:"",tableStyle:"width: 100%",class:"mb-4"},{header:i(()=>[I("div",z,[b(" Buscar: "),o(m,{id:"tableFilter",modelValue:s(a).year,"onUpdate:modelValue":e[0]||(e[0]=l=>s(a).year=l),autofocus:"",placeholder:"Ano",style:{width:"100px"},class:"mx-1"},null,8,["modelValue"]),o(m,{id:"tableFilter",modelValue:s(a).month,"onUpdate:modelValue":e[1]||(e[1]=l=>s(a).month=l),autofocus:"",placeholder:"Mês",style:{width:"100px"},class:"mx-1"},null,8,["modelValue"]),o(y,{icon:"pi pi-times",onClick:e[2]||(e[2]=l=>a.value={}),severity:"danger",text:"",rounded:"","aria-label":"Cancel"})])]),default:i(()=>[o(d,{field:"year",header:"Ano"}),o(d,{field:"month",header:"Mês"}),o(d,{headerStyle:"min-width:10rem;"},{body:i(l=>[o(y,{severity:"secondary",ref_key:"vai",ref:C,type:"button",label:"Download",icon:"pi pi-download",onClick:K=>k(l.data)},null,8,["onClick"])]),_:1})]),_:1},8,["value"])]),_:1})])):M("",!0)}}};export{Ue as default};
