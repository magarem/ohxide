import $ from"./progressspinner.esm.CsgTrgzx.js";import x from"./button.esm.4CrTJpPv.js";import{r as d,y as A,A as _,B,z as S,O as v,n as D,c as R,a as f,t as y,u as t,s as g,H as h,w as b,v as q,U as P,o as p,b as T}from"./entry.BDCQt7mr.js";import{_ as G}from"./logo.B22Okqiv.js";/* empty css                  */import"./basecomponent.esm.BnaG-ql8.js";import"./badge.esm.BeN9gvkA.js";import"./index.esm.CiG9B_Mj.js";import"./baseicon.esm.Bk-6Ho8a.js";const E={class:"text-center",style:{"margin-top":"80px"}},V=f("img",{src:G,style:{width:"200px"}},null,-1),W={__name:"download",async setup(z){let o,m;d("products"),A();const{logUserOut:H,authenticateUser:w}=_(),{authenticated:u}=B(_());S("dataUser");let s=d();const i=v(),l=i.query.year,c=i.query.month,C=i.query.client,e=([o,m]=D(()=>q.get(`select * from clients where id like '${C}'`)),o=await o,m(),o),k=async()=>{console.log({type:"clients",username:e[0].username,password:e[0].password.toString()});const r=await w({type:"clients",username:e[0].username,password:e[0].password.toString()});console.log("r:",r),console.log("authenticated:",u.value),u.value?(console.log("Usuario identificado!!"),O()):console.log("erro login!!")},O=async()=>{const r=`
  select 
      COUNT(reports.id), 
      reports.year, 
      reports.month, 
      GROUP_CONCAT(reports.name) as nome, 
      GROUP_CONCAT(reports.file) as files, 
      GROUP_CONCAT(products.name) as tags 
  from 
      reports, 
      products, 
      clients 
  where 
      reports.tag = products.id AND 
      instr(clients.tags, reports.tag) > 0 AND
      clients.id like '${e[0].id}'
  GROUP BY 
      reports.year, 
      reports.month 
  order by 
      year DESC, 
      month DESC 
`;let a=await $fetch("/api/dbservices?sql="+r.replace(/\s+/g," ").trim());a=a.filter(n=>n.year==l&&n.month==c),s.value=await $fetch(`/api/shell?year=${l}&month=${c}&client=${JSON.stringify(e[0])}&files=${a[0].files}`)};return k(),(r,a)=>{const n=$,N=x,U=P("router-link");return p(),R("div",E,[V,f("h3",null,"Download relatório "+y(t(c))+"/"+y(t(l)),1),t(s)?h("",!0):(p(),g(n,{key:0})),t(s)?(p(),g(U,{key:1,to:"/upload/reports/"+t(s),target:"_blank",rel:"noopener"},{default:b(()=>[T(N,{style:{"margin-top":"20px"},label:"Baixar relatório",icon:"pi pi-cloud-download"})]),_:1},8,["to"])):h("",!0)])}}};export{W as default};
