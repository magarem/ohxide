import B from"./inputtext.esm.BZd1YjaF.js";import R from"./button.esm.UvV8lr3A.js";import x from"./column.esm.DFKTYQbG.js";import E from"./datatable.esm.B73GN6ZB.js";import P from"./card.esm.CLqQUQhI.js";import{z as S,B as C,C as q,A as F,r as m,W as k,Q as G,X as M,n as I,Y,u as r,c,b as o,w as p,I as X,o as f,a as h,d as v,Z as j}from"./entry.wLs2yeIN.js";import"./basecomponent.esm.CKDJQrJ0.js";import"./badge.esm.DufjM3rl.js";import"./index.esm.JWQWjOjL.js";import"./baseicon.esm.BvAfCAO7.js";import"./paginator.esm.CU-sznqi.js";import"./index.esm.BFX7LB5f.js";import"./dropdown.esm.C8khLBni.js";import"./index.esm.BaDhg6XB.js";import"./index.esm.CeewyYlY.js";import"./index.esm.j6vlDZ2w.js";import"./index.esm.ez7U3KwL.js";import"./overlayeventbus.esm.DEphjrQW.js";import"./portal.esm.DdF7qek_.js";import"./virtualscroller.esm.BdYdZEC_.js";import"./inputnumber.esm.DpCJNdH3.js";import"./index.esm.Bm0iwAlF.js";import"./index.esm.BPPGmhsi.js";import"./index.esm.DS0b7uoV.js";import"./index.esm.TXrmyluk.js";import"./index.esm.CaeVaVPf.js";import"./checkbox.esm.t1zSKFmX.js";import"./radiobutton.esm.CMDfee90.js";import"./index.esm.CDX1JcWJ.js";import"./index.esm.BNWs2lhp.js";const z={key:0,class:"m-0"},K={key:0},L={class:"mb-3"},Q={key:1,class:"m-5"},W=h("h2",null,[v("Acesso suspenso"),h("br"),v(" Entre em contato com o administrador")],-1),Z=[W],$e={__name:"index",async setup(H){let i,_;const y=S(),{logUserOut:A}=C(),{authenticated:n}=q(C()),a=F("dataUser");console.log("dataUser---->:",a.value);let U=m(!1);const N=m(null),b=m(!1),s=m({year:null,month:null});console.log("authenticated.value:",n.value),n.value||k("/login"),G(()=>{(!a.value||a.value.type!="clients")&&(A(),y.push("/login")),n.value&&a.value.status=="ativo"&&(b.value=!0),n.value||y.push("/login")}),M({isLoading:!1,columns:[{label:"ID",field:"id",width:"3%",sortable:!0,isKey:!0},{label:"Ano",field:"year",width:"10%",sortable:!0},{label:"Mês",field:"month",width:"10%",sortable:!0},{label:"Título",field:"title",width:"10%",sortable:!0},{label:"Arquivo",field:"file",width:"10%",sortable:!0},{label:"Etiquetas",field:"tags",width:"15%",sortable:!0}],rows:[],totalRecordCount:0,sortable:{order:"id",sort:"asc"}});const O=`
select 
    COUNT(reports.id), 
    reports.year, 
    reports.month, 
    GROUP_CONCAT(reports.name) as nome, 
    GROUP_CONCAT(reports.file) as files, 
    GROUP_CONCAT(products.name) as tags 
from 
    reports, 
    products, 
    clients 
where 
    reports.tag = products.id AND 
    instr(clients.tags, reports.tag) > 0 AND
    clients.id like '${a.value.id}'
GROUP BY 
    reports.year, 
    reports.month 
order by 
    year DESC, 
    month DESC 
`;let w=([i,_]=I(()=>$fetch("/api/dbservices?sql="+O.replace(/\s+/g," ").trim())),i=await i,_(),i);const T=async t=>{const{data:e}=await j("/api/myproxy",{method:"post",body:{year:t.year,month:t.month,client:a.value,files:t.files.split(",").map(d=>"/home/maga/dev/ohxide/upload/"+d).join(",")}},"$PslAyef5YX");console.log("responseData.value//////////>",e.value),e.value&&(U.value=!0,await k(`file/${e.value}`,{open:{target:"_blank"}})),console.log("ret data:",w)},V=Y(()=>w.filter(t=>t.year==(s.value.year||t.year)&t.month==(s.value.month||t.month)));return(t,e)=>{const d=B,g=R,u=x,$=E,D=P;return r(a)?(f(),c("div",z,[r(b)?(f(),c("div",K,[o(D,{class:"m-5",style:{width:"80%"}},{content:p(()=>[o($,{value:r(V),stripedRows:"",tableStyle:"width: 100%",class:"mb-4"},{header:p(()=>[h("div",L,[v(" Buscar: "),o(d,{id:"tableFilter",modelValue:r(s).year,"onUpdate:modelValue":e[0]||(e[0]=l=>r(s).year=l),autofocus:"",placeholder:"Ano",style:{width:"100px"},class:"mx-1"},null,8,["modelValue"]),o(d,{id:"tableFilter",modelValue:r(s).month,"onUpdate:modelValue":e[1]||(e[1]=l=>r(s).month=l),autofocus:"",placeholder:"Mês",style:{width:"100px"},class:"mx-1"},null,8,["modelValue"]),o(g,{icon:"pi pi-times",onClick:e[2]||(e[2]=l=>s.value={}),severity:"danger",text:"",rounded:"","aria-label":"Cancel"})])]),default:p(()=>[o(u,{field:"year",header:"Ano"}),o(u,{field:"month",header:"Mês"}),o(u,{headerStyle:"min-width:10rem;"},{body:p(l=>[o(g,{severity:"secondary",ref_key:"vai",ref:N,type:"button",label:"Download",icon:"pi pi-download",onClick:J=>T(l.data)},null,8,["onClick"])]),_:1})]),_:1},8,["value"])]),_:1})])):(f(),c("div",Q,Z))])):X("",!0)}}};export{$e as default};
