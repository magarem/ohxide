import $ from"./progressspinner.esm.hPA-Rd4c.js";import x from"./button.esm.UvV8lr3A.js";import{r as d,z as A,B as _,C as B,A as S,P as D,n as R,c as b,a as f,t as y,u as t,q as g,I as h,w as q,s as v,V as P,o as p,b as T}from"./entry.wLs2yeIN.js";import{_ as G}from"./logo.DM0okKX-.js";/* empty css                  */import"./basecomponent.esm.CKDJQrJ0.js";import"./badge.esm.DufjM3rl.js";import"./index.esm.JWQWjOjL.js";import"./baseicon.esm.BvAfCAO7.js";const V={class:"text-center",style:{"margin-top":"80px"}},E=f("img",{src:G,style:{width:"200px"}},null,-1),W={__name:"download",async setup(z){let o,m;d("products"),A();const{logUserOut:I,authenticateUser:w}=_(),{authenticated:u}=B(_());S("dataUser");let s=d();const i=D(),l=i.query.year,c=i.query.month,C=i.query.client,e=([o,m]=R(()=>v.get(`select * from clients where id like '${C}'`)),o=await o,m(),o),k=async()=>{console.log({type:"clients",username:e[0].username,password:e[0].password.toString()});const r=await w({type:"clients",username:e[0].username,password:e[0].password.toString()});console.log("r:",r),console.log("authenticated:",u.value),u.value?(console.log("Usuario identificado!!"),N()):console.log("erro login!!")},N=async()=>{const r=`
  select 
      COUNT(reports.id), 
      reports.year, 
      reports.month, 
      GROUP_CONCAT(reports.name) as nome, 
      GROUP_CONCAT(reports.file) as files, 
      GROUP_CONCAT(products.name) as tags 
  from 
      reports, 
      products, 
      clients 
  where 
      reports.tag = products.id AND 
      instr(clients.tags, reports.tag) > 0 AND
      clients.id like '${e[0].id}'
  GROUP BY 
      reports.year, 
      reports.month 
  order by 
      year DESC, 
      month DESC 
`;let a=await $fetch("/api/dbservices?sql="+r.replace(/\s+/g," ").trim());a=a.filter(n=>n.year==l&&n.month==c),s.value=await $fetch(`/api/shell?year=${l}&month=${c}&client=${JSON.stringify(e[0])}&files=${a[0].files}`)};return k(),(r,a)=>{const n=$,O=x,U=P("router-link");return p(),b("div",V,[E,f("h3",null,"Download relatório "+y(t(c))+"/"+y(t(l)),1),t(s)?h("",!0):(p(),g(n,{key:0})),t(s)?(p(),g(U,{key:1,to:"/upload/reports/"+t(s),target:"_blank",rel:"noopener"},{default:q(()=>[T(O,{style:{"margin-top":"20px"},label:"Baixar relatório",icon:"pi pi-cloud-download"})]),_:1},8,["to"])):h("",!0)])}}};export{W as default};
