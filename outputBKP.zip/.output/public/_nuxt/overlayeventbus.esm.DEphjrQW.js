import{az as r}from"./entry.wLs2yeIN.js";var e=r();export{e as O};
