import { d as defineEventHandler, g as getQuery } from './nitro/node-server.mjs';
import shell$1 from 'shelljs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

const shell = defineEventHandler((event) => {
  const req = getQuery(event);
  const client = JSON.parse(req.client);
  console.log("req.client:", client);
  console.log("req.year:", req.year);
  console.log("req.month:", req.month);
  console.log("req.files:", req.files);
  async function merge_pdfs(pdfFiles, outputFile2) {
    await shell$1.exec("pwd");
    console.log(`deno run -A /home/maga/dev/ohxide/deno3.ts ${client.id} ${req.year} ${req.month} '${client.empresa}' ${pdfFiles}`);
    const { stdout, stderr } = await shell$1.exec(`deno run -A /home/maga/dev/ohxide/deno.ts ${client.id} ${req.year} ${req.month} '${client.empresa}' ${pdfFiles}`);
    console.log("stdout:", stdout);
    console.log("stderr:", stderr);
    return stdout;
  }
  return merge_pdfs(req.files.split(",").map((x) => "/home/maga/dev/ohxide/upload/" + x).join(","));
});

export { shell as default };
//# sourceMappingURL=shell.mjs.map
