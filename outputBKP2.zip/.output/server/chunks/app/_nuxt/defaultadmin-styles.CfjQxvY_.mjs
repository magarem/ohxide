import { d as defaultadmin_vue_vue_type_style_index_0_scoped_c1a6b59e_lang } from './defaultadmin-styles-2.mjs-C6m4q-rq.mjs';

const defaultadminStyles_CfjQxvY_ = [defaultadmin_vue_vue_type_style_index_0_scoped_c1a6b59e_lang];

export { defaultadminStyles_CfjQxvY_ as default };
//# sourceMappingURL=defaultadmin-styles.CfjQxvY_.mjs.map
