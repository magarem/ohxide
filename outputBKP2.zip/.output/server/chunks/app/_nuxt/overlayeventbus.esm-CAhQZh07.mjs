import { p as primebus } from '../server.mjs';

var OverlayEventBus = primebus();

export { OverlayEventBus as O };
//# sourceMappingURL=overlayeventbus.esm-CAhQZh07.mjs.map
