import { ref, withAsyncContext, unref, useSSRContext } from 'vue';
import { ssrInterpolate } from 'vue/server-renderer';
import { d as db } from './db_cmds-0OAE-mPK.mjs';

const _sfc_main = {
  __name: "teste2",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    let data = ref([]);
    let tela = ref([]);
    let columns_;
    let values_;
    let insertSQL = [];
    data.value = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from clients`)), __temp = await __temp, __restore(), __temp);
    data.value.map(
      (x, index) => {
        columns_ = "(" + Object.keys(x).join(",") + ")";
        values_ = "(" + Object.values(x).map((y) => {
          if (y == "null") {
            return y;
          } else {
            if (y == "2224") {
              return "'top'";
            } else {
              return "'" + y + "'";
            }
          }
        }).join(",") + ")";
        insertSQL[index] = `
         INSERT INTO clients
         ${columns_}
         VALUES
         ${values_};
      `;
      }
    );
    console.log(insertSQL);
    let sql = `
   
   BEGIN TRANSACTION;

   DELETE FROM clients;
  
   ${insertSQL.join("")}

   COMMIT;
  `;
    console.log(sql);
    let ret = ([__temp, __restore] = withAsyncContext(() => db.exec(sql)), __temp = await __temp, __restore(), __temp);
    console.log("ret:", ret);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h1>teste</h1> ${ssrInterpolate(unref(tela))}<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/teste2.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=teste2-BJgAsTdc.mjs.map
