import script from './card.esm-CPjHNJNk.mjs';
import script$1 from './datatable.esm-HXzgo9_H.mjs';
import script$2 from './inputtext.esm-CNretVO-.mjs';
import script$3 from './button.esm-B68Sl5s9.mjs';
import script$4 from './column.esm-aEFxrzTH.mjs';
import { u as useRouter, b as useAuthStore, s as storeToRefs, a as useCookie, n as navigateTo, g as useFetch } from '../server.mjs';
import { ref, withAsyncContext, computed, unref, mergeProps, withCtx, createVNode, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './basecomponent.esm-BajCsLnl.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './baseicon.esm-g6sGMQlE.mjs';
import './index.esm-Bbz8MpsA.mjs';
import './paginator.esm-BDwaISpD.mjs';
import './index.esm-ChjpqW7a.mjs';
import './dropdown.esm-CCfe8YJb.mjs';
import './index.esm-BxeFIN3p.mjs';
import './index.esm-BltLHj-F.mjs';
import './index.esm-CpyHmxAn.mjs';
import './index.esm-B_U5wsuI.mjs';
import './overlayeventbus.esm-CAhQZh07.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './virtualscroller.esm-CnWKhCV9.mjs';
import './inputnumber.esm-CHAH-cYR.mjs';
import './index.esm-Dos0gWj2.mjs';
import './index.esm-il7tQQCv.mjs';
import './badge.esm-C-rTx-ix.mjs';
import './index.esm-Qq84Bwnv.mjs';
import './index.esm-C3HxEmuK.mjs';
import './index.esm-DvNLCUnP.mjs';
import './checkbox.esm-DeuztAtD.mjs';
import './radiobutton.esm-DEnD9jJz.mjs';
import './index.esm-DDOrdXLZ.mjs';
import './index.esm-Bwx2iWmn.mjs';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRouter();
    useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    const dataUser = useCookie("dataUser");
    let flag_mostra_link = ref(false);
    const vai = ref(null);
    const accessOk = ref(false);
    const tableFilter = ref({
      year: null,
      month: null
    });
    console.log("authenticated.value:", authenticated.value);
    if (!authenticated.value) {
      navigateTo("/login");
    }
    const sql = `
  select 
      COUNT(reports.id), reports.year, reports.month, 
      GROUP_CONCAT(reports.name) as nome, 
      GROUP_CONCAT(reports.file) as files, 
      GROUP_CONCAT(products.name) as tags 
  from 
      reports, products, clients 
  where 
      reports.tag = products.id AND 
      instr(clients.tags, reports.tag) > 0 AND
      clients.id like '${dataUser.value.id}'
  GROUP BY 
      reports.year, reports.month 
  order by 
      year DESC, month DESC 
`;
    let data = ([__temp, __restore] = withAsyncContext(() => $fetch("/api/dbservices?sql=" + sql.replace(/\s+/g, " ").trim())), __temp = await __temp, __restore(), __temp);
    const merge = async (xx) => {
      const { data: responseData } = await useFetch(`/api/myproxy`, {
        method: "post",
        body: {
          year: xx.year,
          month: xx.month,
          client: dataUser.value,
          files: xx.files.split(",").map((x) => "/home/maga/dev/ohxide/upload/" + x).join(",")
        }
      }, "$PslAyef5YX");
      console.log("responseData.value//////////>", responseData.value);
      if (responseData.value) {
        flag_mostra_link.value = true;
        await navigateTo(`file/${responseData.value}`, {
          open: {
            target: "_blank"
          }
        });
      }
      console.log("ret data:", data);
    };
    const aaa = computed(() => {
      return data.filter((x) => x.year == (tableFilter.value.year || x.year) & x.month == (tableFilter.value.month || x.month));
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Card = script;
      const _component_DataTable = script$1;
      const _component_InputText = script$2;
      const _component_Button = script$3;
      const _component_Column = script$4;
      if (unref(dataUser)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "m-0" }, _attrs))}>`);
        if (unref(accessOk)) {
          _push(`<div>`);
          _push(ssrRenderComponent(_component_Card, {
            class: "m-5",
            style: { "width": "80%" }
          }, {
            content: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(ssrRenderComponent(_component_DataTable, {
                  value: unref(aaa),
                  stripedRows: "",
                  tableStyle: "width: 100%",
                  class: "mb-4"
                }, {
                  header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(`<div class="mb-3"${_scopeId2}> Buscar: `);
                      _push3(ssrRenderComponent(_component_InputText, {
                        id: "tableFilter",
                        modelValue: unref(tableFilter).year,
                        "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                        autofocus: "",
                        placeholder: "Ano",
                        style: { "width": "100px" },
                        class: "mx-1"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_component_InputText, {
                        id: "tableFilter",
                        modelValue: unref(tableFilter).month,
                        "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                        autofocus: "",
                        placeholder: "M\xEAs",
                        style: { "width": "100px" },
                        class: "mx-1"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_component_Button, {
                        icon: "pi pi-times",
                        onClick: ($event) => tableFilter.value = {},
                        severity: "danger",
                        text: "",
                        rounded: "",
                        "aria-label": "Cancel"
                      }, null, _parent3, _scopeId2));
                      _push3(`</div>`);
                    } else {
                      return [
                        createVNode("div", { class: "mb-3" }, [
                          createTextVNode(" Buscar: "),
                          createVNode(_component_InputText, {
                            id: "tableFilter",
                            modelValue: unref(tableFilter).year,
                            "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                            autofocus: "",
                            placeholder: "Ano",
                            style: { "width": "100px" },
                            class: "mx-1"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_InputText, {
                            id: "tableFilter",
                            modelValue: unref(tableFilter).month,
                            "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                            autofocus: "",
                            placeholder: "M\xEAs",
                            style: { "width": "100px" },
                            class: "mx-1"
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode(_component_Button, {
                            icon: "pi pi-times",
                            onClick: ($event) => tableFilter.value = {},
                            severity: "danger",
                            text: "",
                            rounded: "",
                            "aria-label": "Cancel"
                          }, null, 8, ["onClick"])
                        ])
                      ];
                    }
                  }),
                  default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      _push3(ssrRenderComponent(_component_Column, {
                        field: "year",
                        header: "Ano"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_component_Column, {
                        field: "month",
                        header: "M\xEAs"
                      }, null, _parent3, _scopeId2));
                      _push3(ssrRenderComponent(_component_Column, { headerStyle: "min-width:10rem;" }, {
                        body: withCtx((slotProps, _push4, _parent4, _scopeId3) => {
                          if (_push4) {
                            _push4(ssrRenderComponent(_component_Button, {
                              severity: "secondary",
                              ref_key: "vai",
                              ref: vai,
                              type: "button",
                              label: "Download",
                              icon: "pi pi-download",
                              onClick: ($event) => merge(slotProps.data)
                            }, null, _parent4, _scopeId3));
                          } else {
                            return [
                              createVNode(_component_Button, {
                                severity: "secondary",
                                ref_key: "vai",
                                ref: vai,
                                type: "button",
                                label: "Download",
                                icon: "pi pi-download",
                                onClick: ($event) => merge(slotProps.data)
                              }, null, 8, ["onClick"])
                            ];
                          }
                        }),
                        _: 1
                      }, _parent3, _scopeId2));
                    } else {
                      return [
                        createVNode(_component_Column, {
                          field: "year",
                          header: "Ano"
                        }),
                        createVNode(_component_Column, {
                          field: "month",
                          header: "M\xEAs"
                        }),
                        createVNode(_component_Column, { headerStyle: "min-width:10rem;" }, {
                          body: withCtx((slotProps) => [
                            createVNode(_component_Button, {
                              severity: "secondary",
                              ref_key: "vai",
                              ref: vai,
                              type: "button",
                              label: "Download",
                              icon: "pi pi-download",
                              onClick: ($event) => merge(slotProps.data)
                            }, null, 8, ["onClick"])
                          ]),
                          _: 1
                        })
                      ];
                    }
                  }),
                  _: 1
                }, _parent2, _scopeId));
              } else {
                return [
                  createVNode(_component_DataTable, {
                    value: unref(aaa),
                    stripedRows: "",
                    tableStyle: "width: 100%",
                    class: "mb-4"
                  }, {
                    header: withCtx(() => [
                      createVNode("div", { class: "mb-3" }, [
                        createTextVNode(" Buscar: "),
                        createVNode(_component_InputText, {
                          id: "tableFilter",
                          modelValue: unref(tableFilter).year,
                          "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                          autofocus: "",
                          placeholder: "Ano",
                          style: { "width": "100px" },
                          class: "mx-1"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_InputText, {
                          id: "tableFilter",
                          modelValue: unref(tableFilter).month,
                          "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                          autofocus: "",
                          placeholder: "M\xEAs",
                          style: { "width": "100px" },
                          class: "mx-1"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_Button, {
                          icon: "pi pi-times",
                          onClick: ($event) => tableFilter.value = {},
                          severity: "danger",
                          text: "",
                          rounded: "",
                          "aria-label": "Cancel"
                        }, null, 8, ["onClick"])
                      ])
                    ]),
                    default: withCtx(() => [
                      createVNode(_component_Column, {
                        field: "year",
                        header: "Ano"
                      }),
                      createVNode(_component_Column, {
                        field: "month",
                        header: "M\xEAs"
                      }),
                      createVNode(_component_Column, { headerStyle: "min-width:10rem;" }, {
                        body: withCtx((slotProps) => [
                          createVNode(_component_Button, {
                            severity: "secondary",
                            ref_key: "vai",
                            ref: vai,
                            type: "button",
                            label: "Download",
                            icon: "pi pi-download",
                            onClick: ($event) => merge(slotProps.data)
                          }, null, 8, ["onClick"])
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["value"])
                ];
              }
            }),
            _: 1
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<div class="m-5"><h2>Acesso suspenso<br> Entre em contato com o administrador</h2></div>`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-DD2hdMXj.mjs.map
