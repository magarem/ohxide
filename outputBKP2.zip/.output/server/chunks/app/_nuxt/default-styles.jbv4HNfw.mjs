const default_vue_vue_type_style_index_0_scoped_7ea342d1_lang = "a[data-v-7ea342d1]{color:#0a0a3e}.title[data-v-7ea342d1]{font-weight:700}";

const defaultStyles_jbv4HNfw = [default_vue_vue_type_style_index_0_scoped_7ea342d1_lang];

export { defaultStyles_jbv4HNfw as default };
//# sourceMappingURL=default-styles.jbv4HNfw.mjs.map
