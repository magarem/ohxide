import script from './toast.esm-BKw76SSr.mjs';
import script$1 from './datatable.esm-HXzgo9_H.mjs';
import script$2 from './button.esm-B68Sl5s9.mjs';
import script$3 from './inputtext.esm-CNretVO-.mjs';
import script$4 from './column.esm-aEFxrzTH.mjs';
import script$5 from './dialog.esm-BXPj_NAl.mjs';
import script$6 from './textarea.esm-EZLfQ2Fk.mjs';
import script$7 from './dropdown.esm-CCfe8YJb.mjs';
import script$8 from './multiselect.esm-Dzm6n2Nu.mjs';
import { useSSRContext, ref, unref, mergeProps, isRef, withCtx, createVNode, toDisplayString, openBlock, createBlock, createCommentVNode, Fragment, renderList, withDirectives, vShow, withModifiers, createTextVNode } from 'vue';
import { d as useToast, e as useRoute, f as useAsyncData } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderStyle, ssrInterpolate, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Magacrud",
  __ssrInlineRender: true,
  props: ["schema", "data", "source2", "reorder"],
  emits: ["insertdata", "updatedata", "deletedata", "updateorder"],
  setup(__props, { emit: __emit }) {
    const toast = useToast();
    const dataItemDialog = ref(false);
    const deleteDataItemDialog = ref(false);
    const deleteDataItemsDialog = ref(false);
    const selectedDataItems = ref(null);
    const dt = ref(null);
    const filters = ref({});
    const submitted = ref(false);
    const dataItem = ref({});
    ref(null);
    const dataTitle = ref(null);
    const dataDesc = ref(null);
    const dataGridColumns = ref([]);
    ref([]);
    ref(null);
    ref(null);
    ref([]);
    useRoute();
    const props = __props;
    const emit = __emit;
    props.schema;
    const data = ref();
    props.source2;
    const files = ref();
    const submitBtn = ref(null);
    const onRowReorder = (event) => {
      data.value = event.value;
      emit("updateorder", data.value);
      toast.add({ severity: "success", summary: "Rows Reordered", life: 3e3 });
    };
    const openNew = () => {
      dataItem.value = {};
      submitted.value = false;
      dataItemDialog.value = true;
    };
    const hideDialog = () => {
      dataItemDialog.value = false;
      submitted.value = false;
    };
    const saveData = async () => {
      if (dataItem.value.id) {
        data.value[findIndexById(dataItem.value.id)] = dataItem.value;
        toast.add({ severity: "success", summary: "Successful", detail: "DataItem Updated", life: 3e3 });
        emit("updatedata", data.value[findIndexById(dataItem.value.id)]);
        dataItem.value = {};
      } else {
        dataItem.value.id = createId();
        data.value.push(dataItem.value);
        toast.add({ severity: "success", summary: "Successful", detail: "DataItem Created", life: 3e3 });
        emit("insertdata", dataItem.value);
        dataItem.value = {};
      }
      dataItemDialog.value = false;
    };
    const editDataItem = (editDataItem2) => {
      dataItem.value = { ...editDataItem2 };
      dataItemDialog.value = true;
    };
    const confirmDeleteDataItem = (editDataItem2) => {
      dataItem.value = editDataItem2;
      deleteDataItemDialog.value = true;
    };
    const deleteData = async () => {
      data.value = data.value.filter((val) => val.id !== dataItem.value.id);
      deleteDataItemDialog.value = false;
      emit("deletedata", dataItem.value);
      dataItem.value = {};
      toast.add({ severity: "success", summary: "Successful", detail: "DataItem Deleted", life: 3e3 });
    };
    const findIndexById = (id) => {
      let index = -1;
      for (let i = 0; i < data.value.length; i++) {
        if (data.value[i].id === id) {
          index = i;
          break;
        }
      }
      return index;
    };
    const createId = () => {
      let id = "";
      const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      for (let i = 0; i < 5; i++) {
        id += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      return id;
    };
    const confirmDeleteSelected = () => {
      deleteDataItemsDialog.value = true;
    };
    const deleteSelectedDataItems = () => {
      data.value = data.value.filter((val) => !selectedDataItems.value.includes(val));
      deleteDataItemsDialog.value = false;
      console.log(selectedDataItems.value);
      emit("deletedata", selectedDataItems.value);
      selectedDataItems.value = null;
      toast.add({ severity: "success", summary: "Successful", detail: "DataItems Deleted", life: 3e3 });
    };
    function handleFile(e) {
      files.value = e.target.files;
      e.target.files[0];
    }
    async function handleImageUpload(x) {
      try {
        const fd = new FormData();
        Array.from(files.value).map((file, index) => {
          fd.append("photo", file);
          console.log("file---->", file.name);
          dataItem.value[x] = file.name;
        });
        const { data: data2, pending, error, refresh } = await useAsyncData(
          "data",
          () => $fetch(
            "/api/upload?dir=reports",
            {
              method: "POST",
              body: fd
            }
          )
        );
        console.log("data from backend is ", data2);
      } catch (error) {
        console.log(error);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Toast = script;
      const _component_DataTable = script$1;
      const _component_Button = script$2;
      const _component_InputText = script$3;
      const _component_Column = script$4;
      const _component_Dialog = script$5;
      const _component_Textarea = script$6;
      const _component_Dropdown = script$7;
      const _component_MultiSelect = script$8;
      if (unref(data)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid" }, _attrs))}><div class="col-12"><div class="card">`);
        _push(ssrRenderComponent(_component_Toast, null, null, _parent));
        _push(ssrRenderComponent(_component_DataTable, {
          ref_key: "dt",
          ref: dt,
          value: unref(data),
          selection: unref(selectedDataItems),
          "onUpdate:selection": ($event) => isRef(selectedDataItems) ? selectedDataItems.value = $event : null,
          onRowReorder,
          dataKey: "id",
          paginator: true,
          rows: 4,
          filters: unref(filters),
          class: "p-0",
          stripedRows: "",
          paginatorTemplate: "FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown",
          rowsPerPageOptions: [5, 10, 25],
          currentPageReportTemplate: "Mostrando {first} at\xE9 {last} de {totalRecords} itens",
          responsiveLayout: "scroll"
        }, {
          header: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex flex-column md:flex-row md:justify-content-between md:align-items-center"${_scopeId}><div class="grid grid-cols-3 gap-6"${_scopeId}><div${_scopeId}><h4 style="${ssrRenderStyle({ "margin-bottom": "-10px" })}"${_scopeId}>${ssrInterpolate(unref(dataTitle))}</h4><h6${_scopeId}>${ssrInterpolate(unref(dataDesc))}</h6></div><div${_scopeId}><div class="mt-3"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Button, {
                label: "Novo",
                icon: "pi pi-plus",
                class: "p-button-success mr-2",
                onClick: openNew
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Excluir",
                icon: "pi pi-trash",
                class: "p-button-danger",
                onClick: confirmDeleteSelected,
                disabled: !unref(selectedDataItems) || !unref(selectedDataItems).length
              }, null, _parent2, _scopeId));
              _push2(`</div></div><div${_scopeId}><span class="block mt-3 md:mt-3 p-input-icon-left"${_scopeId}><i class="pi pi-search mr-2"${_scopeId}></i>`);
              _push2(ssrRenderComponent(_component_InputText, {
                modelValue: unref(filters)["global"].value,
                "onUpdate:modelValue": ($event) => unref(filters)["global"].value = $event,
                placeholder: "Buscar..."
              }, null, _parent2, _scopeId));
              _push2(`</span></div></div></div>`);
            } else {
              return [
                createVNode("div", { class: "flex flex-column md:flex-row md:justify-content-between md:align-items-center" }, [
                  createVNode("div", { class: "grid grid-cols-3 gap-6" }, [
                    createVNode("div", null, [
                      createVNode("h4", { style: { "margin-bottom": "-10px" } }, toDisplayString(unref(dataTitle)), 1),
                      createVNode("h6", null, toDisplayString(unref(dataDesc)), 1)
                    ]),
                    createVNode("div", null, [
                      createVNode("div", { class: "mt-3" }, [
                        createVNode(_component_Button, {
                          label: "Novo",
                          icon: "pi pi-plus",
                          class: "p-button-success mr-2",
                          onClick: openNew
                        }),
                        createVNode(_component_Button, {
                          label: "Excluir",
                          icon: "pi pi-trash",
                          class: "p-button-danger",
                          onClick: confirmDeleteSelected,
                          disabled: !unref(selectedDataItems) || !unref(selectedDataItems).length
                        }, null, 8, ["disabled"])
                      ])
                    ]),
                    createVNode("div", null, [
                      createVNode("span", { class: "block mt-3 md:mt-3 p-input-icon-left" }, [
                        createVNode("i", { class: "pi pi-search mr-2" }),
                        createVNode(_component_InputText, {
                          modelValue: unref(filters)["global"].value,
                          "onUpdate:modelValue": ($event) => unref(filters)["global"].value = $event,
                          placeholder: "Buscar..."
                        }, null, 8, ["modelValue", "onUpdate:modelValue"])
                      ])
                    ])
                  ])
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              if (__props.reorder) {
                _push2(ssrRenderComponent(_component_Column, {
                  rowReorder: "",
                  headerStyle: "width: 3rem",
                  reorderableColumn: false
                }, null, _parent2, _scopeId));
              } else {
                _push2(`<!---->`);
              }
              _push2(ssrRenderComponent(_component_Column, {
                selectionMode: "multiple",
                headerStyle: "width: 3rem"
              }, null, _parent2, _scopeId));
              _push2(`<!--[-->`);
              ssrRenderList(unref(dataGridColumns), (item) => {
                _push2(ssrRenderComponent(_component_Column, {
                  key: item.id,
                  field: item.id,
                  header: item.label,
                  sortable: true,
                  headerStyle: "width:14%; min-width:10rem;"
                }, {
                  body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                    if (_push3) {
                      if (item.type.toLowerCase() == "upload") {
                        _push3(`<div${_scopeId2}><a${ssrRenderAttr("href", "/upload/" + slotProps.data[item.id])}${_scopeId2}>${ssrInterpolate(slotProps.data[item.id])}</a></div>`);
                      } else {
                        _push3(`<!---->`);
                      }
                      if (["string", "integer"].includes(item.type.toLowerCase())) {
                        _push3(`<div${_scopeId2}>${ssrInterpolate(slotProps.data[item.id])}</div>`);
                      } else {
                        _push3(`<!---->`);
                      }
                      if (["select"].includes(item.type.toLowerCase())) {
                        _push3(`<div${_scopeId2}>${ssrInterpolate(item.options.find((x) => x.code == slotProps.data[item.id]).name)}</div>`);
                      } else {
                        _push3(`<!---->`);
                      }
                      if (["multiselect"].includes(item.type.toLowerCase())) {
                        _push3(`<div${_scopeId2}>${ssrInterpolate(slotProps.data[item.id].map(
                          (t) => item.options.find((x) => x.code == t) ? item.options.find((x) => x.code == t).name : "-"
                        ).join(", "))}</div>`);
                      } else {
                        _push3(`<!---->`);
                      }
                      if (Object.values(item)[0].type == "upload") {
                        _push3(`<div${_scopeId2}><a${ssrRenderAttr("href", "/file/" + slotProps.data[item[0]])} target="_blank"${_scopeId2}>${ssrInterpolate(slotProps.data[item[0]])}</a></div>`);
                      } else {
                        _push3(`<!---->`);
                      }
                    } else {
                      return [
                        item.type.toLowerCase() == "upload" ? (openBlock(), createBlock("div", { key: 0 }, [
                          createVNode("a", {
                            href: "/upload/" + slotProps.data[item.id]
                          }, toDisplayString(slotProps.data[item.id]), 9, ["href"])
                        ])) : createCommentVNode("", true),
                        ["string", "integer"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock("div", { key: 1 }, toDisplayString(slotProps.data[item.id]), 1)) : createCommentVNode("", true),
                        ["select"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock("div", { key: 2 }, toDisplayString(item.options.find((x) => x.code == slotProps.data[item.id]).name), 1)) : createCommentVNode("", true),
                        ["multiselect"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock("div", { key: 3 }, toDisplayString(slotProps.data[item.id].map(
                          (t) => item.options.find((x) => x.code == t) ? item.options.find((x) => x.code == t).name : "-"
                        ).join(", ")), 1)) : createCommentVNode("", true),
                        Object.values(item)[0].type == "upload" ? (openBlock(), createBlock("div", { key: 4 }, [
                          createVNode("a", {
                            href: "/file/" + slotProps.data[item[0]],
                            target: "_blank"
                          }, toDisplayString(slotProps.data[item[0]]), 9, ["href"])
                        ])) : createCommentVNode("", true)
                      ];
                    }
                  }),
                  _: 2
                }, _parent2, _scopeId));
              });
              _push2(`<!--]-->`);
              _push2(ssrRenderComponent(_component_Column, { headerStyle: "min-width:10rem;" }, {
                body: withCtx((slotProps, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-pencil",
                      class: "p-button-rounded p-button-success mr-2",
                      onClick: ($event) => editDataItem(slotProps.data)
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-trash",
                      class: "p-button-rounded p-button-warning mt-2",
                      onClick: ($event) => confirmDeleteDataItem(slotProps.data)
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_Button, {
                        icon: "pi pi-pencil",
                        class: "p-button-rounded p-button-success mr-2",
                        onClick: ($event) => editDataItem(slotProps.data)
                      }, null, 8, ["onClick"]),
                      createVNode(_component_Button, {
                        icon: "pi pi-trash",
                        class: "p-button-rounded p-button-warning mt-2",
                        onClick: ($event) => confirmDeleteDataItem(slotProps.data)
                      }, null, 8, ["onClick"])
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                __props.reorder ? (openBlock(), createBlock(_component_Column, {
                  key: 0,
                  rowReorder: "",
                  headerStyle: "width: 3rem",
                  reorderableColumn: false
                })) : createCommentVNode("", true),
                createVNode(_component_Column, {
                  selectionMode: "multiple",
                  headerStyle: "width: 3rem"
                }),
                (openBlock(true), createBlock(Fragment, null, renderList(unref(dataGridColumns), (item) => {
                  return openBlock(), createBlock(_component_Column, {
                    key: item.id,
                    field: item.id,
                    header: item.label,
                    sortable: true,
                    headerStyle: "width:14%; min-width:10rem;"
                  }, {
                    body: withCtx((slotProps) => [
                      item.type.toLowerCase() == "upload" ? (openBlock(), createBlock("div", { key: 0 }, [
                        createVNode("a", {
                          href: "/upload/" + slotProps.data[item.id]
                        }, toDisplayString(slotProps.data[item.id]), 9, ["href"])
                      ])) : createCommentVNode("", true),
                      ["string", "integer"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock("div", { key: 1 }, toDisplayString(slotProps.data[item.id]), 1)) : createCommentVNode("", true),
                      ["select"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock("div", { key: 2 }, toDisplayString(item.options.find((x) => x.code == slotProps.data[item.id]).name), 1)) : createCommentVNode("", true),
                      ["multiselect"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock("div", { key: 3 }, toDisplayString(slotProps.data[item.id].map(
                        (t) => item.options.find((x) => x.code == t) ? item.options.find((x) => x.code == t).name : "-"
                      ).join(", ")), 1)) : createCommentVNode("", true),
                      Object.values(item)[0].type == "upload" ? (openBlock(), createBlock("div", { key: 4 }, [
                        createVNode("a", {
                          href: "/file/" + slotProps.data[item[0]],
                          target: "_blank"
                        }, toDisplayString(slotProps.data[item[0]]), 9, ["href"])
                      ])) : createCommentVNode("", true)
                    ]),
                    _: 2
                  }, 1032, ["field", "header"]);
                }), 128)),
                createVNode(_component_Column, { headerStyle: "min-width:10rem;" }, {
                  body: withCtx((slotProps) => [
                    createVNode(_component_Button, {
                      icon: "pi pi-pencil",
                      class: "p-button-rounded p-button-success mr-2",
                      onClick: ($event) => editDataItem(slotProps.data)
                    }, null, 8, ["onClick"]),
                    createVNode(_component_Button, {
                      icon: "pi pi-trash",
                      class: "p-button-rounded p-button-warning mt-2",
                      onClick: ($event) => confirmDeleteDataItem(slotProps.data)
                    }, null, 8, ["onClick"])
                  ]),
                  _: 1
                })
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(dataItemDialog),
          "onUpdate:visible": ($event) => isRef(dataItemDialog) ? dataItemDialog.value = $event : null,
          style: { width: "450px" },
          header: unref(dataTitle),
          modal: true,
          class: "p-fluid"
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "Cancel",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: hideDialog
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Save",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: saveData
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "Cancel",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: hideDialog
                }),
                createVNode(_component_Button, {
                  label: "Save",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: saveData
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<!--[-->`);
              ssrRenderList(unref(dataGridColumns), (item) => {
                _push2(`<div class="field"${_scopeId}><div style="${ssrRenderStyle(item.id.toLowerCase() !== "id" ? null : { display: "none" })}"${_scopeId}><label for="name"${_scopeId}>${ssrInterpolate(item.label)}</label>`);
                if (["string", "integer"].includes(item.type.toLowerCase())) {
                  _push2(ssrRenderComponent(_component_InputText, {
                    id: "name",
                    modelValue: unref(dataItem)[item.id],
                    "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                    modelModifiers: { trim: true },
                    autofocus: ""
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                if (item.type.toLowerCase() == "textarea") {
                  _push2(ssrRenderComponent(_component_Textarea, {
                    modelValue: unref(dataItem)[item.id],
                    "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                    modelModifiers: { trim: true },
                    rows: "5",
                    cols: "30"
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                if (item.type.toLowerCase() == "select") {
                  _push2(ssrRenderComponent(_component_Dropdown, {
                    modelValue: unref(dataItem)[item.id],
                    "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                    options: item.options,
                    optionValue: "code",
                    optionLabel: "name",
                    placeholder: item.placeholder,
                    class: "w-full md:w-14rem"
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                if (item.type.toLowerCase() == "multiselect") {
                  _push2(ssrRenderComponent(_component_MultiSelect, {
                    display: "chip",
                    modelValue: unref(dataItem)[item.id],
                    "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                    options: item.options,
                    optionValue: "code",
                    filter: "",
                    optionLabel: "name",
                    placeholder: item.placeholder,
                    maxSelectedLabels: "100",
                    class: "w-full md:w-20rem"
                  }, null, _parent2, _scopeId));
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
                if (item.type.toLowerCase() == "upload") {
                  _push2(`<form _style="display: none;"${_scopeId}>`);
                  _push2(ssrRenderComponent(_component_InputText, {
                    id: "name",
                    modelValue: unref(dataItem)[item.id],
                    "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                    modelModifiers: { trim: true },
                    autofocus: ""
                  }, null, _parent2, _scopeId));
                  _push2(`<input type="file" class="form-control invisible" id="inputGroupFile"${_scopeId}><input type="submit" class="btn btn-primary invisible"${_scopeId}></form>`);
                } else {
                  _push2(`<!---->`);
                }
                if (unref(submitted) && !unref(dataItem).name) {
                  _push2(`<small class="p-invalid"${_scopeId}>Preencha ${ssrInterpolate(item[1])}</small>`);
                } else {
                  _push2(`<!---->`);
                }
                _push2(`</div>`);
              });
              _push2(`<!--]-->`);
            } else {
              return [
                (openBlock(true), createBlock(Fragment, null, renderList(unref(dataGridColumns), (item) => {
                  return openBlock(), createBlock("div", {
                    key: item.id,
                    class: "field"
                  }, [
                    withDirectives(createVNode("div", null, [
                      createVNode("label", { for: "name" }, toDisplayString(item.label), 1),
                      ["string", "integer"].includes(item.type.toLowerCase()) ? (openBlock(), createBlock(_component_InputText, {
                        key: 0,
                        id: "name",
                        modelValue: unref(dataItem)[item.id],
                        "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                        modelModifiers: { trim: true },
                        autofocus: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])) : createCommentVNode("", true),
                      item.type.toLowerCase() == "textarea" ? (openBlock(), createBlock(_component_Textarea, {
                        key: 1,
                        modelValue: unref(dataItem)[item.id],
                        "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                        modelModifiers: { trim: true },
                        rows: "5",
                        cols: "30"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])) : createCommentVNode("", true),
                      item.type.toLowerCase() == "select" ? (openBlock(), createBlock(_component_Dropdown, {
                        key: 2,
                        modelValue: unref(dataItem)[item.id],
                        "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                        options: item.options,
                        optionValue: "code",
                        optionLabel: "name",
                        placeholder: item.placeholder,
                        class: "w-full md:w-14rem"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "placeholder"])) : createCommentVNode("", true),
                      item.type.toLowerCase() == "multiselect" ? (openBlock(), createBlock(_component_MultiSelect, {
                        key: 3,
                        display: "chip",
                        modelValue: unref(dataItem)[item.id],
                        "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                        options: item.options,
                        optionValue: "code",
                        filter: "",
                        optionLabel: "name",
                        placeholder: item.placeholder,
                        maxSelectedLabels: "100",
                        class: "w-full md:w-20rem"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options", "placeholder"])) : createCommentVNode("", true)
                    ], 512), [
                      [vShow, item.id.toLowerCase() !== "id"]
                    ]),
                    item.type.toLowerCase() == "upload" ? (openBlock(), createBlock("form", {
                      key: 0,
                      ref_for: true,
                      ref: "formUploadFile",
                      _style: "display: none;",
                      onSubmit: withModifiers(($event) => handleImageUpload(item.id), ["prevent"])
                    }, [
                      createVNode(_component_InputText, {
                        id: "name",
                        modelValue: unref(dataItem)[item.id],
                        "onUpdate:modelValue": ($event) => unref(dataItem)[item.id] = $event,
                        modelModifiers: { trim: true },
                        autofocus: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("input", {
                        type: "file",
                        class: "form-control invisible",
                        id: "inputGroupFile",
                        onChange: ($event) => handleFile($event)
                      }, null, 40, ["onChange"]),
                      createVNode("input", {
                        type: "submit",
                        ref_for: true,
                        ref_key: "submitBtn",
                        ref: submitBtn,
                        class: "btn btn-primary invisible"
                      }, null, 512)
                    ], 40, ["onSubmit"])) : createCommentVNode("", true),
                    unref(submitted) && !unref(dataItem).name ? (openBlock(), createBlock("small", {
                      key: 1,
                      class: "p-invalid"
                    }, "Preencha " + toDisplayString(item[1]), 1)) : createCommentVNode("", true)
                  ]);
                }), 128))
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(deleteDataItemDialog),
          "onUpdate:visible": ($event) => isRef(deleteDataItemDialog) ? deleteDataItemDialog.value = $event : null,
          style: { width: "450px" },
          header: "Confirm",
          modal: true
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "N\xE3o",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: ($event) => deleteDataItemDialog.value = false
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Sim",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: deleteData
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "N\xE3o",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: ($event) => deleteDataItemDialog.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_Button, {
                  label: "Sim",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: deleteData
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex align-items-center justify-content-center"${_scopeId}><i class="pi pi-exclamation-triangle mr-3" style="${ssrRenderStyle({ "font-size": "2rem" })}"${_scopeId}></i>`);
              if (unref(dataItem)) {
                _push2(`<span${_scopeId}>Confirma exclus\xE3o <b${_scopeId}>${ssrInterpolate(unref(dataItem).name)}</b>?</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex align-items-center justify-content-center" }, [
                  createVNode("i", {
                    class: "pi pi-exclamation-triangle mr-3",
                    style: { "font-size": "2rem" }
                  }),
                  unref(dataItem) ? (openBlock(), createBlock("span", { key: 0 }, [
                    createTextVNode("Confirma exclus\xE3o "),
                    createVNode("b", null, toDisplayString(unref(dataItem).name), 1),
                    createTextVNode("?")
                  ])) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_Dialog, {
          visible: unref(deleteDataItemsDialog),
          "onUpdate:visible": ($event) => isRef(deleteDataItemsDialog) ? deleteDataItemsDialog.value = $event : null,
          style: { width: "450px" },
          header: "Confirm",
          modal: true
        }, {
          footer: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_Button, {
                label: "N\xE3o",
                icon: "pi pi-times",
                class: "p-button-text",
                onClick: ($event) => deleteDataItemsDialog.value = false
              }, null, _parent2, _scopeId));
              _push2(ssrRenderComponent(_component_Button, {
                label: "Sim",
                icon: "pi pi-check",
                class: "p-button-text",
                onClick: deleteSelectedDataItems
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_Button, {
                  label: "N\xE3o",
                  icon: "pi pi-times",
                  class: "p-button-text",
                  onClick: ($event) => deleteDataItemsDialog.value = false
                }, null, 8, ["onClick"]),
                createVNode(_component_Button, {
                  label: "Sim",
                  icon: "pi pi-check",
                  class: "p-button-text",
                  onClick: deleteSelectedDataItems
                })
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<div class="flex align-items-center justify-content-center"${_scopeId}><i class="pi pi-exclamation-triangle mr-3" style="${ssrRenderStyle({ "font-size": "2rem" })}"${_scopeId}></i>`);
              if (unref(dataItem)) {
                _push2(`<span${_scopeId}>Confirma exclus\xE3o de itens selecionados?</span>`);
              } else {
                _push2(`<!---->`);
              }
              _push2(`</div>`);
            } else {
              return [
                createVNode("div", { class: "flex align-items-center justify-content-center" }, [
                  createVNode("i", {
                    class: "pi pi-exclamation-triangle mr-3",
                    style: { "font-size": "2rem" }
                  }),
                  unref(dataItem) ? (openBlock(), createBlock("span", { key: 0 }, "Confirma exclus\xE3o de itens selecionados?")) : createCommentVNode("", true)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Magacrud.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Magacrud-C50a6HCh.mjs.map
