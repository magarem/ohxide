import { _ as __nuxt_component_0 } from './Magacrud-C50a6HCh.mjs';
import { withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { u as users } from './schemas-DTwCqrge.mjs';
import { d as db } from './db_cmds-0OAE-mPK.mjs';
import './toast.esm-BKw76SSr.mjs';
import './portal.esm-CdWWxjdD.mjs';
import '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './basecomponent.esm-BajCsLnl.mjs';
import './index.esm-BxeFIN3p.mjs';
import './baseicon.esm-g6sGMQlE.mjs';
import './index.esm-CID5p7Wa.mjs';
import './index.esm-B_U5wsuI.mjs';
import './index.esm-BD14euZ4.mjs';
import './datatable.esm-HXzgo9_H.mjs';
import './index.esm-Bbz8MpsA.mjs';
import './paginator.esm-BDwaISpD.mjs';
import './index.esm-ChjpqW7a.mjs';
import './dropdown.esm-CCfe8YJb.mjs';
import './index.esm-BltLHj-F.mjs';
import './index.esm-CpyHmxAn.mjs';
import './overlayeventbus.esm-CAhQZh07.mjs';
import './virtualscroller.esm-CnWKhCV9.mjs';
import './inputnumber.esm-CHAH-cYR.mjs';
import './button.esm-B68Sl5s9.mjs';
import './badge.esm-C-rTx-ix.mjs';
import './index.esm-Dos0gWj2.mjs';
import './index.esm-il7tQQCv.mjs';
import './inputtext.esm-CNretVO-.mjs';
import './index.esm-Qq84Bwnv.mjs';
import './index.esm-C3HxEmuK.mjs';
import './index.esm-DvNLCUnP.mjs';
import './checkbox.esm-DeuztAtD.mjs';
import './radiobutton.esm-DEnD9jJz.mjs';
import './index.esm-DDOrdXLZ.mjs';
import './index.esm-Bwx2iWmn.mjs';
import './column.esm-aEFxrzTH.mjs';
import './dialog.esm-BXPj_NAl.mjs';
import './textarea.esm-EZLfQ2Fk.mjs';
import './multiselect.esm-Dzm6n2Nu.mjs';

const _sfc_main = {
  __name: "users",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const data = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from users`)), __temp = await __temp, __restore(), __temp);
    const insertdata = async (data2) => {
      console.log("data:", data2);
      const ret = await db.insert({
        table: "users",
        data: data2
      });
      console.log("ret insert:", ret);
    };
    const updatedata = async (data2) => {
      const ret = await db.update({
        table: "users",
        data: data2,
        where: "id LIKE '" + data2.id + "'"
      });
      console.log("ret update:", ret);
    };
    const deletedata = async (data2) => {
      if (Array.isArray(data2)) {
        const ret = await db.delete({
          table: "users",
          where: "id in (" + data2.map((x) => `'${x.id}'`).join(",") + ")"
        });
        console.log("ret update:", ret);
      } else {
        const ret = await db.delete({
          table: "users",
          where: "id like '" + data2.id + "'"
        });
        console.log("ret update:", ret);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(ssrRenderComponent(_component_Magacrud, mergeProps({
        onInsertdata: insertdata,
        onUpdatedata: updatedata,
        onDeletedata: deletedata,
        schema: unref(users),
        data: unref(data)
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/users.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=users-DuJxSQth.mjs.map
