import script from './toast.esm-BKw76SSr.mjs';
import script$1 from './confirmdialog.esm-Ct2jqShM.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-BB5S4AHg.mjs';
import script$2 from './datatable.esm-HXzgo9_H.mjs';
import script$3 from './column.esm-aEFxrzTH.mjs';
import script$4 from './dialog.esm-BXPj_NAl.mjs';
import script$5 from './card.esm-CPjHNJNk.mjs';
import script$6 from './multiselect.esm-Dzm6n2Nu.mjs';
import script$7 from './button.esm-B68Sl5s9.mjs';
import { ref, withAsyncContext, unref, withCtx, createTextVNode, createVNode, isRef, withDirectives, vModelText, useSSRContext } from 'vue';
import { u as useRouter, a as useCookie, b as useAuthStore, s as storeToRefs, d as useToast } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-BajCsLnl.mjs';
import './index.esm-BxeFIN3p.mjs';
import './baseicon.esm-g6sGMQlE.mjs';
import './index.esm-CID5p7Wa.mjs';
import './index.esm-B_U5wsuI.mjs';
import './index.esm-BD14euZ4.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import './index.esm-Bbz8MpsA.mjs';
import './paginator.esm-BDwaISpD.mjs';
import './index.esm-ChjpqW7a.mjs';
import './dropdown.esm-CCfe8YJb.mjs';
import './index.esm-BltLHj-F.mjs';
import './index.esm-CpyHmxAn.mjs';
import './overlayeventbus.esm-CAhQZh07.mjs';
import './virtualscroller.esm-CnWKhCV9.mjs';
import './inputnumber.esm-CHAH-cYR.mjs';
import './index.esm-Dos0gWj2.mjs';
import './index.esm-il7tQQCv.mjs';
import './inputtext.esm-CNretVO-.mjs';
import './index.esm-Qq84Bwnv.mjs';
import './index.esm-C3HxEmuK.mjs';
import './index.esm-DvNLCUnP.mjs';
import './checkbox.esm-DeuztAtD.mjs';
import './radiobutton.esm-DEnD9jJz.mjs';
import './index.esm-DDOrdXLZ.mjs';
import './index.esm-Bwx2iWmn.mjs';
import './badge.esm-C-rTx-ix.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    let retorno = ref();
    const visible = ref(false);
    const data = ([__temp, __restore] = withAsyncContext(() => $fetch("/api/admin_proximos_vencimentos")), __temp = await __temp, __restore(), __temp);
    const clients = ref(data);
    const toast = useToast();
    const sendEmailForm = ref({
      year: (/* @__PURE__ */ new Date()).getFullYear(),
      month: (/* @__PURE__ */ new Date()).getMonth() + 1,
      subject: "Novo relat\xF3rio dispon\xEDvel",
      message: "Ol\xE1!\nSeu relat\xF3rio est\xE1 pronto no link abaixo.",
      linktext: "Baixar relat\xF3rio"
    });
    const sendMails = async () => {
      if (sendEmailForm.value.clients.length > 0) {
        const ret = await $fetch("/api/sendemail", {
          method: "POST",
          body: JSON.stringify(sendEmailForm.value)
        });
        if (ret) {
          visible.value = false;
          toast.add({ severity: "secondary", summary: "E-mails", detail: ret.join(", "), life: 3e3 });
        }
      }
    };
    if (!authenticated.value) {
      router.push("/admin/login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_Toast = script;
      const _component_ConfirmDialog = script$1;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_DataTable = script$2;
      const _component_Column = script$3;
      const _component_Dialog = script$4;
      const _component_Card = script$5;
      const _component_MultiSelect = script$6;
      const _component_Button = script$7;
      _push(`<!--[--><div class="p-5"><div _class="flex">`);
      _push(ssrRenderComponent(_component_Toast, null, null, _parent));
      _push(ssrRenderComponent(_component_ConfirmDialog, null, null, _parent));
      _push(`<h4>Se\xE7\xF5es</h4>`);
      if (((_a = unref(dataUser)) == null ? void 0 : _a.status) == "root") {
        _push(ssrRenderComponent(_component_NuxtLink, {
          class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
          to: "/admin/users"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Usu\xE1rios`);
            } else {
              return [
                createTextVNode("Usu\xE1rios")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
        to: "/admin/clients"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Clientes`);
          } else {
            return [
              createTextVNode("Clientes")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
        to: "/admin/products"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Produtos`);
          } else {
            return [
              createTextVNode("Produtos")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "block mt-4 mb-3 lg:mt-0 hover:text-white mr-4",
        to: "/admin/reports"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Relat\xF3rios`);
          } else {
            return [
              createTextVNode("Relat\xF3rios")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h4>Pr\xF3ximos vencimentos</h4>`);
      _push(ssrRenderComponent(_component_DataTable, {
        value: unref(clients),
        stripedRows: "",
        tableStyle: "width: 100%",
        class: "mb-4"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Column, {
              field: "name",
              header: "Nome"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_Column, {
              field: "data_limite",
              header: "Vencimento"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Column, {
                field: "name",
                header: "Nome"
              }),
              createVNode(_component_Column, {
                field: "data_limite",
                header: "Vencimento"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(` ${ssrInterpolate(unref(retorno))}</div></div>`);
      _push(ssrRenderComponent(_component_Dialog, {
        visible: unref(visible),
        "onUpdate:visible": ($event) => isRef(visible) ? visible.value = $event : null,
        header: "Envio de mensagens",
        style: { width: "35rem" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Card, {
              style: { "width": "31rem", "overflow": "hidden" },
              class: "mt-0"
            }, {
              content: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="formgrid grid"${_scopeId2}><div class="field col-12 md:col-3"${_scopeId2}><label for="firstname6"${_scopeId2}>Ano</label><input id="firstname6"${ssrRenderAttr("value", unref(sendEmailForm).year)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12 md:col-3"${_scopeId2}><label for="lastname6"${_scopeId2}>M\xEAs</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).month)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12 md:col-6"${_scopeId2}><label for="lastname6"${_scopeId2}>Assunto</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).subject)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12"${_scopeId2}><label for="address"${_scopeId2}>Mensagem</label><textarea id="address" type="text" rows="4" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}>${ssrInterpolate(unref(sendEmailForm).message)}</textarea></div><div class="field col-12"${_scopeId2}><label for="lastname6"${_scopeId2}>Texto do link</label><input id="lastname6"${ssrRenderAttr("value", unref(sendEmailForm).linktext)} type="text" class="text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"${_scopeId2}></div><div class="field col-12 md:col-3"${_scopeId2}><label for="state"${_scopeId2}>Clientes</label>`);
                  _push3(ssrRenderComponent(_component_MultiSelect, {
                    modelValue: unref(sendEmailForm).clients,
                    "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                    display: "chip",
                    options: unref(clients),
                    optionLabel: "name",
                    optionValue: "id",
                    placeholder: "Selecione os clientes",
                    maxSelectedLabels: 3,
                    class: "w-full md:w-28rem"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div></div>`);
                } else {
                  return [
                    createVNode("div", { class: "formgrid grid" }, [
                      createVNode("div", { class: "field col-12 md:col-3" }, [
                        createVNode("label", { for: "firstname6" }, "Ano"),
                        withDirectives(createVNode("input", {
                          id: "firstname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).year = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).year]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12 md:col-3" }, [
                        createVNode("label", { for: "lastname6" }, "M\xEAs"),
                        withDirectives(createVNode("input", {
                          id: "lastname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).month = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).month]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12 md:col-6" }, [
                        createVNode("label", { for: "lastname6" }, "Assunto"),
                        withDirectives(createVNode("input", {
                          id: "lastname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).subject = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).subject]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12" }, [
                        createVNode("label", { for: "address" }, "Mensagem"),
                        withDirectives(createVNode("textarea", {
                          id: "address",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).message = $event,
                          type: "text",
                          rows: "4",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).message]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12" }, [
                        createVNode("label", { for: "lastname6" }, "Texto do link"),
                        withDirectives(createVNode("input", {
                          id: "lastname6",
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).linktext = $event,
                          type: "text",
                          class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                        }, null, 8, ["onUpdate:modelValue"]), [
                          [vModelText, unref(sendEmailForm).linktext]
                        ])
                      ]),
                      createVNode("div", { class: "field col-12 md:col-3" }, [
                        createVNode("label", { for: "state" }, "Clientes"),
                        createVNode(_component_MultiSelect, {
                          modelValue: unref(sendEmailForm).clients,
                          "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                          display: "chip",
                          options: unref(clients),
                          optionLabel: "name",
                          optionValue: "id",
                          placeholder: "Selecione os clientes",
                          maxSelectedLabels: 3,
                          class: "w-full md:w-28rem"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                      ])
                    ])
                  ];
                }
              }),
              footer: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="flex gap-3 mt-1"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: ($event) => visible.value = false,
                    label: "Cancel",
                    severity: "secondary",
                    outlined: "",
                    class: "w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_Button, {
                    onClick: sendMails,
                    label: "Enviar",
                    class: "w-full"
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                } else {
                  return [
                    createVNode("div", { class: "flex gap-3 mt-1" }, [
                      createVNode(_component_Button, {
                        onClick: ($event) => visible.value = false,
                        label: "Cancel",
                        severity: "secondary",
                        outlined: "",
                        class: "w-full"
                      }, null, 8, ["onClick"]),
                      createVNode(_component_Button, {
                        onClick: sendMails,
                        label: "Enviar",
                        class: "w-full"
                      })
                    ])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_Card, {
                style: { "width": "31rem", "overflow": "hidden" },
                class: "mt-0"
              }, {
                content: withCtx(() => [
                  createVNode("div", { class: "formgrid grid" }, [
                    createVNode("div", { class: "field col-12 md:col-3" }, [
                      createVNode("label", { for: "firstname6" }, "Ano"),
                      withDirectives(createVNode("input", {
                        id: "firstname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).year = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).year]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12 md:col-3" }, [
                      createVNode("label", { for: "lastname6" }, "M\xEAs"),
                      withDirectives(createVNode("input", {
                        id: "lastname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).month = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).month]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12 md:col-6" }, [
                      createVNode("label", { for: "lastname6" }, "Assunto"),
                      withDirectives(createVNode("input", {
                        id: "lastname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).subject = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).subject]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12" }, [
                      createVNode("label", { for: "address" }, "Mensagem"),
                      withDirectives(createVNode("textarea", {
                        id: "address",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).message = $event,
                        type: "text",
                        rows: "4",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).message]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12" }, [
                      createVNode("label", { for: "lastname6" }, "Texto do link"),
                      withDirectives(createVNode("input", {
                        id: "lastname6",
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).linktext = $event,
                        type: "text",
                        class: "text-base text-color surface-overlay p-2 border-1 border-solid surface-border border-round appearance-none outline-none focus:border-primary w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, unref(sendEmailForm).linktext]
                      ])
                    ]),
                    createVNode("div", { class: "field col-12 md:col-3" }, [
                      createVNode("label", { for: "state" }, "Clientes"),
                      createVNode(_component_MultiSelect, {
                        modelValue: unref(sendEmailForm).clients,
                        "onUpdate:modelValue": ($event) => unref(sendEmailForm).clients = $event,
                        display: "chip",
                        options: unref(clients),
                        optionLabel: "name",
                        optionValue: "id",
                        placeholder: "Selecione os clientes",
                        maxSelectedLabels: 3,
                        class: "w-full md:w-28rem"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "options"])
                    ])
                  ])
                ]),
                footer: withCtx(() => [
                  createVNode("div", { class: "flex gap-3 mt-1" }, [
                    createVNode(_component_Button, {
                      onClick: ($event) => visible.value = false,
                      label: "Cancel",
                      severity: "secondary",
                      outlined: "",
                      class: "w-full"
                    }, null, 8, ["onClick"]),
                    createVNode(_component_Button, {
                      onClick: sendMails,
                      label: "Enviar",
                      class: "w-full"
                    })
                  ])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-DAkz1Y2o.mjs.map
