import script from './card.esm-CPjHNJNk.mjs';
import script$1 from './datatable.esm-HXzgo9_H.mjs';
import script$2 from './inputtext.esm-CNretVO-.mjs';
import script$3 from './button.esm-B68Sl5s9.mjs';
import script$4 from './column.esm-aEFxrzTH.mjs';
import { u as useRouter, b as useAuthStore, s as storeToRefs, a as useCookie } from '../server.mjs';
import { ref, reactive, withAsyncContext, computed, unref, mergeProps, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { d as db } from './db_cmds-0OAE-mPK.mjs';
import './basecomponent.esm-BajCsLnl.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './baseicon.esm-g6sGMQlE.mjs';
import './index.esm-Bbz8MpsA.mjs';
import './paginator.esm-BDwaISpD.mjs';
import './index.esm-ChjpqW7a.mjs';
import './dropdown.esm-CCfe8YJb.mjs';
import './index.esm-BxeFIN3p.mjs';
import './index.esm-BltLHj-F.mjs';
import './index.esm-CpyHmxAn.mjs';
import './index.esm-B_U5wsuI.mjs';
import './overlayeventbus.esm-CAhQZh07.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './virtualscroller.esm-CnWKhCV9.mjs';
import './inputnumber.esm-CHAH-cYR.mjs';
import './index.esm-Dos0gWj2.mjs';
import './index.esm-il7tQQCv.mjs';
import './badge.esm-C-rTx-ix.mjs';
import './index.esm-Qq84Bwnv.mjs';
import './index.esm-C3HxEmuK.mjs';
import './index.esm-DvNLCUnP.mjs';
import './checkbox.esm-DeuztAtD.mjs';
import './radiobutton.esm-DEnD9jJz.mjs';
import './index.esm-DDOrdXLZ.mjs';
import './index.esm-Bwx2iWmn.mjs';

const _sfc_main = {
  __name: "teste",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const { logUserOut } = useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    const dataUser = useCookie("dataUser");
    console.log("dataUser---->:", dataUser.value);
    const tableFilter = ref({
      year: null,
      month: null
    });
    if (dataUser.type !== "clients") {
      logUserOut();
    }
    if (!authenticated.value) {
      router.push("/login");
    }
    reactive({
      isLoading: false,
      columns: [
        {
          label: "ID",
          field: "id",
          width: "3%",
          sortable: true,
          isKey: true
        },
        {
          label: "Ano",
          field: "year",
          width: "10%",
          sortable: true
        },
        {
          label: "M\xEAs",
          field: "month",
          width: "10%",
          sortable: true
        },
        {
          label: "T\xEDtulo",
          field: "title",
          width: "10%",
          sortable: true
        },
        {
          label: "Arquivo",
          field: "file",
          width: "10%",
          sortable: true
        },
        {
          label: "Etiquetas",
          field: "tags",
          width: "15%",
          sortable: true
        }
      ],
      rows: [],
      totalRecordCount: 0,
      sortable: {
        order: "id",
        sort: "asc"
      }
    });
    const data = ([__temp, __restore] = withAsyncContext(() => db.get(`select reports.year, reports.month, reports.name, reports.desc, reports.file, products.name as tag from reports, products where reports.tag = products.id`)), __temp = await __temp, __restore(), __temp);
    console.log("data:", data);
    const aaa = computed(() => {
      return data.filter((x) => x.year == (tableFilter.value.year || x.year) & x.month == (tableFilter.value.month || x.month));
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Card = script;
      const _component_DataTable = script$1;
      const _component_InputText = script$2;
      const _component_Button = script$3;
      const _component_Column = script$4;
      if (unref(dataUser)) {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "m-0" }, _attrs))}>`);
        _push(ssrRenderComponent(_component_Card, {
          class: "m-5",
          style: { "width": "80%" }
        }, {
          title: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`Relat\xF3rios`);
            } else {
              return [
                createTextVNode("Relat\xF3rios")
              ];
            }
          }),
          content: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_DataTable, {
                value: unref(aaa),
                stripedRows: "",
                tableStyle: "width: 100%"
              }, {
                header: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="mb-3"${_scopeId2}> Buscar: `);
                    _push3(ssrRenderComponent(_component_InputText, {
                      id: "tableFilter",
                      modelValue: unref(tableFilter).year,
                      "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                      autofocus: "",
                      placeholder: "Ano",
                      style: { "width": "100px" },
                      class: "mx-1"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_InputText, {
                      id: "tableFilter",
                      modelValue: unref(tableFilter).month,
                      "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                      autofocus: "",
                      placeholder: "M\xEAs",
                      style: { "width": "100px" },
                      class: "mx-1"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Button, {
                      icon: "pi pi-times",
                      onClick: ($event) => tableFilter.value = {},
                      severity: "danger",
                      text: "",
                      rounded: "",
                      "aria-label": "Cancel"
                    }, null, _parent3, _scopeId2));
                    _push3(`</div>`);
                  } else {
                    return [
                      createVNode("div", { class: "mb-3" }, [
                        createTextVNode(" Buscar: "),
                        createVNode(_component_InputText, {
                          id: "tableFilter",
                          modelValue: unref(tableFilter).year,
                          "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                          autofocus: "",
                          placeholder: "Ano",
                          style: { "width": "100px" },
                          class: "mx-1"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_InputText, {
                          id: "tableFilter",
                          modelValue: unref(tableFilter).month,
                          "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                          autofocus: "",
                          placeholder: "M\xEAs",
                          style: { "width": "100px" },
                          class: "mx-1"
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode(_component_Button, {
                          icon: "pi pi-times",
                          onClick: ($event) => tableFilter.value = {},
                          severity: "danger",
                          text: "",
                          rounded: "",
                          "aria-label": "Cancel"
                        }, null, 8, ["onClick"])
                      ])
                    ];
                  }
                }),
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "year",
                      header: "Ano"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "month",
                      header: "M\xEAs"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "title",
                      header: "T\xEDtulo"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "desc",
                      header: "Descri\xE7\xE3o"
                    }, null, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "file",
                      header: "Relat\xF3rio"
                    }, {
                      body: withCtx((slotProps, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          _push4(`<a${ssrRenderAttr("href", "file/" + slotProps.data.file)} target="_blank"${_scopeId3}>Baixar</a>`);
                        } else {
                          return [
                            createVNode("a", {
                              href: "file/" + slotProps.data.file,
                              target: "_blank"
                            }, "Baixar", 8, ["href"])
                          ];
                        }
                      }),
                      _: 1
                    }, _parent3, _scopeId2));
                    _push3(ssrRenderComponent(_component_Column, {
                      field: "tag",
                      header: "R\xF3tulos"
                    }, null, _parent3, _scopeId2));
                  } else {
                    return [
                      createVNode(_component_Column, {
                        field: "year",
                        header: "Ano"
                      }),
                      createVNode(_component_Column, {
                        field: "month",
                        header: "M\xEAs"
                      }),
                      createVNode(_component_Column, {
                        field: "title",
                        header: "T\xEDtulo"
                      }),
                      createVNode(_component_Column, {
                        field: "desc",
                        header: "Descri\xE7\xE3o"
                      }),
                      createVNode(_component_Column, {
                        field: "file",
                        header: "Relat\xF3rio"
                      }, {
                        body: withCtx((slotProps) => [
                          createVNode("a", {
                            href: "file/" + slotProps.data.file,
                            target: "_blank"
                          }, "Baixar", 8, ["href"])
                        ]),
                        _: 1
                      }),
                      createVNode(_component_Column, {
                        field: "tag",
                        header: "R\xF3tulos"
                      })
                    ];
                  }
                }),
                _: 1
              }, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_DataTable, {
                  value: unref(aaa),
                  stripedRows: "",
                  tableStyle: "width: 100%"
                }, {
                  header: withCtx(() => [
                    createVNode("div", { class: "mb-3" }, [
                      createTextVNode(" Buscar: "),
                      createVNode(_component_InputText, {
                        id: "tableFilter",
                        modelValue: unref(tableFilter).year,
                        "onUpdate:modelValue": ($event) => unref(tableFilter).year = $event,
                        autofocus: "",
                        placeholder: "Ano",
                        style: { "width": "100px" },
                        class: "mx-1"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_component_InputText, {
                        id: "tableFilter",
                        modelValue: unref(tableFilter).month,
                        "onUpdate:modelValue": ($event) => unref(tableFilter).month = $event,
                        autofocus: "",
                        placeholder: "M\xEAs",
                        style: { "width": "100px" },
                        class: "mx-1"
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode(_component_Button, {
                        icon: "pi pi-times",
                        onClick: ($event) => tableFilter.value = {},
                        severity: "danger",
                        text: "",
                        rounded: "",
                        "aria-label": "Cancel"
                      }, null, 8, ["onClick"])
                    ])
                  ]),
                  default: withCtx(() => [
                    createVNode(_component_Column, {
                      field: "year",
                      header: "Ano"
                    }),
                    createVNode(_component_Column, {
                      field: "month",
                      header: "M\xEAs"
                    }),
                    createVNode(_component_Column, {
                      field: "title",
                      header: "T\xEDtulo"
                    }),
                    createVNode(_component_Column, {
                      field: "desc",
                      header: "Descri\xE7\xE3o"
                    }),
                    createVNode(_component_Column, {
                      field: "file",
                      header: "Relat\xF3rio"
                    }, {
                      body: withCtx((slotProps) => [
                        createVNode("a", {
                          href: "file/" + slotProps.data.file,
                          target: "_blank"
                        }, "Baixar", 8, ["href"])
                      ]),
                      _: 1
                    }),
                    createVNode(_component_Column, {
                      field: "tag",
                      header: "R\xF3tulos"
                    })
                  ]),
                  _: 1
                }, 8, ["value"])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/teste.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=teste-DBQsxJ8b.mjs.map
