const defaultadmin_vue_vue_type_style_index_0_scoped_c1a6b59e_lang = ".menulink[data-v-c1a6b59e]{color:#f5f5f5}";

export { defaultadmin_vue_vue_type_style_index_0_scoped_c1a6b59e_lang as d };
//# sourceMappingURL=defaultadmin-styles-2.mjs-C6m4q-rq.mjs.map
