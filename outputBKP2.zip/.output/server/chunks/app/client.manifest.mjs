const client_manifest = {
  "_Magacrud.DjFujIRA.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Magacrud.DjFujIRA.js",
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "styles.BPUKciI7.css": {
    "file": "styles.BPUKciI7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeicons.Dk_eWBPK.eot": {
    "file": "primeicons.Dk_eWBPK.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "primeicons.DsZ1W7-Z.woff2": {
    "file": "primeicons.DsZ1W7-Z.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "primeicons.CCFeZR6K.woff": {
    "file": "primeicons.CCFeZR6K.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "primeicons.NDVQFXzF.ttf": {
    "file": "primeicons.NDVQFXzF.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "primeicons.BubJZjaf.svg": {
    "file": "primeicons.BubJZjaf.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "flags_responsive.DbRDn7iy.png": {
    "file": "flags_responsive.DbRDn7iy.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.DlAUqK2U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.DlAUqK2U.js"
  },
  "_basecomponent.esm.DY1GLH_O.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "basecomponent.esm.DY1GLH_O.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_baseicon.esm.CSRxXfqT.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "baseicon.esm.CSRxXfqT.js",
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_db_cmds.BFDKMBNB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "db_cmds.BFDKMBNB.js"
  },
  "_index.esm.AjWl12ij.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.AjWl12ij.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.B3mNnO_4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.B3mNnO_4.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.B9dSENRW.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.B9dSENRW.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BA9xDlYQ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BA9xDlYQ.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BFr6NF-c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BFr6NF-c.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BG4wR-t0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BG4wR-t0.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BQwYHUuH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BQwYHUuH.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BlK3klRH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BlK3klRH.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.C0XBCvE0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.C0XBCvE0.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.C48EkMFy.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.C48EkMFy.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CBNxEYjF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CBNxEYjF.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CP0IJfJH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CP0IJfJH.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CQ0fnYdu.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CQ0fnYdu.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CgneQRaP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CgneQRaP.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DSO7iwap.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DSO7iwap.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Fk8A37Gr.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Fk8A37Gr.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.IJTsEsVn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.IJTsEsVn.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.WKy_4PBm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.WKy_4PBm.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.XJn_8sFx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.XJn_8sFx.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.d6MCt9tK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.d6MCt9tK.js",
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo.t3DWmJMg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.t3DWmJMg.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_moment.Cl4UOzQZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "moment.Cl4UOzQZ.js"
  },
  "_nuxt-link.Df3XV4uc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.Df3XV4uc.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_overlayeventbus.esm.Ddw5GRH4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlayeventbus.esm.Ddw5GRH4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_portal.esm.DlcqxQG6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "portal.esm.DlcqxQG6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_primeflex.!~{02j}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "primeflex.DHMfoBAW.css",
    "src": "_primeflex.!~{02j}~.js"
  },
  "_schemas._qSaTQ2D.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "schemas._qSaTQ2D.js",
    "imports": [
      "_db_cmds.BFDKMBNB.js"
    ]
  },
  "_styles.!~{02g}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "styles.BPUKciI7.css",
    "src": "_styles.!~{02g}~.js"
  },
  "_vue.f36acd1f.By-b8Lmw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.By-b8Lmw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/demo/flags/flags_responsive.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "flags_responsive.DbRDn7iy.png",
    "src": "assets/demo/flags/flags_responsive.png"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.DbpGwnaj.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.t3DWmJMg.js",
      "_db_cmds.BFDKMBNB.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ],
    "css": []
  },
  "default.uIW4_lmD.css": {
    "file": "default.uIW4_lmD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/defaultadmin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "defaultadmin.CyQIeGEg.js",
    "src": "layouts/defaultadmin.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.Df3XV4uc.js",
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.t3DWmJMg.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.IJTsEsVn.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.B3mNnO_4.js"
    ],
    "css": []
  },
  "defaultadmin.el42Ebak.css": {
    "file": "defaultadmin.el42Ebak.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeflex.DHMfoBAW.css": {
    "file": "primeflex.DHMfoBAW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.CUue_k6o.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.Df3XV4uc.js",
      "_vue.f36acd1f.By-b8Lmw.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-404.BChdqdSe.css": {
    "file": "error-404.BChdqdSe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.rTXWKtz8.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_vue.f36acd1f.By-b8Lmw.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.MglWbOfU.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/primevue/autocomplete/autocomplete.esm.js",
      "node_modules/primevue/calendar/calendar.esm.js",
      "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/chips/chips.esm.js",
      "node_modules/primevue/colorpicker/colorpicker.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/floatlabel/floatlabel.esm.js",
      "node_modules/primevue/iconfield/iconfield.esm.js",
      "node_modules/primevue/inputgroup/inputgroup.esm.js",
      "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
      "node_modules/primevue/inputicon/inputicon.esm.js",
      "node_modules/primevue/inputmask/inputmask.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/inputswitch/inputswitch.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/knob/knob.esm.js",
      "node_modules/primevue/listbox/listbox.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/password/password.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/selectbutton/selectbutton.esm.js",
      "node_modules/primevue/slider/slider.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/togglebutton/togglebutton.esm.js",
      "node_modules/primevue/treeselect/treeselect.esm.js",
      "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/speeddial/speeddial.esm.js",
      "node_modules/primevue/splitbutton/splitbutton.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/row/row.esm.js",
      "node_modules/primevue/columngroup/columngroup.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dataview/dataview.esm.js",
      "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
      "node_modules/primevue/orderlist/orderlist.esm.js",
      "node_modules/primevue/organizationchart/organizationchart.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/picklist/picklist.esm.js",
      "node_modules/primevue/tree/tree.esm.js",
      "node_modules/primevue/treetable/treetable.esm.js",
      "node_modules/primevue/timeline/timeline.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
      "node_modules/primevue/divider/divider.esm.js",
      "node_modules/primevue/fieldset/fieldset.esm.js",
      "node_modules/primevue/panel/panel.esm.js",
      "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
      "node_modules/primevue/splitter/splitter.esm.js",
      "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
      "node_modules/primevue/tabview/tabview.esm.js",
      "node_modules/primevue/tabpanel/tabpanel.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
      "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
      "node_modules/primevue/sidebar/sidebar.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
      "node_modules/primevue/contextmenu/contextmenu.esm.js",
      "node_modules/primevue/dock/dock.esm.js",
      "node_modules/primevue/menu/menu.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/primevue/megamenu/megamenu.esm.js",
      "node_modules/primevue/panelmenu/panelmenu.esm.js",
      "node_modules/primevue/steps/steps.esm.js",
      "node_modules/primevue/tabmenu/tabmenu.esm.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/carousel/carousel.esm.js",
      "node_modules/primevue/galleria/galleria.esm.js",
      "node_modules/primevue/image/image.esm.js",
      "node_modules/primevue/avatar/avatar.esm.js",
      "node_modules/primevue/avatargroup/avatargroup.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/blockui/blockui.esm.js",
      "node_modules/primevue/chip/chip.esm.js",
      "node_modules/primevue/inplace/inplace.esm.js",
      "node_modules/primevue/metergroup/metergroup.esm.js",
      "node_modules/primevue/scrolltop/scrolltop.esm.js",
      "node_modules/primevue/skeleton/skeleton.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/tag/tag.esm.js",
      "node_modules/primevue/terminal/terminal.esm.js",
      "layouts/default.vue",
      "layouts/defaultadmin.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "_globalCSS": true
  },
  "node_modules/primeicons/fonts/primeicons.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "primeicons.Dk_eWBPK.eot",
    "src": "node_modules/primeicons/fonts/primeicons.eot"
  },
  "node_modules/primeicons/fonts/primeicons.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "primeicons.BubJZjaf.svg",
    "src": "node_modules/primeicons/fonts/primeicons.svg"
  },
  "node_modules/primeicons/fonts/primeicons.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "primeicons.NDVQFXzF.ttf",
    "src": "node_modules/primeicons/fonts/primeicons.ttf"
  },
  "node_modules/primeicons/fonts/primeicons.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "primeicons.CCFeZR6K.woff",
    "src": "node_modules/primeicons/fonts/primeicons.woff"
  },
  "node_modules/primeicons/fonts/primeicons.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "primeicons.DsZ1W7-Z.woff2",
    "src": "node_modules/primeicons/fonts/primeicons.woff2"
  },
  "node_modules/primevue/accordion/accordion.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordion.esm.saA2NihH.js",
    "src": "node_modules/primevue/accordion/accordion.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/accordiontab/accordiontab.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordiontab.esm.xChcSE1R.js",
    "src": "node_modules/primevue/accordiontab/accordiontab.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/autocomplete/autocomplete.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "autocomplete.esm.DG6CD7k4.js",
    "src": "node_modules/primevue/autocomplete/autocomplete.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.AjWl12ij.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/avatar/avatar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.esm.CyNC0Fsh.js",
    "src": "node_modules/primevue/avatar/avatar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/avatargroup/avatargroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatargroup.esm.U8fXhJmY.js",
    "src": "node_modules/primevue/avatargroup/avatargroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/badge/badge.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "badge.esm.-dS0I1jI.js",
    "src": "node_modules/primevue/badge/badge.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/blockui/blockui.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "blockui.esm.CxNlpPlS.js",
    "src": "node_modules/primevue/blockui/blockui.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/breadcrumb/breadcrumb.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "breadcrumb.esm.aGqWozBL.js",
    "src": "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.B9dSENRW.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/button/button.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "button.esm.Qp_RklvB.js",
    "src": "node_modules/primevue/button/button.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/calendar/calendar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "calendar.esm.CinoOLPW.js",
    "src": "node_modules/primevue/calendar/calendar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.BG4wR-t0.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.DSO7iwap.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js"
    ]
  },
  "node_modules/primevue/card/card.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "card.esm.iym2PHVF.js",
    "src": "node_modules/primevue/card/card.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/carousel/carousel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "carousel.esm.BF3u9VXe.js",
    "src": "node_modules/primevue/carousel/carousel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CgneQRaP.js",
      "_index.esm.BG4wR-t0.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.DSO7iwap.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/cascadeselect/cascadeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cascadeselect.esm.aOgiWEra.js",
    "src": "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.B3mNnO_4.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CP0IJfJH.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/checkbox/checkbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.esm.DDS7tkRZ.js",
    "src": "node_modules/primevue/checkbox/checkbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CBNxEYjF.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/chip/chip.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chip.esm.BhxpN-Zn.js",
    "src": "node_modules/primevue/chip/chip.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.AjWl12ij.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/chips/chips.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chips.esm.DbZoK2V8.js",
    "src": "node_modules/primevue/chips/chips.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.AjWl12ij.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/colorpicker/colorpicker.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "colorpicker.esm.DzjR7fO9.js",
    "src": "node_modules/primevue/colorpicker/colorpicker.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/column/column.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "column.esm.C572U1l9.js",
    "src": "node_modules/primevue/column/column.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/columngroup/columngroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "columngroup.esm.Dwf4Oote.js",
    "src": "node_modules/primevue/columngroup/columngroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/confirmdialog/confirmdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmdialog.esm.DSqj0hst.js",
    "src": "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.C0XBCvE0.js",
      "_portal.esm.DlcqxQG6.js"
    ]
  },
  "node_modules/primevue/confirmpopup/confirmpopup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmpopup.esm.B8fiDCof.js",
    "src": "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/contextmenu/contextmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contextmenu.esm.BmvBZ2xJ.js",
    "src": "node_modules/primevue/contextmenu/contextmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.B3mNnO_4.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/datatable/datatable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "datatable.esm.C2P5Y7U_.js",
    "src": "node_modules/primevue/datatable/datatable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_portal.esm.DlcqxQG6.js",
      "_index.esm.BA9xDlYQ.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B3mNnO_4.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CQ0fnYdu.js"
    ]
  },
  "node_modules/primevue/dataview/dataview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataview.esm.DRkkqf6S.js",
    "src": "node_modules/primevue/dataview/dataview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.BlK3klRH.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B3mNnO_4.js"
    ]
  },
  "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataviewlayoutoptions.esm.C8AijWza.js",
    "src": "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.IJTsEsVn.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/deferredcontent/deferredcontent.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "deferredcontent.esm.BCZ7npBo.js",
    "src": "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dialog/dialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.esm.DOtaRgOd.js",
    "src": "node_modules/primevue/dialog/dialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.C0XBCvE0.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/divider/divider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.esm.BSMUTqlC.js",
    "src": "node_modules/primevue/divider/divider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dock/dock.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dock.esm.CX6W28Md.js",
    "src": "node_modules/primevue/dock/dock.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dropdown/dropdown.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dropdown.esm.CJE4ZcWT.js",
    "src": "node_modules/primevue/dropdown/dropdown.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dynamicdialog.esm.DYEjPn8B.js",
    "src": "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.C0XBCvE0.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_portal.esm.DlcqxQG6.js"
    ]
  },
  "node_modules/primevue/fieldset/fieldset.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fieldset.esm.CaSzRW5s.js",
    "src": "node_modules/primevue/fieldset/fieldset.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.WKy_4PBm.js",
      "_index.esm.Fk8A37Gr.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/fileupload/fileupload.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fileupload.esm.BnPECi8f.js",
    "src": "node_modules/primevue/fileupload/fileupload.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.C0XBCvE0.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.AjWl12ij.js"
    ]
  },
  "node_modules/primevue/floatlabel/floatlabel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "floatlabel.esm.UUOBN0XF.js",
    "src": "node_modules/primevue/floatlabel/floatlabel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/galleria/galleria.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "galleria.esm.hQfXla8X.js",
    "src": "node_modules/primevue/galleria/galleria.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.BG4wR-t0.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.DSO7iwap.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/iconfield/iconfield.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "iconfield.esm.CRMUP0Ek.js",
    "src": "node_modules/primevue/iconfield/iconfield.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/image/image.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "image.esm.By7MSeCV.js",
    "src": "node_modules/primevue/image/image.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.XJn_8sFx.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.C0XBCvE0.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/inlinemessage/inlinemessage.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inlinemessage.esm.BEpP-QGh.js",
    "src": "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CBNxEYjF.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.AjWl12ij.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/inplace/inplace.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inplace.esm.Cc00su9Q.js",
    "src": "node_modules/primevue/inplace/inplace.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.C0XBCvE0.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/inputgroup/inputgroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroup.esm.D1K0yX_U.js",
    "src": "node_modules/primevue/inputgroup/inputgroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroupaddon.esm.CUR5oduT.js",
    "src": "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputicon/inputicon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputicon.esm.BAbK_5M3.js",
    "src": "node_modules/primevue/inputicon/inputicon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputmask/inputmask.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputmask.esm.BsM3jWis.js",
    "src": "node_modules/primevue/inputmask/inputmask.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/inputnumber/inputnumber.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputnumber.esm.BXMMCYVE.js",
    "src": "node_modules/primevue/inputnumber/inputnumber.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/inputswitch/inputswitch.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputswitch.esm.BXVqIgqe.js",
    "src": "node_modules/primevue/inputswitch/inputswitch.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputtext/inputtext.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputtext.esm.Df0NFZhH.js",
    "src": "node_modules/primevue/inputtext/inputtext.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/knob/knob.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "knob.esm.DOje9eSS.js",
    "src": "node_modules/primevue/knob/knob.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/listbox/listbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "listbox.esm.anAoEay9.js",
    "src": "node_modules/primevue/listbox/listbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CQ0fnYdu.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.CP0IJfJH.js"
    ]
  },
  "node_modules/primevue/megamenu/megamenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "megamenu.esm._ydE_gYq.js",
    "src": "node_modules/primevue/megamenu/megamenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.IJTsEsVn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.B3mNnO_4.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/menu/menu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.esm.CyY6Jc1U.js",
    "src": "node_modules/primevue/menu/menu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/menubar/menubar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menubar.esm.DaWf-aji.js",
    "src": "node_modules/primevue/menubar/menubar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.IJTsEsVn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.B3mNnO_4.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/message/message.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "message.esm.C--z8u7g.js",
    "src": "node_modules/primevue/message/message.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CBNxEYjF.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/metergroup/metergroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "metergroup.esm.DIRVhDah.js",
    "src": "node_modules/primevue/metergroup/metergroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/multiselect/multiselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "multiselect.esm.BuirEDLo.js",
    "src": "node_modules/primevue/multiselect/multiselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/orderlist/orderlist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "orderlist.esm.DAxj4MQ_.js",
    "src": "node_modules/primevue/orderlist/orderlist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.C48EkMFy.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/organizationchart/organizationchart.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "organizationchart.esm.BkhZk577.js",
    "src": "node_modules/primevue/organizationchart/organizationchart.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.DSO7iwap.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/overlaypanel/overlaypanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlaypanel.esm.DPShvGMa.js",
    "src": "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/paginator/paginator.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "paginator.esm.Cqw7t55t.js",
    "src": "node_modules/primevue/paginator/paginator.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.B3mNnO_4.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js"
    ]
  },
  "node_modules/primevue/panel/panel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panel.esm.CvmGtHQO.js",
    "src": "node_modules/primevue/panel/panel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.WKy_4PBm.js",
      "_index.esm.Fk8A37Gr.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/panelmenu/panelmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panelmenu.esm.BZ3AMWNj.js",
    "src": "node_modules/primevue/panelmenu/panelmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/password/password.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "password.esm.BWglIjhz.js",
    "src": "node_modules/primevue/password/password.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.XJn_8sFx.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/picklist/picklist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "picklist.esm.DRi75xN_.js",
    "src": "node_modules/primevue/picklist/picklist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.C48EkMFy.js",
      "_index.esm.BlK3klRH.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/progressbar/progressbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressbar.esm.Bvaqep_X.js",
    "src": "node_modules/primevue/progressbar/progressbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/progressspinner/progressspinner.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressspinner.esm.BT_qkwBT.js",
    "src": "node_modules/primevue/progressspinner/progressspinner.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/radiobutton/radiobutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "radiobutton.esm.CD1PAhRx.js",
    "src": "node_modules/primevue/radiobutton/radiobutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/rating/rating.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rating.esm.BT-rx7eT.js",
    "src": "node_modules/primevue/rating/rating.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-italic.var.DhD-tpjY.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2"
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-roman.var.C-r5W2Hj.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2"
  },
  "node_modules/primevue/row/row.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "row.esm.fk5KyKq6.js",
    "src": "node_modules/primevue/row/row.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/scrollpanel/scrollpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollpanel.esm.Cz636tHf.js",
    "src": "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/scrolltop/scrolltop.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrolltop.esm.C9jm9ROB.js",
    "src": "node_modules/primevue/scrolltop/scrolltop.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DSO7iwap.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/selectbutton/selectbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "selectbutton.esm.BTQuu5hq.js",
    "src": "node_modules/primevue/selectbutton/selectbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/sidebar/sidebar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sidebar.esm.BdyPtuuD.js",
    "src": "node_modules/primevue/sidebar/sidebar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.C0XBCvE0.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/skeleton/skeleton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "skeleton.esm.CidNsRXv.js",
    "src": "node_modules/primevue/skeleton/skeleton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/slider/slider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "slider.esm.BhvGFZLu.js",
    "src": "node_modules/primevue/slider/slider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/speeddial/speeddial.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "speeddial.esm.C5Cj6sDK.js",
    "src": "node_modules/primevue/speeddial/speeddial.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/splitbutton/splitbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitbutton.esm.DLKaRdLA.js",
    "src": "node_modules/primevue/splitbutton/splitbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.CgneQRaP.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "_index.esm.B3mNnO_4.js"
    ]
  },
  "node_modules/primevue/splitter/splitter.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitter.esm.B85wazc8.js",
    "src": "node_modules/primevue/splitter/splitter.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/splitterpanel/splitterpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitterpanel.esm.9fl2IOWk.js",
    "src": "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/steps/steps.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "steps.esm.DlCY8rCr.js",
    "src": "node_modules/primevue/steps/steps.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/tabmenu/tabmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabmenu.esm.CLle08T_.js",
    "src": "node_modules/primevue/tabmenu/tabmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/tabpanel/tabpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabpanel.esm.B8oE3baQ.js",
    "src": "node_modules/primevue/tabpanel/tabpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tabview/tabview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabview.esm.CPSnUrT4.js",
    "src": "node_modules/primevue/tabview/tabview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BG4wR-t0.js",
      "_index.esm.B9dSENRW.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/tag/tag.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.esm.CWXOcl4R.js",
    "src": "node_modules/primevue/tag/tag.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/terminal/terminal.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terminal.esm.-NPYsMNO.js",
    "src": "node_modules/primevue/terminal/terminal.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/textarea/textarea.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "textarea.esm.XHN6W7LQ.js",
    "src": "node_modules/primevue/textarea/textarea.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tieredmenu/tieredmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tieredmenu.esm.BDPR__9t.js",
    "src": "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.B3mNnO_4.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/timeline/timeline.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "timeline.esm.D3UkaHDQ.js",
    "src": "node_modules/primevue/timeline/timeline.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/toast/toast.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toast.esm.-8pUeXn-.js",
    "src": "node_modules/primevue/toast/toast.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/togglebutton/togglebutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "togglebutton.esm.Tr8gYHbA.js",
    "src": "node_modules/primevue/togglebutton/togglebutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ]
  },
  "node_modules/primevue/toolbar/toolbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toolbar.esm.BInuO5CZ.js",
    "src": "node_modules/primevue/toolbar/toolbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tree/tree.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tree.esm.D7np4-yk.js",
    "src": "node_modules/primevue/tree/tree.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.WKy_4PBm.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/treeselect/treeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treeselect.esm.yBLX8C1K.js",
    "src": "node_modules/primevue/treeselect/treeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CgneQRaP.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/tree/tree.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.WKy_4PBm.js"
    ]
  },
  "node_modules/primevue/treetable/treetable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treetable.esm.7eIoCPQw.js",
    "src": "node_modules/primevue/treetable/treetable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.WKy_4PBm.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B3mNnO_4.js"
    ]
  },
  "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tristatecheckbox.esm.NtMOjrGy.js",
    "src": "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CBNxEYjF.js",
      "_index.esm.C0XBCvE0.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "node_modules/primevue/virtualscroller/virtualscroller.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "virtualscroller.esm.So4xNEQb.js",
    "src": "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CP0IJfJH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_baseicon.esm.CSRxXfqT.js"
    ]
  },
  "pages/admin/client_planos.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client_planos.BNhK4Nm7.js",
    "src": "pages/admin/client_planos.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.DjFujIRA.js",
      "_schemas._qSaTQ2D.js",
      "_db_cmds.BFDKMBNB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/clients.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clients.Bqj5pdxi.js",
    "src": "pages/admin/clients.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.DjFujIRA.js",
      "_moment.Cl4UOzQZ.js",
      "_schemas._qSaTQ2D.js",
      "_db_cmds.BFDKMBNB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/config.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.D5tYep46.js",
    "src": "pages/admin/config.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_db_cmds.BFDKMBNB.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js"
    ]
  },
  "pages/admin/date.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date.DBoWes0y.js",
    "src": "pages/admin/date.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.LBrHQ8eY.js",
    "src": "pages/admin/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "_nuxt-link.Df3XV4uc.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/index_res.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index_res.CFXl6HLB.js",
    "src": "pages/admin/index_res.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.DjFujIRA.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.BFC9ULBF.js",
    "src": "pages/admin/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.t3DWmJMg.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.DY1GLH_O.js"
    ],
    "css": []
  },
  "login.CmvI9c4k.css": {
    "file": "login.CmvI9c4k.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/products.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "products.DjMGLemj.js",
    "src": "pages/admin/products.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.DjFujIRA.js",
      "_schemas._qSaTQ2D.js",
      "_db_cmds.BFDKMBNB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/reports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "reports.BLHOXYBl.js",
    "src": "pages/admin/reports.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.DjFujIRA.js",
      "_schemas._qSaTQ2D.js",
      "_db_cmds.BFDKMBNB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/sendemail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sendemail.DzmWjXoy.js",
    "src": "pages/admin/sendemail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_db_cmds.BFDKMBNB.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.CP0IJfJH.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.BhvoeTzo.js",
    "src": "pages/admin/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "_db_cmds.BFDKMBNB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/users.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "users.C5MJnkec.js",
    "src": "pages/admin/users.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.DjFujIRA.js",
      "_schemas._qSaTQ2D.js",
      "_db_cmds.BFDKMBNB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud copy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud copy.BoNBeDnY.js",
    "src": "pages/crud copy.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_index.esm.Fk8A37Gr.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "_index.esm.B3mNnO_4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BA9xDlYQ.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud.D8ALG_fr.js",
    "src": "pages/crud.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.DlcqxQG6.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "_index.esm.CBNxEYjF.js",
      "_baseicon.esm.CSRxXfqT.js",
      "_index.esm.BFr6NF-c.js",
      "_index.esm.C0XBCvE0.js",
      "_index.esm.AjWl12ij.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/download.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "download.CVq6qENS.js",
    "src": "pages/download.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.t3DWmJMg.js",
      "_db_cmds.BFDKMBNB.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js"
    ],
    "css": []
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.zzNgITtA.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js"
    ]
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.BQ9_B2IJ.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.t3DWmJMg.js",
      "__plugin-vue_export-helper.DlAUqK2U.js"
    ],
    "css": []
  },
  "login.BH8asLz8.css": {
    "file": "login.BH8asLz8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/teste.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste.BmC9hKB1.js",
    "src": "pages/teste.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_db_cmds.BFDKMBNB.js",
      "_basecomponent.esm.DY1GLH_O.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CP0IJfJH.js",
      "_baseicon.esm.CSRxXfqT.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.BlK3klRH.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CBNxEYjF.js",
      "_index.esm.CgneQRaP.js",
      "_index.esm.CQ0fnYdu.js",
      "_index.esm.C0XBCvE0.js",
      "_overlayeventbus.esm.Ddw5GRH4.js",
      "_portal.esm.DlcqxQG6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.d6MCt9tK.js",
      "_index.esm.BQwYHUuH.js",
      "_index.esm.B3mNnO_4.js",
      "_index.esm.B9dSENRW.js",
      "_index.esm.IJTsEsVn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.Fk8A37Gr.js",
      "_index.esm.BA9xDlYQ.js"
    ]
  },
  "pages/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.DEkj5506.js",
    "src": "pages/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
