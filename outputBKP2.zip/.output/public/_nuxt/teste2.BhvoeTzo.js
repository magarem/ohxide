import{d as u}from"./db_cmds.BFDKMBNB.js";import{r as _,n as m,c as d,d as E,t as N,u as T,F as g,a as O,o as j}from"./entry.MglWbOfU.js";const I=O("h1",null,"teste",-1),x={__name:"teste2",async setup(S){let e,t,o=_([]),p=_([]),n,r,l=[];o.value=([e,t]=m(()=>u.get("select * from clients")),e=await e,t(),e),o.value.map((a,i)=>{n="("+Object.keys(a).join(",")+")",r="("+Object.values(a).map(s=>s=="null"?s:s=="2224"?"'top'":"'"+s+"'").join(",")+")",l[i]=`
         INSERT INTO clients
         ${n}
         VALUES
         ${r};
      `}),console.log(l);let c=`
   
   BEGIN TRANSACTION;

   DELETE FROM clients;
  
   ${l.join("")}

   COMMIT;
  `;console.log(c);let f=([e,t]=m(()=>u.exec(c)),e=await e,t(),e);return console.log("ret:",f),(a,i)=>(j(),d(g,null,[I,E(" "+N(T(p)),1)],64))}};export{x as default};
