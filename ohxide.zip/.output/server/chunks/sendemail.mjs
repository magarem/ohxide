import { d as defineEventHandler, r as readBody, a as getRequestURL } from './nitro/node-server.mjs';
import Database from 'better-sqlite3';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

const sendemail = defineEventHandler(async (event) => {
  const db = new Database("database.db");
  let ret = [];
  let link = "";
  let req = await readBody(event);
  const url = getRequestURL(event);
  console.log("url::>", url.origin);
  const clientsIds = req.clients.map((x) => `'${x}'`).join(",");
  console.log("clientsIds:", clientsIds);
  const client_final_report_build = async (year, month, client) => {
    const sql = `
      select 
          COUNT(reports.id), 
          reports.year, 
          reports.month, 
          GROUP_CONCAT(reports.name) as nome, 
          GROUP_CONCAT(reports.file) as files, 
          GROUP_CONCAT(products.name) as tags 
      from 
          reports, 
          products, 
          clients 
      where 
          reports.tag = products.id AND 
          instr(clients.tags, reports.tag) > 0 AND
          clients.id like '${client.id}' AND
          reports.year LIKE '${year}' AND
          reports.month LIKE '${month}' 
      GROUP BY 
          reports.year, 
          reports.month 
      order by 
          year DESC, 
          month DESC 
      `;
    let data_ = db.prepare(sql.replace(/\s+/g, " ").trim()).all();
    console.log("whay stop?");
    if (data_[0]?.files) {
      let data2_ = await $fetch(`http://216.238.98.143:3005/test?year=${year}&month=${month}&client=${JSON.stringify(client)}&files=${data_[0].files.split(",").map((x) => "/home/maga/dev/ohxide/upload/" + x).join(",")}`);
      console.log("data2_", data2_);
      return data2_;
    } else {
      return false;
    }
  };
  const clients = db.prepare(`select * from clients where status like 'ativo' and id in (${clientsIds})`).all();
  console.log(clients);
  await Promise.all(
    clients.map(async (x, index) => {
      const option = { month: "long" };
      const locale = "pt-br";
      (/* @__PURE__ */ new Date()).toLocaleDateString(locale, option);
      const meses = new Array("Janeiro", "Fevereiro", "Mar\xE7o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro");
      let message = req.message;
      message = message.replaceAll("[nome]", x.name);
      message = message.replaceAll("[username]", x.username);
      message = message.replaceAll("[empresa]", x.empresa);
      message = message.replaceAll("[email]", x.email);
      message = message.replaceAll("[ano]", req.year);
      message = message.replaceAll("[mes]", meses[req.month - 1]);
      message = message.replaceAll("[m\xEAs]", meses[req.month - 1]);
      if (req.linktext) {
        link = `<br/><a href="${url.origin}/file'/${x.id}_report_${req.year}_${req.month}.pdf">${req.linktext}</a>`;
      }
      let get_final_report_name = await client_final_report_build(req.year, req.month, clients.filter((xx) => xx.id == x.id)[0]);
      if (get_final_report_name) {
        console.log(`/home/maga/dev/ohxide/reports/${get_final_report_name}`);
        const dataEmailSend = await $fetch("/api/mailersend", {
          method: "POST",
          body: JSON.stringify({
            to: x.email,
            destinatario: x.email,
            // attach: `/home/maga/dev/ohxide/reports/${x.id}_report_${req.year}_${req.month}.pdf`,
            attach: `/home/maga/dev/ohxide/reports/${get_final_report_name}`,
            subject: req.subject,
            // body: req.subject,
            html: `
              <img src="https://bucket.mailersendapp.com/neqvygmrw5l0p7w2/jy7zpl9359ol5vx6/images/9ba4cd5b-1751-4410-adea-640b39425b51.jpeg" style="width: 70px;"/><br/>
              ${message.replaceAll("\n", "<br/>")}
              ${link}
            `
          })
        });
        console.log("dataEmailSend:", dataEmailSend);
        ret.push(`${clients.find((xx) => xx.id == x.id).name} ---> OK`);
      } else {
        ret.push(`${clients.find((xx) => xx.id == x.id).name} ---> Erro. N\xE3o existem arquivos`);
      }
    })
  );
  console.log("ret>", ret);
  return ret;
});

export { sendemail as default };
//# sourceMappingURL=sendemail.mjs.map
