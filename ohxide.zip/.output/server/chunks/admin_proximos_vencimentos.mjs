import { d as defineEventHandler } from './nitro/node-server.mjs';
import Database from 'better-sqlite3';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

const admin_proximos_vencimentos = defineEventHandler(async (event) => {
  const db = new Database("database.db");
  let ret = null;
  const getData = (sql2) => {
    const selectData = db.prepare(sql2).all();
    return selectData;
  };
  const sql = "select name, data_limite, date(substr(data_limite, 7, 4) || '-' || substr(data_limite, 4, 2) || '-' || substr(data_limite, 1, 2)) as vencimento from clients WHERE vencimento BETWEEN DATE('now') AND DATE('now', '+30 days') ORDER BY vencimento";
  ret = getData(sql);
  return ret;
});

export { admin_proximos_vencimentos as default };
//# sourceMappingURL=admin_proximos_vencimentos.mjs.map
