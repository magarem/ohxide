import { d as defineEventHandler, s as sendStream } from './nitro/node-server.mjs';
import fs from 'fs';
import path from 'path';
import 'node:http';
import 'node:https';
import 'vue';
import 'node:fs';
import 'node:url';

const _name__get = defineEventHandler(async (event) => {
  const base = "upload";
  const filePath = path.join(base, event.context.params.name);
  console.log("filePath", filePath);
  return sendStream(event, fs.createReadStream(filePath));
});

export { _name__get as default };
//# sourceMappingURL=_name_.get2.mjs.map
