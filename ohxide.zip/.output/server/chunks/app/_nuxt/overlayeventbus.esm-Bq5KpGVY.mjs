import { q as primebus } from '../server.mjs';

var OverlayEventBus = primebus();

export { OverlayEventBus as O };
//# sourceMappingURL=overlayeventbus.esm-Bq5KpGVY.mjs.map
