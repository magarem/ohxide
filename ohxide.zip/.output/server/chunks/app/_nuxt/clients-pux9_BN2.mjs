import { _ as __nuxt_component_0 } from './Magacrud-kKfwUxEc.mjs';
import { ref, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import moment from 'moment';
import { a as clients } from './schemas-BNqwxg4n.mjs';
import { d as db } from '../server.mjs';
import './toast.esm-CRPwFobe.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-BVGT0S0N.mjs';
import './index.esm-Ck6r_PO0.mjs';
import './baseicon.esm-DmfInns-.mjs';
import './index.esm-CALLIO8z.mjs';
import './index.esm-D3KrKUH2.mjs';
import './index.esm-CUG1V6Y9.mjs';
import './datatable.esm-BhVn4DbT.mjs';
import './index.esm-D9hkvMdq.mjs';
import './paginator.esm-BO8qQLAy.mjs';
import './index.esm-FjW_QFo3.mjs';
import './dropdown.esm-Br8THNf2.mjs';
import './index.esm-x8bPqNMQ.mjs';
import './index.esm-DIylI8Is.mjs';
import './overlayeventbus.esm-Bq5KpGVY.mjs';
import './virtualscroller.esm-D2VQ_Zc2.mjs';
import './inputnumber.esm-CRDYm17l.mjs';
import './button.esm-BXyYR5vb.mjs';
import './badge.esm-B9G3W3GA.mjs';
import './index.esm-CdlNfHzJ.mjs';
import './index.esm-DEA9sl9B.mjs';
import './inputtext.esm-Dcp3Eiz9.mjs';
import './index.esm-DHCZPrg6.mjs';
import './index.esm-QjhWl5Pd.mjs';
import './index.esm-CV5JRnen.mjs';
import './checkbox.esm-DUmz2QaO.mjs';
import './radiobutton.esm-VcoWiiBU.mjs';
import './index.esm-CW1L2d1N.mjs';
import './index.esm-62nGn5U5.mjs';
import './column.esm-fP37R6LT.mjs';
import './dialog.esm-BnmY8miO.mjs';
import './textarea.esm-30SlnOnd.mjs';
import './multiselect.esm---tbYcTT.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "clients",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    let data = ref([]);
    let data2 = [];
    let insertSQL = [];
    data.value = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from clients`)), __temp = await __temp, __restore(), __temp);
    const limitDataCalc = async (date, plano) => {
      console.log("qnt_months sql:", `select desc from client_planos where id = ${plano}`);
      const sqlret = await db.get(`select desc from client_planos where id = ${plano}`);
      const qnt_months = sqlret[0].desc;
      console.log("qnt_months:", qnt_months);
      let myDate = date.split("/");
      let d = moment([myDate[2], myDate[1] - 1, myDate[0]]);
      d.add(qnt_months, "month");
      console.log("mais um m\xEAs:", d);
      const ret = moment(d).utc().format("DD/MM/YYYY");
      console.log("mais um m\xEAs ret:", ret);
      console.log("ret:", ret);
      return ret;
    };
    const insertdata = async (data_) => {
      data2 = { ...data_ };
      Object.entries(clients.schema).forEach((item) => {
        if (item[1].type.toLowerCase() == "multiselect") {
          data2[item[0]] = data2[item[0]].join(",");
          console.log("lll>>", data2[item[0]]);
        }
      });
      data2.data_limite = await limitDataCalc(data2.data_adesao, data2.plano);
      console.log("data2.data_limite:", data2.data_limite);
      console.log("data2:", data2);
      data.value = data2;
      await db.insert({
        table: "clients",
        data: data2
      });
    };
    const updatedata = async (data_) => {
      data2 = { ...data_ };
      Object.entries(clients.schema).forEach((item) => {
        if (item[1].type.toLowerCase() == "multiselect") {
          data2[item[0]] = data2[item[0]].join(",");
          console.log("lll>>", data2[item[0]]);
        }
      });
      data2.data_limite = await limitDataCalc(data2.data_adesao, data2.plano);
      console.log("data2.data_limite", data2.data_limite);
      const ret = await db.update({
        table: "clients",
        data: data2,
        where: "id LIKE '" + data2.id + "'"
      });
      console.log("ret update:", ret);
    };
    const updateorder = async (data3) => {
      console.log("data:", data3);
      data3.map((x, index) => {
        let columns_ = "(" + Object.keys(x).join(",") + ")";
        let values_ = "(" + Object.values(x).map((y) => {
          if (y == "null") {
            return y;
          } else {
            return "'" + y + "'";
          }
        }).join(",") + ")";
        insertSQL[index] = `
            INSERT INTO clients
            ${columns_}
            VALUES
            ${values_};
        `;
      });
      let sql = `
            BEGIN TRANSACTION;
            DELETE FROM clients;
            ${insertSQL.join("")}
            COMMIT;
            `;
      console.log("sql:", sql);
      await db.exec(sql);
    };
    const deletedata = async (data3) => {
      if (Array.isArray(data3)) {
        const ret = await db.delete({
          table: "clients",
          where: "id in (" + data3.map((x) => `'${x.id}'`).join(",") + ")"
        });
        console.log("ret update:", ret);
      } else {
        const ret = await db.delete({
          table: "clients",
          where: "id like '" + data3.id + "'"
        });
        console.log("ret update:", ret);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(ssrRenderComponent(_component_Magacrud, mergeProps({
        onInsertdata: insertdata,
        onUpdatedata: updatedata,
        onUpdateorder: updateorder,
        onDeletedata: deletedata,
        schema: unref(clients),
        data: unref(data)
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/clients.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=clients-pux9_BN2.mjs.map
