import { _ as __nuxt_component_0 } from './Magacrud-B2rF_MjD.mjs';
import { u as useRouter, a as useCookie, b as useAuthStore, s as storeToRefs } from '../server.mjs';
import { mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderStyle, ssrRenderComponent } from 'vue/server-renderer';
import './toast.esm-CRPwFobe.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-BVGT0S0N.mjs';
import './index.esm-Ck6r_PO0.mjs';
import './baseicon.esm-DmfInns-.mjs';
import './index.esm-CALLIO8z.mjs';
import './index.esm-D3KrKUH2.mjs';
import './index.esm-CUG1V6Y9.mjs';
import './datatable.esm-BhVn4DbT.mjs';
import './index.esm-D9hkvMdq.mjs';
import './paginator.esm-BO8qQLAy.mjs';
import './index.esm-FjW_QFo3.mjs';
import './dropdown.esm-Br8THNf2.mjs';
import './index.esm-x8bPqNMQ.mjs';
import './index.esm-DIylI8Is.mjs';
import './overlayeventbus.esm-Bq5KpGVY.mjs';
import './virtualscroller.esm-D2VQ_Zc2.mjs';
import './inputnumber.esm-CRDYm17l.mjs';
import './button.esm-BXyYR5vb.mjs';
import './badge.esm-B9G3W3GA.mjs';
import './index.esm-CdlNfHzJ.mjs';
import './index.esm-DEA9sl9B.mjs';
import './inputtext.esm-Dcp3Eiz9.mjs';
import './index.esm-DHCZPrg6.mjs';
import './index.esm-QjhWl5Pd.mjs';
import './index.esm-CV5JRnen.mjs';
import './checkbox.esm-DUmz2QaO.mjs';
import './radiobutton.esm-VcoWiiBU.mjs';
import './index.esm-CW1L2d1N.mjs';
import './index.esm-62nGn5U5.mjs';
import './column.esm-fP37R6LT.mjs';
import './dialog.esm-BnmY8miO.mjs';
import './textarea.esm-30SlnOnd.mjs';
import './multiselect.esm---tbYcTT.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "index_res",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    if (!authenticated.value) {
      router.push("/login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "p-5" }, _attrs))}><div class="flex">`);
      if (unref(dataUser).status == "root") {
        _push(`<div class="p-1" style="${ssrRenderStyle({ "width": "520px", "max-height": "500px", "margin-right": "20px", "overflow": "auto" })}">`);
        _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/users.json" }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="p-1" style="${ssrRenderStyle({ "width": "520px", "max-height": "500px", "margin-right": "20px", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/clients.json" }, null, _parent));
      _push(`</div><div class="p-1" style="${ssrRenderStyle({ "width": "500px", "height": "500px", "overflow": "auto" })}">`);
      _push(ssrRenderComponent(_component_Magacrud, { source: "demo/data/reports.json" }, null, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index_res.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index_res-Co481sj7.mjs.map
