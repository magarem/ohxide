const defaultadmin_vue_vue_type_style_index_0_scoped_213ae9e4_lang = ".menulink[data-v-213ae9e4]{color:#f5f5f5}";

export { defaultadmin_vue_vue_type_style_index_0_scoped_213ae9e4_lang as d };
//# sourceMappingURL=defaultadmin-styles-2.mjs-BMu5GLk9.mjs.map
