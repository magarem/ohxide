const default_vue_vue_type_style_index_0_scoped_74744641_lang = "a[data-v-74744641]{color:#0a0a3e}.title[data-v-74744641]{font-weight:700}";

const defaultStyles_P9dQgj4r = [default_vue_vue_type_style_index_0_scoped_74744641_lang];

export { defaultStyles_P9dQgj4r as default };
//# sourceMappingURL=default-styles.P9dQgj4r.mjs.map
