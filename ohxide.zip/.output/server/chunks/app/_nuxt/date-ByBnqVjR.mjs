import { ref, unref, useSSRContext } from 'vue';
import { ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "date",
  __ssrInlineRender: true,
  setup(__props) {
    let ret = ref("in\xEDcio");
    var myDate = "26-01-2012";
    myDate = myDate.split("-");
    function addDays(date, days) {
      var result = new Date(date);
      result.setDate(result.getDate() + days);
      return result;
    }
    var newDate = new Date(myDate[2], myDate[1] - 1, myDate[0]);
    console.log(newDate.getTime());
    ret.value = addDays(newDate.getTime(), 12 * 30);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><h1>Tempo</h1> ${ssrInterpolate(unref(ret))}<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/date.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=date-ByBnqVjR.mjs.map
