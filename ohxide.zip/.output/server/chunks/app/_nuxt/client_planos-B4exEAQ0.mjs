import { _ as __nuxt_component_0 } from './Magacrud-B2rF_MjD.mjs';
import { ref, withAsyncContext, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { c as client_planos } from './schemas-BNqwxg4n.mjs';
import { d as db } from '../server.mjs';
import './toast.esm-CRPwFobe.mjs';
import './portal.esm-CdWWxjdD.mjs';
import './basecomponent.esm-BVGT0S0N.mjs';
import './index.esm-Ck6r_PO0.mjs';
import './baseicon.esm-DmfInns-.mjs';
import './index.esm-CALLIO8z.mjs';
import './index.esm-D3KrKUH2.mjs';
import './index.esm-CUG1V6Y9.mjs';
import './datatable.esm-BhVn4DbT.mjs';
import './index.esm-D9hkvMdq.mjs';
import './paginator.esm-BO8qQLAy.mjs';
import './index.esm-FjW_QFo3.mjs';
import './dropdown.esm-Br8THNf2.mjs';
import './index.esm-x8bPqNMQ.mjs';
import './index.esm-DIylI8Is.mjs';
import './overlayeventbus.esm-Bq5KpGVY.mjs';
import './virtualscroller.esm-D2VQ_Zc2.mjs';
import './inputnumber.esm-CRDYm17l.mjs';
import './button.esm-BXyYR5vb.mjs';
import './badge.esm-B9G3W3GA.mjs';
import './index.esm-CdlNfHzJ.mjs';
import './index.esm-DEA9sl9B.mjs';
import './inputtext.esm-Dcp3Eiz9.mjs';
import './index.esm-DHCZPrg6.mjs';
import './index.esm-QjhWl5Pd.mjs';
import './index.esm-CV5JRnen.mjs';
import './checkbox.esm-DUmz2QaO.mjs';
import './radiobutton.esm-VcoWiiBU.mjs';
import './index.esm-CW1L2d1N.mjs';
import './index.esm-62nGn5U5.mjs';
import './column.esm-fP37R6LT.mjs';
import './dialog.esm-BnmY8miO.mjs';
import './textarea.esm-30SlnOnd.mjs';
import './multiselect.esm---tbYcTT.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "client_planos",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const table = ref("client_planos");
    const data = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from ${table.value}`)), __temp = await __temp, __restore(), __temp);
    const insertdata = async (data2) => {
      console.log("data:", data2);
      const ret = await db.insert({
        table: table.value,
        data: data2
      });
      console.log("ret insert:", ret);
    };
    const updatedata = async (data2) => {
      const ret = await db.update({
        table: table.value,
        data: data2,
        where: "id LIKE '" + data2.id + "'"
      });
      console.log("ret update:", ret);
    };
    const deletedata = async (data2) => {
      if (Array.isArray(data2)) {
        const ret = await db.delete({
          table: table.value,
          where: "id in (" + data2.map((x) => `'${x.id}'`).join(",") + ")"
        });
        console.log("ret update:", ret);
      } else {
        const ret = await db.delete({
          table: table.value,
          where: "id like '" + data2.id + "'"
        });
        console.log("ret update:", ret);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Magacrud = __nuxt_component_0;
      _push(ssrRenderComponent(_component_Magacrud, mergeProps({
        onInsertdata: insertdata,
        onUpdatedata: updatedata,
        onDeletedata: deletedata,
        schema: unref(client_planos),
        data: unref(data)
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/client_planos.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=client_planos-B4exEAQ0.mjs.map
