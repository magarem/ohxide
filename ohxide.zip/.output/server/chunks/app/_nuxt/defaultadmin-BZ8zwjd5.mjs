import script from './menubar.esm-D1g4fCsl.mjs';
import { _ as __nuxt_component_0 } from './nuxt-link-maGuimwn.mjs';
import script$1 from './badge.esm-B9G3W3GA.mjs';
import script$2 from './button.esm-BXyYR5vb.mjs';
import { u as useRouter, a as useCookie, b as useAuthStore, s as storeToRefs, n as navigateTo } from '../server.mjs';
import { withAsyncContext, ref, resolveDirective, unref, withCtx, createVNode, mergeProps, toDisplayString, withDirectives, openBlock, createBlock, createCommentVNode, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrRenderAttrs, ssrGetDirectiveProps, ssrRenderClass, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-BTo1DBng.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './index.esm-CV5JRnen.mjs';
import './baseicon.esm-DmfInns-.mjs';
import './basecomponent.esm-BVGT0S0N.mjs';
import './index.esm-CdlNfHzJ.mjs';
import './index.esm-DHCZPrg6.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './index.esm-D9hkvMdq.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "defaultadmin",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    useRouter();
    const dataUser = useCookie("dataUser");
    console.log("dataUser:", !dataUser.value);
    const { logUserOut } = useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    const logOut = async () => {
      logUserOut();
      await navigateTo("/admin/login");
    };
    if (authenticated.value && ((_a = dataUser.value) == null ? void 0 : _a.type) != "users") {
      logUserOut();
      [__temp, __restore] = withAsyncContext(() => navigateTo("/admin/login")), await __temp, __restore();
    }
    if (!authenticated.value) {
      console.log("!!!!!!!!!");
      [__temp, __restore] = withAsyncContext(() => navigateTo("/admin/login")), await __temp, __restore();
    }
    const items = ref([
      {
        label: "Home",
        icon: "pi pi-home",
        link: "/admin/"
      },
      {
        label: "Usu\xE1rios",
        icon: "pi pi-users",
        link: "/admin/users"
      },
      {
        label: "Clientes",
        icon: "pi pi-id-card",
        link: "/admin/clients"
      },
      {
        label: "Planos",
        icon: "pi pi-id-card",
        link: "/admin/client_planos"
      },
      {
        label: "R\xF3tulos",
        icon: "pi pi-id-card",
        link: "/admin/products"
      },
      {
        label: "Relat\xF3rios",
        icon: "pi pi-file-pdf",
        link: "/admin/reports"
      },
      // },
      {
        label: "Sistema",
        icon: "pi pi-sliders-h",
        items: [
          {
            label: "Configura\xE7\xF5es",
            icon: "pi pi-bolt",
            link: "/admin/config"
          },
          {
            label: "Enviar emails",
            icon: "pi pi-server",
            link: "/admin/sendemail"
            // shortcut: '⌘+B'
          }
          // ,
          // {
          //     label: 'UI Kit',
          //     icon: 'pi pi-pencil',
          //     shortcut: '⌘+U'
          // },
          // {
          //     separator: true
          // },
          // {
          //     label: 'Templates',
          //     icon: 'pi pi-palette',
          //     items: [
          //         {
          //             label: 'Apollo',
          //             icon: 'pi pi-palette',
          //             badge: 2
          //         },
          //         {
          //             label: 'Ultima',
          //             icon: 'pi pi-palette',
          //             badge: 3
          //         }
          //     ]
          // }
        ]
      }
      // {
      //     label: 'Contact',
      //     icon: 'pi pi-envelope',
      //     badge: 3
      // }
    ]);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Menubar = script;
      const _component_NuxtLink = __nuxt_component_0;
      const _component_Badge = script$1;
      const _component_Button = script$2;
      const _directive_ripple = resolveDirective("ripple");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Menubar, { model: unref(items) }, {
        start: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="mr-5" style="${ssrRenderStyle({ "width": "100px", "border-radius": ".3rem" })}" data-v-213ae9e4${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "mr-5",
                style: { "width": "100px", "border-radius": ".3rem" }
              })
            ];
          }
        }),
        item: withCtx(({ item, props, hasSubmenu, root }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<a${ssrRenderAttrs(mergeProps({ class: "flex align-items-center" }, props.action, ssrGetDirectiveProps(_ctx, _directive_ripple)))} data-v-213ae9e4${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: item.link
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<span class="${ssrRenderClass([item.icon, "menulink"])}" data-v-213ae9e4${_scopeId2}></span><span class="ml-2 menulink" data-v-213ae9e4${_scopeId2}>${ssrInterpolate(item.label)}</span>`);
                } else {
                  return [
                    createVNode("span", {
                      class: [item.icon, "menulink"]
                    }, null, 2),
                    createVNode("span", { class: "ml-2 menulink" }, toDisplayString(item.label), 1)
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            if (item.badge) {
              _push2(ssrRenderComponent(_component_Badge, {
                class: { "ml-auto": !root, "ml-2": root },
                value: item.badge
              }, null, _parent2, _scopeId));
            } else {
              _push2(`<!---->`);
            }
            if (item.shortcut) {
              _push2(`<span class="ml-auto border-1 surface-border border-round surface-100 text-xs p-1" data-v-213ae9e4${_scopeId}>${ssrInterpolate(item.shortcut)}</span>`);
            } else {
              _push2(`<!---->`);
            }
            if (hasSubmenu) {
              _push2(`<i class="${ssrRenderClass(["pi pi-angle-down", { "pi-angle-down ml-2": root, "pi-angle-right ml-auto": !root }])}" data-v-213ae9e4${_scopeId}></i>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</a>`);
          } else {
            return [
              withDirectives((openBlock(), createBlock("a", mergeProps({ class: "flex align-items-center" }, props.action), [
                createVNode(_component_NuxtLink, {
                  to: item.link
                }, {
                  default: withCtx(() => [
                    createVNode("span", {
                      class: [item.icon, "menulink"]
                    }, null, 2),
                    createVNode("span", { class: "ml-2 menulink" }, toDisplayString(item.label), 1)
                  ]),
                  _: 2
                }, 1032, ["to"]),
                item.badge ? (openBlock(), createBlock(_component_Badge, {
                  key: 0,
                  class: { "ml-auto": !root, "ml-2": root },
                  value: item.badge
                }, null, 8, ["class", "value"])) : createCommentVNode("", true),
                item.shortcut ? (openBlock(), createBlock("span", {
                  key: 1,
                  class: "ml-auto border-1 surface-border border-round surface-100 text-xs p-1"
                }, toDisplayString(item.shortcut), 1)) : createCommentVNode("", true),
                hasSubmenu ? (openBlock(), createBlock("i", {
                  key: 2,
                  class: ["pi pi-angle-down", { "pi-angle-down ml-2": root, "pi-angle-right ml-auto": !root }]
                }, null, 2)) : createCommentVNode("", true)
              ], 16)), [
                [_directive_ripple]
              ])
            ];
          }
        }),
        end: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b;
          if (_push2) {
            _push2(`<div class="flex align-items-center gap-2" data-v-213ae9e4${_scopeId}><span style="${ssrRenderStyle({ "font-size": "18px" })}" class="mr-3" data-v-213ae9e4${_scopeId}>${ssrInterpolate((_a2 = unref(dataUser)) == null ? void 0 : _a2.username)}</span>`);
            _push2(ssrRenderComponent(_component_Button, {
              label: "Sair",
              onClick: logOut,
              severity: "contrast",
              class: "mr-5"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex align-items-center gap-2" }, [
                createVNode("span", {
                  style: { "font-size": "18px" },
                  class: "mr-3"
                }, toDisplayString((_b = unref(dataUser)) == null ? void 0 : _b.username), 1),
                createVNode(_component_Button, {
                  label: "Sair",
                  onClick: logOut,
                  severity: "contrast",
                  class: "mr-5"
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      {
        _push(`<!---->`);
      }
      {
        _push(`<!---->`);
      }
      _push(`<div class="p-4" data-v-213ae9e4>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/defaultadmin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const defaultadmin = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-213ae9e4"]]);

export { defaultadmin as default };
//# sourceMappingURL=defaultadmin-BZ8zwjd5.mjs.map
