import script from './menubar.esm-D1g4fCsl.mjs';
import script$1 from './button.esm-BXyYR5vb.mjs';
import { u as useRouter, a as useCookie, b as useAuthStore, s as storeToRefs, d as db } from '../server.mjs';
import { withAsyncContext, withCtx, createVNode, unref, toDisplayString, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderAttr, ssrRenderStyle, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';
import { _ as _imports_0 } from './logo-BTo1DBng.mjs';
import { _ as _export_sfc } from './_plugin-vue_export-helper-1tPrXgE0.mjs';
import './index.esm-CV5JRnen.mjs';
import './baseicon.esm-DmfInns-.mjs';
import './basecomponent.esm-BVGT0S0N.mjs';
import './index.esm-CdlNfHzJ.mjs';
import './index.esm-DHCZPrg6.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'node:fs';
import 'node:url';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import './badge.esm-B9G3W3GA.mjs';
import './index.esm-D9hkvMdq.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';

const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const router = useRouter();
    const dataUser = useCookie("dataUser");
    console.log("dataUser:", !dataUser.value);
    const { logUserOut } = useAuthStore();
    const { authenticated } = storeToRefs(useAuthStore());
    const sqlret = ([__temp, __restore] = withAsyncContext(() => db.get(`select * from client_planos where id = ${dataUser.value.plano}`)), __temp = await __temp, __restore(), __temp);
    const userPlanoName = sqlret[0].name;
    const logOut = () => {
      logUserOut();
      router.push("/login");
    };
    if (!authenticated.value || !dataUser.value) {
      console.log("!!!!!!!!!");
      router.push("login");
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_Menubar = script;
      const _component_Button = script$1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Menubar, { style: { "background-color": "#73a1a5" } }, {
        start: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} class="mr-5" style="${ssrRenderStyle({ "width": "100px", "border-radius": ".3rem" })}" data-v-74744641${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                class: "mr-5",
                style: { "width": "100px", "border-radius": ".3rem" }
              })
            ];
          }
        }),
        end: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2;
          if (_push2) {
            _push2(`<div class="flex align-items-center gap-2" data-v-74744641${_scopeId}><span style="${ssrRenderStyle({ "font-size": "18px" })}" class="mr-3" data-v-74744641${_scopeId}>${ssrInterpolate((_a2 = unref(dataUser)) == null ? void 0 : _a2.username)}</span>`);
            _push2(ssrRenderComponent(_component_Button, {
              label: "Sair",
              onClick: logOut,
              severity: "contrast",
              class: "mr-5"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex align-items-center gap-2" }, [
                createVNode("span", {
                  style: { "font-size": "18px" },
                  class: "mr-3"
                }, toDisplayString((_b2 = unref(dataUser)) == null ? void 0 : _b2.username), 1),
                createVNode(_component_Button, {
                  label: "Sair",
                  onClick: logOut,
                  severity: "contrast",
                  class: "mr-5"
                })
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      if (unref(dataUser)) {
        _push(`<div class="mt-1 p-2" style="${ssrRenderStyle({ "background-color": "#9f763a", "border-radius": "8px" })}" data-v-74744641><span class="title" data-v-74744641>Usu\xE1rio:</span> ${ssrInterpolate((_a = unref(dataUser)) == null ? void 0 : _a.username)} / <span class="title" data-v-74744641>Plano:</span> ${ssrInterpolate(unref(userPlanoName))} / <span class="title" data-v-74744641>Ades\xE3o:</span> ${ssrInterpolate((_b = unref(dataUser)) == null ? void 0 : _b.data_adesao)} / <span class="title" data-v-74744641>Encerramento:</span> ${ssrInterpolate((_c = unref(dataUser)) == null ? void 0 : _c.data_limite)} `);
        if ((_d = unref(dataUser)) == null ? void 0 : _d.products) {
          _push(`<span data-v-74744641>| Produtos: ${ssrInterpolate((_e = unref(dataUser)) == null ? void 0 : _e.products.map((x) => x.name).join(","))}</span>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-74744641"]]);

export { _default as default };
//# sourceMappingURL=default-CJAzqAZ_.mjs.map
