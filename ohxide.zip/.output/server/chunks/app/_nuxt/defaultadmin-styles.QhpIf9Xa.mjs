import { p as primeflex } from './download-styles-1.mjs-Bj68gDig.mjs';
import { d as defaultadmin_vue_vue_type_style_index_0_scoped_213ae9e4_lang } from './defaultadmin-styles-2.mjs-BMu5GLk9.mjs';

const defaultadminStyles_QhpIf9Xa = [primeflex, defaultadmin_vue_vue_type_style_index_0_scoped_213ae9e4_lang];

export { defaultadminStyles_QhpIf9Xa as default };
//# sourceMappingURL=defaultadmin-styles.QhpIf9Xa.mjs.map
