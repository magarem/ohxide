import { d as defaultadmin_vue_vue_type_style_index_0_scoped_213ae9e4_lang } from './defaultadmin-styles-2.mjs-BMu5GLk9.mjs';

const defaultadminStyles_T9GDuzk1 = [defaultadmin_vue_vue_type_style_index_0_scoped_213ae9e4_lang];

export { defaultadminStyles_T9GDuzk1 as default };
//# sourceMappingURL=defaultadmin-styles.T9GDuzk1.mjs.map
