const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.mX9XA2bS.mjs').then(interopDefault),
  "pages/download.vue": () => import('./_nuxt/download-styles.C0SNoOW_.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/download-styles.C0SNoOW_.mjs').then(interopDefault),
  "pages/admin/login.vue": () => import('./_nuxt/login-styles.CxozEz_Z.mjs').then(interopDefault),
  "pages/login.vue": () => import('./_nuxt/login-styles.CIoDIJw_.mjs').then(interopDefault),
  "pages/redefinirsenha.vue": () => import('./_nuxt/redefinirsenha-styles.13OSHVI4.mjs').then(interopDefault),
  "pages/usersettings.vue": () => import('./_nuxt/usersettings-styles.BXw4whrt.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "pages/login.vue?vue&type=style&index=0&scoped=29724000&lang.css": () => import('./_nuxt/login-styles.CIoDIJw_.mjs').then(interopDefault),
  "pages/admin/login.vue?vue&type=style&index=0&scoped=497febc3&lang.css": () => import('./_nuxt/login-styles.CxozEz_Z.mjs').then(interopDefault),
  "pages/redefinirsenha.vue?vue&type=style&index=0&scoped=a5270efc&lang.css": () => import('./_nuxt/redefinirsenha-styles.DbIY00Rl.mjs').then(interopDefault),
  "pages/usersettings.vue?vue&type=style&index=0&scoped=dbf4e8b8&lang.css": () => import('./_nuxt/usersettings-styles.DN31Gn-S.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue?vue&type=style&index=0&scoped=ccd3db62&lang.css": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue?vue&type=style&index=0&scoped=df79c84d&lang.css": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.CLggdrM1.mjs').then(interopDefault),
  "layouts/defaultadmin.vue": () => import('./_nuxt/defaultadmin-styles.Cnnn2qWr.mjs').then(interopDefault),
  "layouts/default.vue?vue&type=style&index=0&scoped=ab2124d3&lang.css": () => import('./_nuxt/default-styles.zm_1YOOt.mjs').then(interopDefault),
  "layouts/defaultadmin.vue?vue&type=style&index=0&scoped=5f0dffad&lang.css": () => import('./_nuxt/defaultadmin-styles.ButWzZ62.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
