const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.mX9XA2bS.mjs').then(interopDefault),
  "pages/admin/login.vue": () => import('./_nuxt/login-styles.CxozEz_Z.mjs').then(interopDefault),
  "pages/download.vue": () => import('./_nuxt/download-styles.C0SNoOW_.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/download-styles.C0SNoOW_.mjs').then(interopDefault),
  "pages/usersettings.vue": () => import('./_nuxt/usersettings-styles.D0N7y-K1.mjs').then(interopDefault),
  "pages/login.vue": () => import('./_nuxt/login-styles.Dooe7cCC.mjs').then(interopDefault),
  "pages/admin/login.vue?vue&type=style&index=0&scoped=497febc3&lang.css": () => import('./_nuxt/login-styles.CxozEz_Z.mjs').then(interopDefault),
  "pages/usersettings.vue?vue&type=style&index=0&scoped=8932bcd6&lang.css": () => import('./_nuxt/usersettings-styles.Bxvnl4Zx.mjs').then(interopDefault),
  "pages/login.vue?vue&type=style&index=0&scoped=ef16ad92&lang.css": () => import('./_nuxt/login-styles.Dooe7cCC.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue?vue&type=style&index=0&scoped=ccd3db62&lang.css": () => import('./_nuxt/error-404-styles.DKrRPVnW.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue?vue&type=style&index=0&scoped=df79c84d&lang.css": () => import('./_nuxt/error-500-styles.TTVQqs5q.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.D9EYhXrh.mjs').then(interopDefault),
  "layouts/defaultadmin.vue": () => import('./_nuxt/defaultadmin-styles.Cnnn2qWr.mjs').then(interopDefault),
  "layouts/default.vue?vue&type=style&index=0&scoped=8691ded8&lang.css": () => import('./_nuxt/default-styles.D9EYhXrh.mjs').then(interopDefault),
  "layouts/defaultadmin.vue?vue&type=style&index=0&scoped=5f0dffad&lang.css": () => import('./_nuxt/defaultadmin-styles.ButWzZ62.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
