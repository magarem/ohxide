const client_manifest = {
  "_Magacrud.C_skaHWg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Magacrud.C_skaHWg.js",
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "styles.BPUKciI7.css": {
    "file": "styles.BPUKciI7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeicons.Dk_eWBPK.eot": {
    "file": "primeicons.Dk_eWBPK.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "primeicons.DsZ1W7-Z.woff2": {
    "file": "primeicons.DsZ1W7-Z.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "primeicons.CCFeZR6K.woff": {
    "file": "primeicons.CCFeZR6K.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "primeicons.NDVQFXzF.ttf": {
    "file": "primeicons.NDVQFXzF.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "primeicons.BubJZjaf.svg": {
    "file": "primeicons.BubJZjaf.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "flags_responsive.DbRDn7iy.png": {
    "file": "flags_responsive.DbRDn7iy.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.DlAUqK2U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.DlAUqK2U.js"
  },
  "_basecomponent.esm.g5c2XKhn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "basecomponent.esm.g5c2XKhn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_baseicon.esm.T9zWXEvn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "baseicon.esm.T9zWXEvn.js",
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.7YxQZ9de.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.7YxQZ9de.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.B5YBx2CV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.B5YBx2CV.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BBHK5Npe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BBHK5Npe.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BIpQOyzx.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BIpQOyzx.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BlX3JZvm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BlX3JZvm.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Bv_u7NsB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Bv_u7NsB.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CQMqV76G.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CQMqV76G.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CXXwTmEX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CXXwTmEX.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CbTOfI3O.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CbTOfI3O.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CyI3DoL2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CyI3DoL2.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.D3qb0LBZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.D3qb0LBZ.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DRhq6M-k.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DRhq6M-k.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DsOWDPur.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DsOWDPur.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DwOtKpnD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DwOtKpnD.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.JWiplkJ0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.JWiplkJ0.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.LjMzGoO0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.LjMzGoO0.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.X9AORYoS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.X9AORYoS.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.flSZQKlZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.flSZQKlZ.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.sj9IfDyL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.sj9IfDyL.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.wHnEKdu6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.wHnEKdu6.js",
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo.DoPtIFBH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.DoPtIFBH.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_moment.Cl4UOzQZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "moment.Cl4UOzQZ.js"
  },
  "_nuxt-link.C-e6rnsf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.C-e6rnsf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_overlayeventbus.esm.DgS7zUB4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlayeventbus.esm.DgS7zUB4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_portal.esm.BsDadrOn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "portal.esm.BsDadrOn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_primeflex.!~{02k}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "primeflex.DHMfoBAW.css",
    "src": "_primeflex.!~{02k}~.js"
  },
  "_schemas.C4Od0iqV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "schemas.C4Od0iqV.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_styles.!~{02h}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "styles.BPUKciI7.css",
    "src": "_styles.!~{02h}~.js"
  },
  "_vue.f36acd1f.DNdk67hI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.DNdk67hI.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/demo/flags/flags_responsive.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "flags_responsive.DbRDn7iy.png",
    "src": "assets/demo/flags/flags_responsive.png"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.CFA2yLr3.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.DoPtIFBH.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.JWiplkJ0.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.B5YBx2CV.js"
    ],
    "css": []
  },
  "default.DdDJXt-Z.css": {
    "file": "default.DdDJXt-Z.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeflex.DHMfoBAW.css": {
    "file": "primeflex.DHMfoBAW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/defaultadmin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "defaultadmin.BsBd1ruP.js",
    "src": "layouts/defaultadmin.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.DoPtIFBH.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.JWiplkJ0.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.B5YBx2CV.js"
    ],
    "css": []
  },
  "defaultadmin.D9jIJCFZ.css": {
    "file": "defaultadmin.D9jIJCFZ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.D1U3e-Lu.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.C-e6rnsf.js",
      "_vue.f36acd1f.DNdk67hI.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-404.BChdqdSe.css": {
    "file": "error-404.BChdqdSe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.D6SrO9fe.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_vue.f36acd1f.DNdk67hI.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.B39Jqr7T.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/primevue/autocomplete/autocomplete.esm.js",
      "node_modules/primevue/calendar/calendar.esm.js",
      "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/chips/chips.esm.js",
      "node_modules/primevue/colorpicker/colorpicker.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/floatlabel/floatlabel.esm.js",
      "node_modules/primevue/iconfield/iconfield.esm.js",
      "node_modules/primevue/inputgroup/inputgroup.esm.js",
      "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
      "node_modules/primevue/inputicon/inputicon.esm.js",
      "node_modules/primevue/inputmask/inputmask.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/inputswitch/inputswitch.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/knob/knob.esm.js",
      "node_modules/primevue/listbox/listbox.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/password/password.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/selectbutton/selectbutton.esm.js",
      "node_modules/primevue/slider/slider.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/togglebutton/togglebutton.esm.js",
      "node_modules/primevue/treeselect/treeselect.esm.js",
      "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/speeddial/speeddial.esm.js",
      "node_modules/primevue/splitbutton/splitbutton.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/row/row.esm.js",
      "node_modules/primevue/columngroup/columngroup.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dataview/dataview.esm.js",
      "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
      "node_modules/primevue/orderlist/orderlist.esm.js",
      "node_modules/primevue/organizationchart/organizationchart.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/picklist/picklist.esm.js",
      "node_modules/primevue/tree/tree.esm.js",
      "node_modules/primevue/treetable/treetable.esm.js",
      "node_modules/primevue/timeline/timeline.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
      "node_modules/primevue/divider/divider.esm.js",
      "node_modules/primevue/fieldset/fieldset.esm.js",
      "node_modules/primevue/panel/panel.esm.js",
      "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
      "node_modules/primevue/splitter/splitter.esm.js",
      "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
      "node_modules/primevue/tabview/tabview.esm.js",
      "node_modules/primevue/tabpanel/tabpanel.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
      "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
      "node_modules/primevue/sidebar/sidebar.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
      "node_modules/primevue/contextmenu/contextmenu.esm.js",
      "node_modules/primevue/dock/dock.esm.js",
      "node_modules/primevue/menu/menu.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/primevue/megamenu/megamenu.esm.js",
      "node_modules/primevue/panelmenu/panelmenu.esm.js",
      "node_modules/primevue/steps/steps.esm.js",
      "node_modules/primevue/tabmenu/tabmenu.esm.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/carousel/carousel.esm.js",
      "node_modules/primevue/galleria/galleria.esm.js",
      "node_modules/primevue/image/image.esm.js",
      "node_modules/primevue/avatar/avatar.esm.js",
      "node_modules/primevue/avatargroup/avatargroup.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/blockui/blockui.esm.js",
      "node_modules/primevue/chip/chip.esm.js",
      "node_modules/primevue/inplace/inplace.esm.js",
      "node_modules/primevue/metergroup/metergroup.esm.js",
      "node_modules/primevue/scrolltop/scrolltop.esm.js",
      "node_modules/primevue/skeleton/skeleton.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/tag/tag.esm.js",
      "node_modules/primevue/terminal/terminal.esm.js",
      "layouts/default.vue",
      "layouts/defaultadmin.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "_globalCSS": true
  },
  "node_modules/primeicons/fonts/primeicons.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "primeicons.Dk_eWBPK.eot",
    "src": "node_modules/primeicons/fonts/primeicons.eot"
  },
  "node_modules/primeicons/fonts/primeicons.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "primeicons.BubJZjaf.svg",
    "src": "node_modules/primeicons/fonts/primeicons.svg"
  },
  "node_modules/primeicons/fonts/primeicons.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "primeicons.NDVQFXzF.ttf",
    "src": "node_modules/primeicons/fonts/primeicons.ttf"
  },
  "node_modules/primeicons/fonts/primeicons.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "primeicons.CCFeZR6K.woff",
    "src": "node_modules/primeicons/fonts/primeicons.woff"
  },
  "node_modules/primeicons/fonts/primeicons.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "primeicons.DsZ1W7-Z.woff2",
    "src": "node_modules/primeicons/fonts/primeicons.woff2"
  },
  "node_modules/primevue/accordion/accordion.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordion.esm.DavO0ieL.js",
    "src": "node_modules/primevue/accordion/accordion.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/accordiontab/accordiontab.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordiontab.esm.wSDsBzlR.js",
    "src": "node_modules/primevue/accordiontab/accordiontab.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/autocomplete/autocomplete.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "autocomplete.esm.Cqu0Ze8c.js",
    "src": "node_modules/primevue/autocomplete/autocomplete.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.sj9IfDyL.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/avatar/avatar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.esm.C4WnzDAX.js",
    "src": "node_modules/primevue/avatar/avatar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/avatargroup/avatargroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatargroup.esm.CcGFvqNu.js",
    "src": "node_modules/primevue/avatargroup/avatargroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/badge/badge.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "badge.esm.D6Ri2A6v.js",
    "src": "node_modules/primevue/badge/badge.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/blockui/blockui.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "blockui.esm.CfyuzjRw.js",
    "src": "node_modules/primevue/blockui/blockui.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/breadcrumb/breadcrumb.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "breadcrumb.esm.DlLrjb5X.js",
    "src": "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.wHnEKdu6.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/button/button.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "button.esm.BfFv5n-z.js",
    "src": "node_modules/primevue/button/button.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/calendar/calendar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "calendar.esm.DL500sgd.js",
    "src": "node_modules/primevue/calendar/calendar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.DwOtKpnD.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.flSZQKlZ.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js"
    ]
  },
  "node_modules/primevue/card/card.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "card.esm.CVAKQ5bf.js",
    "src": "node_modules/primevue/card/card.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/carousel/carousel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "carousel.esm.9UWCBWaH.js",
    "src": "node_modules/primevue/carousel/carousel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DRhq6M-k.js",
      "_index.esm.DwOtKpnD.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.flSZQKlZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/cascadeselect/cascadeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cascadeselect.esm.h1Cni4On.js",
    "src": "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.B5YBx2CV.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CyI3DoL2.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/checkbox/checkbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.esm.DdBM2va3.js",
    "src": "node_modules/primevue/checkbox/checkbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BIpQOyzx.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/chip/chip.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chip.esm.DHNaxpdg.js",
    "src": "node_modules/primevue/chip/chip.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.sj9IfDyL.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/chips/chips.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chips.esm.CWie9nHG.js",
    "src": "node_modules/primevue/chips/chips.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.sj9IfDyL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/colorpicker/colorpicker.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "colorpicker.esm.Dk4pWDze.js",
    "src": "node_modules/primevue/colorpicker/colorpicker.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/column/column.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "column.esm.MMUU2OaY.js",
    "src": "node_modules/primevue/column/column.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/columngroup/columngroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "columngroup.esm.CWreY_MA.js",
    "src": "node_modules/primevue/columngroup/columngroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/confirmdialog/confirmdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmdialog.esm.HxDjp6z-.js",
    "src": "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.LjMzGoO0.js",
      "_portal.esm.BsDadrOn.js"
    ]
  },
  "node_modules/primevue/confirmpopup/confirmpopup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmpopup.esm.ME-CpDEI.js",
    "src": "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/contextmenu/contextmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contextmenu.esm.DPhrD14j.js",
    "src": "node_modules/primevue/contextmenu/contextmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.B5YBx2CV.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/datatable/datatable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "datatable.esm.BE0DtH4h.js",
    "src": "node_modules/primevue/datatable/datatable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_portal.esm.BsDadrOn.js",
      "_index.esm.CbTOfI3O.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B5YBx2CV.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CXXwTmEX.js"
    ]
  },
  "node_modules/primevue/dataview/dataview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataview.esm.D9uYKSWx.js",
    "src": "node_modules/primevue/dataview/dataview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.Bv_u7NsB.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B5YBx2CV.js"
    ]
  },
  "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataviewlayoutoptions.esm.BQ1a3vp5.js",
    "src": "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.JWiplkJ0.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/deferredcontent/deferredcontent.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "deferredcontent.esm.CMarj_ov.js",
    "src": "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dialog/dialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.esm.J6GV5nBJ.js",
    "src": "node_modules/primevue/dialog/dialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.LjMzGoO0.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/divider/divider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.esm.JJiy41mP.js",
    "src": "node_modules/primevue/divider/divider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dock/dock.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dock.esm.BTRnMFgg.js",
    "src": "node_modules/primevue/dock/dock.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dropdown/dropdown.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dropdown.esm.BJ5Rv5Aj.js",
    "src": "node_modules/primevue/dropdown/dropdown.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dynamicdialog.esm.tfCj5AGo.js",
    "src": "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.LjMzGoO0.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_portal.esm.BsDadrOn.js"
    ]
  },
  "node_modules/primevue/fieldset/fieldset.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fieldset.esm.BH58Upk4.js",
    "src": "node_modules/primevue/fieldset/fieldset.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.7YxQZ9de.js",
      "_index.esm.BBHK5Npe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/fileupload/fileupload.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fileupload.esm.DdlMVcpm.js",
    "src": "node_modules/primevue/fileupload/fileupload.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.LjMzGoO0.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.sj9IfDyL.js"
    ]
  },
  "node_modules/primevue/floatlabel/floatlabel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "floatlabel.esm.BiNoEu5N.js",
    "src": "node_modules/primevue/floatlabel/floatlabel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/galleria/galleria.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "galleria.esm.CCwQBgLW.js",
    "src": "node_modules/primevue/galleria/galleria.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.DwOtKpnD.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.flSZQKlZ.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/iconfield/iconfield.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "iconfield.esm.CcOJTOBW.js",
    "src": "node_modules/primevue/iconfield/iconfield.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/image/image.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "image.esm.BbWmos3q.js",
    "src": "node_modules/primevue/image/image.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CQMqV76G.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.LjMzGoO0.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/inlinemessage/inlinemessage.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inlinemessage.esm.CmClGOXy.js",
    "src": "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.sj9IfDyL.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/inplace/inplace.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inplace.esm.CcP-H5Em.js",
    "src": "node_modules/primevue/inplace/inplace.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.LjMzGoO0.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/inputgroup/inputgroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroup.esm.DrhsK9gj.js",
    "src": "node_modules/primevue/inputgroup/inputgroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroupaddon.esm.D0k9bF1k.js",
    "src": "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputicon/inputicon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputicon.esm.7VI5lJkU.js",
    "src": "node_modules/primevue/inputicon/inputicon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputmask/inputmask.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputmask.esm.CNJvg4dq.js",
    "src": "node_modules/primevue/inputmask/inputmask.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/inputnumber/inputnumber.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputnumber.esm.DCDoCJri.js",
    "src": "node_modules/primevue/inputnumber/inputnumber.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/inputswitch/inputswitch.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputswitch.esm.CwCqXdQX.js",
    "src": "node_modules/primevue/inputswitch/inputswitch.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputtext/inputtext.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputtext.esm.1_Zq-az7.js",
    "src": "node_modules/primevue/inputtext/inputtext.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/knob/knob.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "knob.esm.vu6s5DSt.js",
    "src": "node_modules/primevue/knob/knob.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/listbox/listbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "listbox.esm.ChWClOg7.js",
    "src": "node_modules/primevue/listbox/listbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CXXwTmEX.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.CyI3DoL2.js"
    ]
  },
  "node_modules/primevue/megamenu/megamenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "megamenu.esm.D5I8YDNE.js",
    "src": "node_modules/primevue/megamenu/megamenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.JWiplkJ0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.B5YBx2CV.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/menu/menu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.esm.D8yDFOV3.js",
    "src": "node_modules/primevue/menu/menu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/menubar/menubar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menubar.esm.DCNJptvN.js",
    "src": "node_modules/primevue/menubar/menubar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.JWiplkJ0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.B5YBx2CV.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/message/message.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "message.esm.5ISQMqo4.js",
    "src": "node_modules/primevue/message/message.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/metergroup/metergroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "metergroup.esm.DG2MnqES.js",
    "src": "node_modules/primevue/metergroup/metergroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/multiselect/multiselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "multiselect.esm.C_s-vKzg.js",
    "src": "node_modules/primevue/multiselect/multiselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/orderlist/orderlist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "orderlist.esm.C0W9FNo7.js",
    "src": "node_modules/primevue/orderlist/orderlist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.D3qb0LBZ.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/organizationchart/organizationchart.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "organizationchart.esm.Ct7QHwzL.js",
    "src": "node_modules/primevue/organizationchart/organizationchart.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.flSZQKlZ.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/overlaypanel/overlaypanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlaypanel.esm.i5QDzwee.js",
    "src": "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/paginator/paginator.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "paginator.esm.Bvyea_wI.js",
    "src": "node_modules/primevue/paginator/paginator.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.B5YBx2CV.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js"
    ]
  },
  "node_modules/primevue/panel/panel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panel.esm.ABg0tPr5.js",
    "src": "node_modules/primevue/panel/panel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.7YxQZ9de.js",
      "_index.esm.BBHK5Npe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/panelmenu/panelmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panelmenu.esm.Cv9mXpsn.js",
    "src": "node_modules/primevue/panelmenu/panelmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/password/password.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "password.esm.BBm9roZ9.js",
    "src": "node_modules/primevue/password/password.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CQMqV76G.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/picklist/picklist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "picklist.esm.D31H92WW.js",
    "src": "node_modules/primevue/picklist/picklist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.D3qb0LBZ.js",
      "_index.esm.Bv_u7NsB.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/progressbar/progressbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressbar.esm.DquODvZB.js",
    "src": "node_modules/primevue/progressbar/progressbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/progressspinner/progressspinner.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressspinner.esm.C8y-zvpR.js",
    "src": "node_modules/primevue/progressspinner/progressspinner.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/radiobutton/radiobutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "radiobutton.esm.C9VTZebO.js",
    "src": "node_modules/primevue/radiobutton/radiobutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/rating/rating.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rating.esm.bcKGGl9S.js",
    "src": "node_modules/primevue/rating/rating.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-italic.var.DhD-tpjY.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2"
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-roman.var.C-r5W2Hj.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2"
  },
  "node_modules/primevue/row/row.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "row.esm.Bi_czHX6.js",
    "src": "node_modules/primevue/row/row.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/scrollpanel/scrollpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollpanel.esm.B70vkL6R.js",
    "src": "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/scrolltop/scrolltop.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrolltop.esm.C0ijuWe_.js",
    "src": "node_modules/primevue/scrolltop/scrolltop.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.flSZQKlZ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/selectbutton/selectbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "selectbutton.esm.Bzy5r8y8.js",
    "src": "node_modules/primevue/selectbutton/selectbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/sidebar/sidebar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sidebar.esm.CEd5apuH.js",
    "src": "node_modules/primevue/sidebar/sidebar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.LjMzGoO0.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/skeleton/skeleton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "skeleton.esm.CRebi0ah.js",
    "src": "node_modules/primevue/skeleton/skeleton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/slider/slider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "slider.esm.CfJa1bui.js",
    "src": "node_modules/primevue/slider/slider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/speeddial/speeddial.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "speeddial.esm.mkOvKvKf.js",
    "src": "node_modules/primevue/speeddial/speeddial.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BBHK5Npe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/splitbutton/splitbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitbutton.esm.Cn2NAOG6.js",
    "src": "node_modules/primevue/splitbutton/splitbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DRhq6M-k.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "_index.esm.B5YBx2CV.js"
    ]
  },
  "node_modules/primevue/splitter/splitter.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitter.esm.BC-4StmK.js",
    "src": "node_modules/primevue/splitter/splitter.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/splitterpanel/splitterpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitterpanel.esm.DvXmM6G_.js",
    "src": "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/steps/steps.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "steps.esm.DN51dzjv.js",
    "src": "node_modules/primevue/steps/steps.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/tabmenu/tabmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabmenu.esm.BRgwelbL.js",
    "src": "node_modules/primevue/tabmenu/tabmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/tabpanel/tabpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabpanel.esm.CT4Lfdxm.js",
    "src": "node_modules/primevue/tabpanel/tabpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tabview/tabview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabview.esm.CmMbxskj.js",
    "src": "node_modules/primevue/tabview/tabview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DwOtKpnD.js",
      "_index.esm.wHnEKdu6.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/tag/tag.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.esm.Cq_cMKig.js",
    "src": "node_modules/primevue/tag/tag.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/terminal/terminal.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terminal.esm.DroHVloU.js",
    "src": "node_modules/primevue/terminal/terminal.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/textarea/textarea.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "textarea.esm.DbEQEV5X.js",
    "src": "node_modules/primevue/textarea/textarea.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tieredmenu/tieredmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tieredmenu.esm.BxVIPqGC.js",
    "src": "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.B5YBx2CV.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/timeline/timeline.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "timeline.esm.S542AtiT.js",
    "src": "node_modules/primevue/timeline/timeline.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/toast/toast.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toast.esm.9yq2ZUXe.js",
    "src": "node_modules/primevue/toast/toast.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/togglebutton/togglebutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "togglebutton.esm.Dm8AwEZY.js",
    "src": "node_modules/primevue/togglebutton/togglebutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ]
  },
  "node_modules/primevue/toolbar/toolbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toolbar.esm.Dd2pTxBS.js",
    "src": "node_modules/primevue/toolbar/toolbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tree/tree.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tree.esm.DLtkhPp3.js",
    "src": "node_modules/primevue/tree/tree.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.7YxQZ9de.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/treeselect/treeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treeselect.esm.N3kdgwiL.js",
    "src": "node_modules/primevue/treeselect/treeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DRhq6M-k.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/tree/tree.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.7YxQZ9de.js"
    ]
  },
  "node_modules/primevue/treetable/treetable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treetable.esm.BWIp5-S4.js",
    "src": "node_modules/primevue/treetable/treetable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.7YxQZ9de.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B5YBx2CV.js"
    ]
  },
  "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tristatecheckbox.esm.B85Z7tJc.js",
    "src": "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BIpQOyzx.js",
      "_index.esm.LjMzGoO0.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "node_modules/primevue/virtualscroller/virtualscroller.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "virtualscroller.esm.BudiePSQ.js",
    "src": "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CyI3DoL2.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_baseicon.esm.T9zWXEvn.js"
    ]
  },
  "pages/admin/client_planos.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client_planos.bIwFj01B.js",
    "src": "pages/admin/client_planos.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.C_skaHWg.js",
      "_schemas.C4Od0iqV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/clients.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clients.CQSmRue1.js",
    "src": "pages/admin/clients.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.C_skaHWg.js",
      "_moment.Cl4UOzQZ.js",
      "_schemas.C4Od0iqV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/config.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.DB59Z2Kt.js",
    "src": "pages/admin/config.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js"
    ]
  },
  "pages/admin/date.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date.2R71Duq6.js",
    "src": "pages/admin/date.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.Cp3Hbh84.js",
    "src": "pages/admin/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "_nuxt-link.C-e6rnsf.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/index_res.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index_res.C322TEBl.js",
    "src": "pages/admin/index_res.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.C_skaHWg.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.BLGGLrSE.js",
    "src": "pages/admin/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.DoPtIFBH.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.g5c2XKhn.js"
    ],
    "css": []
  },
  "login.BH5VzkIW.css": {
    "file": "login.BH5VzkIW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/products.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "products.W-av9RKw.js",
    "src": "pages/admin/products.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.C_skaHWg.js",
      "_schemas.C4Od0iqV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/reports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "reports.Dk9WcV-4.js",
    "src": "pages/admin/reports.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.C_skaHWg.js",
      "_schemas.C4Od0iqV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/sendemail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sendemail.X5oclLAt.js",
    "src": "pages/admin/sendemail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.CyI3DoL2.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.D6dvntrg.js",
    "src": "pages/admin/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/users.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "users.CW14Mayb.js",
    "src": "pages/admin/users.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.C_skaHWg.js",
      "_schemas.C4Od0iqV.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud copy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud copy.CTB_iO-T.js",
    "src": "pages/crud copy.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_index.esm.BBHK5Npe.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "_index.esm.B5YBx2CV.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.CbTOfI3O.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud.CAbiCFeN.js",
    "src": "pages/crud.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/download.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "download.BcFmSvtE.js",
    "src": "pages/download.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.DoPtIFBH.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js"
    ],
    "css": []
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.BuA2Fdd3.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js"
    ],
    "css": []
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.DZy4VJmF.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.DoPtIFBH.js",
      "__plugin-vue_export-helper.DlAUqK2U.js"
    ],
    "css": []
  },
  "login.Dqu076QK.css": {
    "file": "login.Dqu076QK.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/redefinirsenha.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "redefinirsenha.QdGvpwL4.js",
    "src": "pages/redefinirsenha.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.DoPtIFBH.js",
      "_moment.Cl4UOzQZ.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js"
    ],
    "css": []
  },
  "redefinirsenha.YfbOq0qu.css": {
    "file": "redefinirsenha.YfbOq0qu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/teste.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste.zxZslZ0A.js",
    "src": "pages/teste.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js",
      "_baseicon.esm.T9zWXEvn.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.Bv_u7NsB.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BIpQOyzx.js",
      "_index.esm.DRhq6M-k.js",
      "_index.esm.CXXwTmEX.js",
      "_index.esm.LjMzGoO0.js",
      "_overlayeventbus.esm.DgS7zUB4.js",
      "_portal.esm.BsDadrOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.X9AORYoS.js",
      "_index.esm.BlX3JZvm.js",
      "_index.esm.B5YBx2CV.js",
      "_index.esm.wHnEKdu6.js",
      "_index.esm.JWiplkJ0.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BBHK5Npe.js",
      "_index.esm.CbTOfI3O.js"
    ]
  },
  "pages/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.BRCduNss.js",
    "src": "pages/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/usersettings.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usersettings.uoHbEw0B.js",
    "src": "pages/usersettings.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_portal.esm.BsDadrOn.js",
      "_basecomponent.esm.g5c2XKhn.js",
      "_index.esm.BIpQOyzx.js",
      "_baseicon.esm.T9zWXEvn.js",
      "_index.esm.DsOWDPur.js",
      "_index.esm.LjMzGoO0.js",
      "_index.esm.sj9IfDyL.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CyI3DoL2.js"
    ],
    "css": []
  },
  "usersettings.7IO3HJw9.css": {
    "file": "usersettings.7IO3HJw9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
