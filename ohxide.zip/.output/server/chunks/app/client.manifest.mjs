const client_manifest = {
  "_Magacrud.Dps7D7Mm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Magacrud.Dps7D7Mm.js",
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "styles.BPUKciI7.css": {
    "file": "styles.BPUKciI7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeicons.Dk_eWBPK.eot": {
    "file": "primeicons.Dk_eWBPK.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "primeicons.DsZ1W7-Z.woff2": {
    "file": "primeicons.DsZ1W7-Z.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "primeicons.CCFeZR6K.woff": {
    "file": "primeicons.CCFeZR6K.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "primeicons.NDVQFXzF.ttf": {
    "file": "primeicons.NDVQFXzF.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "primeicons.BubJZjaf.svg": {
    "file": "primeicons.BubJZjaf.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "flags_responsive.DbRDn7iy.png": {
    "file": "flags_responsive.DbRDn7iy.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.DlAUqK2U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.DlAUqK2U.js"
  },
  "_basecomponent.esm.CISdb4yi.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "basecomponent.esm.CISdb4yi.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_baseicon.esm.CGrB1CoK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "baseicon.esm.CGrB1CoK.js",
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.6S9jGzBg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.6S9jGzBg.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.7Uh1UTRF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.7Uh1UTRF.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.B-rIAkN6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.B-rIAkN6.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BKN4toOy.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BKN4toOy.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BY2hdW9C.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BY2hdW9C.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BjDW0YYn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BjDW0YYn.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BpblEFbZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BpblEFbZ.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BsHdVYtf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BsHdVYtf.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BuMUYE-b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BuMUYE-b.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CYx0MJyj.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CYx0MJyj.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DCjk9KGe.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DCjk9KGe.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DIzpVI4Z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DIzpVI4Z.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.D_m4ZpuH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.D_m4ZpuH.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DtJJ9hHs.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DtJJ9hHs.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DuKrUmcg.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DuKrUmcg.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.E9Klyi4C.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.E9Klyi4C.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.ZCFuFG5D.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.ZCFuFG5D.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.kbjOkWXD.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.kbjOkWXD.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.ta478DUX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.ta478DUX.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.uvoYYgy8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.uvoYYgy8.js",
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo.CQ5Thchh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.CQ5Thchh.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_moment.Cl4UOzQZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "moment.Cl4UOzQZ.js"
  },
  "_nuxt-link.ddoMBOSB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.ddoMBOSB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_overlayeventbus.esm.m9QGNPtL.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlayeventbus.esm.m9QGNPtL.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_portal.esm.nA6wwvSp.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "portal.esm.nA6wwvSp.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_primeflex.!~{02k}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "primeflex.DHMfoBAW.css",
    "src": "_primeflex.!~{02k}~.js"
  },
  "_schemas.Dn9UJcS4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "schemas.Dn9UJcS4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_styles.!~{02h}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "styles.BPUKciI7.css",
    "src": "_styles.!~{02h}~.js"
  },
  "_vue.f36acd1f.Cjw5Yx1J.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.Cjw5Yx1J.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/demo/flags/flags_responsive.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "flags_responsive.DbRDn7iy.png",
    "src": "assets/demo/flags/flags_responsive.png"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.CPYO_rVc.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CQ5Thchh.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BuMUYE-b.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.D_m4ZpuH.js"
    ],
    "css": []
  },
  "default.DdDJXt-Z.css": {
    "file": "default.DdDJXt-Z.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeflex.DHMfoBAW.css": {
    "file": "primeflex.DHMfoBAW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/defaultadmin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "defaultadmin.wXKQyns_.js",
    "src": "layouts/defaultadmin.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CQ5Thchh.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BuMUYE-b.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.D_m4ZpuH.js"
    ],
    "css": []
  },
  "defaultadmin.D9jIJCFZ.css": {
    "file": "defaultadmin.D9jIJCFZ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.Behitezx.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.ddoMBOSB.js",
      "_vue.f36acd1f.Cjw5Yx1J.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-404.BChdqdSe.css": {
    "file": "error-404.BChdqdSe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.DYSow12m.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_vue.f36acd1f.Cjw5Yx1J.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.lDIhfCic.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/primevue/autocomplete/autocomplete.esm.js",
      "node_modules/primevue/calendar/calendar.esm.js",
      "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/chips/chips.esm.js",
      "node_modules/primevue/colorpicker/colorpicker.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/floatlabel/floatlabel.esm.js",
      "node_modules/primevue/iconfield/iconfield.esm.js",
      "node_modules/primevue/inputgroup/inputgroup.esm.js",
      "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
      "node_modules/primevue/inputicon/inputicon.esm.js",
      "node_modules/primevue/inputmask/inputmask.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/inputswitch/inputswitch.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/knob/knob.esm.js",
      "node_modules/primevue/listbox/listbox.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/password/password.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/selectbutton/selectbutton.esm.js",
      "node_modules/primevue/slider/slider.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/togglebutton/togglebutton.esm.js",
      "node_modules/primevue/treeselect/treeselect.esm.js",
      "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/speeddial/speeddial.esm.js",
      "node_modules/primevue/splitbutton/splitbutton.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/row/row.esm.js",
      "node_modules/primevue/columngroup/columngroup.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dataview/dataview.esm.js",
      "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
      "node_modules/primevue/orderlist/orderlist.esm.js",
      "node_modules/primevue/organizationchart/organizationchart.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/picklist/picklist.esm.js",
      "node_modules/primevue/tree/tree.esm.js",
      "node_modules/primevue/treetable/treetable.esm.js",
      "node_modules/primevue/timeline/timeline.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
      "node_modules/primevue/divider/divider.esm.js",
      "node_modules/primevue/fieldset/fieldset.esm.js",
      "node_modules/primevue/panel/panel.esm.js",
      "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
      "node_modules/primevue/splitter/splitter.esm.js",
      "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
      "node_modules/primevue/tabview/tabview.esm.js",
      "node_modules/primevue/tabpanel/tabpanel.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
      "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
      "node_modules/primevue/sidebar/sidebar.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
      "node_modules/primevue/contextmenu/contextmenu.esm.js",
      "node_modules/primevue/dock/dock.esm.js",
      "node_modules/primevue/menu/menu.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/primevue/megamenu/megamenu.esm.js",
      "node_modules/primevue/panelmenu/panelmenu.esm.js",
      "node_modules/primevue/steps/steps.esm.js",
      "node_modules/primevue/tabmenu/tabmenu.esm.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/carousel/carousel.esm.js",
      "node_modules/primevue/galleria/galleria.esm.js",
      "node_modules/primevue/image/image.esm.js",
      "node_modules/primevue/avatar/avatar.esm.js",
      "node_modules/primevue/avatargroup/avatargroup.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/blockui/blockui.esm.js",
      "node_modules/primevue/chip/chip.esm.js",
      "node_modules/primevue/inplace/inplace.esm.js",
      "node_modules/primevue/metergroup/metergroup.esm.js",
      "node_modules/primevue/scrolltop/scrolltop.esm.js",
      "node_modules/primevue/skeleton/skeleton.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/tag/tag.esm.js",
      "node_modules/primevue/terminal/terminal.esm.js",
      "layouts/default.vue",
      "layouts/defaultadmin.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "_globalCSS": true
  },
  "node_modules/primeicons/fonts/primeicons.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "primeicons.Dk_eWBPK.eot",
    "src": "node_modules/primeicons/fonts/primeicons.eot"
  },
  "node_modules/primeicons/fonts/primeicons.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "primeicons.BubJZjaf.svg",
    "src": "node_modules/primeicons/fonts/primeicons.svg"
  },
  "node_modules/primeicons/fonts/primeicons.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "primeicons.NDVQFXzF.ttf",
    "src": "node_modules/primeicons/fonts/primeicons.ttf"
  },
  "node_modules/primeicons/fonts/primeicons.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "primeicons.CCFeZR6K.woff",
    "src": "node_modules/primeicons/fonts/primeicons.woff"
  },
  "node_modules/primeicons/fonts/primeicons.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "primeicons.DsZ1W7-Z.woff2",
    "src": "node_modules/primeicons/fonts/primeicons.woff2"
  },
  "node_modules/primevue/accordion/accordion.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordion.esm.MV0uhjUU.js",
    "src": "node_modules/primevue/accordion/accordion.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/accordiontab/accordiontab.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordiontab.esm.CRiYNOoP.js",
    "src": "node_modules/primevue/accordiontab/accordiontab.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/autocomplete/autocomplete.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "autocomplete.esm.BYxJ_p7s.js",
    "src": "node_modules/primevue/autocomplete/autocomplete.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.6S9jGzBg.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/avatar/avatar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.esm.Bh9IB9HZ.js",
    "src": "node_modules/primevue/avatar/avatar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/avatargroup/avatargroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatargroup.esm.qRc2wDK2.js",
    "src": "node_modules/primevue/avatargroup/avatargroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/badge/badge.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "badge.esm.CMytNnMI.js",
    "src": "node_modules/primevue/badge/badge.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/blockui/blockui.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "blockui.esm.LXb1lZ3Y.js",
    "src": "node_modules/primevue/blockui/blockui.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/breadcrumb/breadcrumb.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "breadcrumb.esm.CkIBNFwW.js",
    "src": "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.kbjOkWXD.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/button/button.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "button.esm.gu6tjW3z.js",
    "src": "node_modules/primevue/button/button.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/calendar/calendar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "calendar.esm.BoTbNhXC.js",
    "src": "node_modules/primevue/calendar/calendar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.uvoYYgy8.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BY2hdW9C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js"
    ]
  },
  "node_modules/primevue/card/card.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "card.esm.D7DmhCzk.js",
    "src": "node_modules/primevue/card/card.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/carousel/carousel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "carousel.esm._gS4XdI_.js",
    "src": "node_modules/primevue/carousel/carousel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.uvoYYgy8.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BY2hdW9C.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/cascadeselect/cascadeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cascadeselect.esm.DIfVACLO.js",
    "src": "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.ta478DUX.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/checkbox/checkbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.esm.B8kmNnzb.js",
    "src": "node_modules/primevue/checkbox/checkbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DIzpVI4Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/chip/chip.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chip.esm.DobQ19J-.js",
    "src": "node_modules/primevue/chip/chip.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.6S9jGzBg.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/chips/chips.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chips.esm.lKiW75kW.js",
    "src": "node_modules/primevue/chips/chips.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.6S9jGzBg.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/colorpicker/colorpicker.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "colorpicker.esm.BKlTOiNW.js",
    "src": "node_modules/primevue/colorpicker/colorpicker.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/column/column.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "column.esm.bCZ_cVjg.js",
    "src": "node_modules/primevue/column/column.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/columngroup/columngroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "columngroup.esm.iGZuok_C.js",
    "src": "node_modules/primevue/columngroup/columngroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/confirmdialog/confirmdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmdialog.esm.cOpLzoQu.js",
    "src": "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.E9Klyi4C.js",
      "_portal.esm.nA6wwvSp.js"
    ]
  },
  "node_modules/primevue/confirmpopup/confirmpopup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmpopup.esm.p0Nu4YA9.js",
    "src": "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/contextmenu/contextmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contextmenu.esm.DPZvbLqF.js",
    "src": "node_modules/primevue/contextmenu/contextmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.D_m4ZpuH.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/datatable/datatable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "datatable.esm.Db_sIsCZ.js",
    "src": "node_modules/primevue/datatable/datatable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_portal.esm.nA6wwvSp.js",
      "_index.esm.BpblEFbZ.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.D_m4ZpuH.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.B-rIAkN6.js"
    ]
  },
  "node_modules/primevue/dataview/dataview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataview.esm.BSwbY37y.js",
    "src": "node_modules/primevue/dataview/dataview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DuKrUmcg.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.D_m4ZpuH.js"
    ]
  },
  "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataviewlayoutoptions.esm.BID8PVWP.js",
    "src": "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BuMUYE-b.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/deferredcontent/deferredcontent.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "deferredcontent.esm.M4sO77n2.js",
    "src": "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dialog/dialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.esm.DqBykCRc.js",
    "src": "node_modules/primevue/dialog/dialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.E9Klyi4C.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/divider/divider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.esm.B637MtQ8.js",
    "src": "node_modules/primevue/divider/divider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dock/dock.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dock.esm.C-a-mJxB.js",
    "src": "node_modules/primevue/dock/dock.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dropdown/dropdown.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dropdown.esm.B52geh7R.js",
    "src": "node_modules/primevue/dropdown/dropdown.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dynamicdialog.esm.CCoIMYoF.js",
    "src": "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.E9Klyi4C.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_portal.esm.nA6wwvSp.js"
    ]
  },
  "node_modules/primevue/fieldset/fieldset.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fieldset.esm.DN3CF4yM.js",
    "src": "node_modules/primevue/fieldset/fieldset.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.ZCFuFG5D.js",
      "_index.esm.BjDW0YYn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/fileupload/fileupload.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fileupload.esm.BOgK66rJ.js",
    "src": "node_modules/primevue/fileupload/fileupload.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.E9Klyi4C.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.6S9jGzBg.js"
    ]
  },
  "node_modules/primevue/floatlabel/floatlabel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "floatlabel.esm.B7LVXRGi.js",
    "src": "node_modules/primevue/floatlabel/floatlabel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/galleria/galleria.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "galleria.esm.DGbIriHR.js",
    "src": "node_modules/primevue/galleria/galleria.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.uvoYYgy8.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.BY2hdW9C.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/iconfield/iconfield.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "iconfield.esm.C54pxwt8.js",
    "src": "node_modules/primevue/iconfield/iconfield.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/image/image.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "image.esm.yve3fg3Y.js",
    "src": "node_modules/primevue/image/image.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.BKN4toOy.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.E9Klyi4C.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/inlinemessage/inlinemessage.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inlinemessage.esm.FLPRwqVi.js",
    "src": "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.6S9jGzBg.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/inplace/inplace.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inplace.esm.C_8ycvKS.js",
    "src": "node_modules/primevue/inplace/inplace.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.E9Klyi4C.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/inputgroup/inputgroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroup.esm.CACY9b1T.js",
    "src": "node_modules/primevue/inputgroup/inputgroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroupaddon.esm.CuWGE1Vt.js",
    "src": "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputicon/inputicon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputicon.esm.F-fippDB.js",
    "src": "node_modules/primevue/inputicon/inputicon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputmask/inputmask.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputmask.esm.CDVI_99-.js",
    "src": "node_modules/primevue/inputmask/inputmask.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/inputnumber/inputnumber.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputnumber.esm.Cqrke3ZA.js",
    "src": "node_modules/primevue/inputnumber/inputnumber.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/inputswitch/inputswitch.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputswitch.esm.gAU9jNSQ.js",
    "src": "node_modules/primevue/inputswitch/inputswitch.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputtext/inputtext.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputtext.esm.C234eckm.js",
    "src": "node_modules/primevue/inputtext/inputtext.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/knob/knob.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "knob.esm.Dc0cG7qB.js",
    "src": "node_modules/primevue/knob/knob.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/listbox/listbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "listbox.esm.6HBjjGyu.js",
    "src": "node_modules/primevue/listbox/listbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.B-rIAkN6.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.ta478DUX.js"
    ]
  },
  "node_modules/primevue/megamenu/megamenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "megamenu.esm.Be4fKfGQ.js",
    "src": "node_modules/primevue/megamenu/megamenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BuMUYE-b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.D_m4ZpuH.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/menu/menu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.esm.DD0palZ0.js",
    "src": "node_modules/primevue/menu/menu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/menubar/menubar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menubar.esm.DBbXW5rv.js",
    "src": "node_modules/primevue/menubar/menubar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BuMUYE-b.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.D_m4ZpuH.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/message/message.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "message.esm.B-GBBMHG.js",
    "src": "node_modules/primevue/message/message.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/metergroup/metergroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "metergroup.esm.YCi3E2Vb.js",
    "src": "node_modules/primevue/metergroup/metergroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/multiselect/multiselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "multiselect.esm.CAv6L3rX.js",
    "src": "node_modules/primevue/multiselect/multiselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/orderlist/orderlist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "orderlist.esm.BpvOQ5ef.js",
    "src": "node_modules/primevue/orderlist/orderlist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.7Uh1UTRF.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/organizationchart/organizationchart.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "organizationchart.esm.5c9Ga9D0.js",
    "src": "node_modules/primevue/organizationchart/organizationchart.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.BY2hdW9C.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/overlaypanel/overlaypanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlaypanel.esm.BB-cHOQH.js",
    "src": "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/paginator/paginator.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "paginator.esm.BDwA4GBa.js",
    "src": "node_modules/primevue/paginator/paginator.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.D_m4ZpuH.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/primevue/inputtext/inputtext.esm.js"
    ]
  },
  "node_modules/primevue/panel/panel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panel.esm.BwWie0cr.js",
    "src": "node_modules/primevue/panel/panel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.ZCFuFG5D.js",
      "_index.esm.BjDW0YYn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/panelmenu/panelmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panelmenu.esm.De-q2fs2.js",
    "src": "node_modules/primevue/panelmenu/panelmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/password/password.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "password.esm.ssOb0hYQ.js",
    "src": "node_modules/primevue/password/password.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BKN4toOy.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/picklist/picklist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "picklist.esm.Ck8lsPEJ.js",
    "src": "node_modules/primevue/picklist/picklist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.7Uh1UTRF.js",
      "_index.esm.DuKrUmcg.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/progressbar/progressbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressbar.esm.DWp6nK-X.js",
    "src": "node_modules/primevue/progressbar/progressbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/progressspinner/progressspinner.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressspinner.esm.CrKbocXT.js",
    "src": "node_modules/primevue/progressspinner/progressspinner.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/radiobutton/radiobutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "radiobutton.esm.Dt6uCxuR.js",
    "src": "node_modules/primevue/radiobutton/radiobutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/rating/rating.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rating.esm.CRNwzCQ-.js",
    "src": "node_modules/primevue/rating/rating.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-italic.var.DhD-tpjY.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2"
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-roman.var.C-r5W2Hj.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2"
  },
  "node_modules/primevue/row/row.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "row.esm.Dwi8raXO.js",
    "src": "node_modules/primevue/row/row.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/scrollpanel/scrollpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollpanel.esm.A5RMa7r_.js",
    "src": "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/scrolltop/scrolltop.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrolltop.esm.BJMkrxNt.js",
    "src": "node_modules/primevue/scrolltop/scrolltop.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BY2hdW9C.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/selectbutton/selectbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "selectbutton.esm.Bf5lRr7s.js",
    "src": "node_modules/primevue/selectbutton/selectbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/sidebar/sidebar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sidebar.esm.CWMfN516.js",
    "src": "node_modules/primevue/sidebar/sidebar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.E9Klyi4C.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/skeleton/skeleton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "skeleton.esm.CC1UWGMN.js",
    "src": "node_modules/primevue/skeleton/skeleton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/slider/slider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "slider.esm.DIYo6vSx.js",
    "src": "node_modules/primevue/slider/slider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/speeddial/speeddial.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "speeddial.esm.P0BKMNJs.js",
    "src": "node_modules/primevue/speeddial/speeddial.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BjDW0YYn.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/splitbutton/splitbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitbutton.esm.DCpQRBLL.js",
    "src": "node_modules/primevue/splitbutton/splitbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "_index.esm.D_m4ZpuH.js"
    ]
  },
  "node_modules/primevue/splitter/splitter.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitter.esm.B4z290tu.js",
    "src": "node_modules/primevue/splitter/splitter.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/splitterpanel/splitterpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitterpanel.esm.DNCh9eQB.js",
    "src": "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/steps/steps.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "steps.esm.4goNz0GZ.js",
    "src": "node_modules/primevue/steps/steps.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/tabmenu/tabmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabmenu.esm.Com9q_5a.js",
    "src": "node_modules/primevue/tabmenu/tabmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/tabpanel/tabpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabpanel.esm.D_OWNSnb.js",
    "src": "node_modules/primevue/tabpanel/tabpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tabview/tabview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabview.esm.6sP5UBWo.js",
    "src": "node_modules/primevue/tabview/tabview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.uvoYYgy8.js",
      "_index.esm.kbjOkWXD.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/tag/tag.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.esm.KtBq0QFa.js",
    "src": "node_modules/primevue/tag/tag.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/terminal/terminal.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terminal.esm.C0G9QNSj.js",
    "src": "node_modules/primevue/terminal/terminal.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/textarea/textarea.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "textarea.esm.BQ4QHJov.js",
    "src": "node_modules/primevue/textarea/textarea.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tieredmenu/tieredmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tieredmenu.esm.B-geHIbH.js",
    "src": "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.D_m4ZpuH.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/timeline/timeline.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "timeline.esm.Pccs817D.js",
    "src": "node_modules/primevue/timeline/timeline.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/toast/toast.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toast.esm.BV9_C4Bx.js",
    "src": "node_modules/primevue/toast/toast.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/togglebutton/togglebutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "togglebutton.esm.u-L4lyOP.js",
    "src": "node_modules/primevue/togglebutton/togglebutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js"
    ]
  },
  "node_modules/primevue/toolbar/toolbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toolbar.esm.C2G3VGa0.js",
    "src": "node_modules/primevue/toolbar/toolbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tree/tree.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tree.esm.DJ1ZaT-f.js",
    "src": "node_modules/primevue/tree/tree.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.ZCFuFG5D.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/treeselect/treeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treeselect.esm.BuHa-WKw.js",
    "src": "node_modules/primevue/treeselect/treeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DtJJ9hHs.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/tree/tree.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.ZCFuFG5D.js"
    ]
  },
  "node_modules/primevue/treetable/treetable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treetable.esm.BKa_eP15.js",
    "src": "node_modules/primevue/treetable/treetable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.ZCFuFG5D.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.D_m4ZpuH.js"
    ]
  },
  "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tristatecheckbox.esm.B6vY8re-.js",
    "src": "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.E9Klyi4C.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "node_modules/primevue/virtualscroller/virtualscroller.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "virtualscroller.esm.DR1GEyZu.js",
    "src": "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.ta478DUX.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_baseicon.esm.CGrB1CoK.js"
    ]
  },
  "pages/admin/client_planos.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client_planos.Dtc2Cw0u.js",
    "src": "pages/admin/client_planos.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.Dps7D7Mm.js",
      "_schemas.Dn9UJcS4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/clients.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clients.MFKIcV58.js",
    "src": "pages/admin/clients.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.Dps7D7Mm.js",
      "_moment.Cl4UOzQZ.js",
      "_schemas.Dn9UJcS4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/config.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.D21YETPZ.js",
    "src": "pages/admin/config.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js"
    ]
  },
  "pages/admin/date.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date.DzH0ORHZ.js",
    "src": "pages/admin/date.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.CWWrPcuk.js",
    "src": "pages/admin/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "_nuxt-link.ddoMBOSB.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/index_res.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index_res.DDe257jX.js",
    "src": "pages/admin/index_res.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.Dps7D7Mm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.BPiHbxUc.js",
    "src": "pages/admin/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CQ5Thchh.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.CISdb4yi.js"
    ],
    "css": []
  },
  "login.DTvi2mUD.css": {
    "file": "login.DTvi2mUD.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/products.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "products.C84G04gJ.js",
    "src": "pages/admin/products.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.Dps7D7Mm.js",
      "_schemas.Dn9UJcS4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/reports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "reports.CId4GX6N.js",
    "src": "pages/admin/reports.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.Dps7D7Mm.js",
      "_schemas.Dn9UJcS4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/sendemail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sendemail.CWnIdcVT.js",
    "src": "pages/admin/sendemail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.ta478DUX.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.BcK4dGDD.js",
    "src": "pages/admin/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/users.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "users.B5jM_iHC.js",
    "src": "pages/admin/users.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.Dps7D7Mm.js",
      "_schemas.Dn9UJcS4.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud copy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud copy.BZ3bvoFh.js",
    "src": "pages/crud copy.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_index.esm.BjDW0YYn.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "_index.esm.D_m4ZpuH.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BpblEFbZ.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud.Um4_PPBa.js",
    "src": "pages/crud.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/download.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "download.bmCtM_dB.js",
    "src": "pages/download.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CQ5Thchh.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js"
    ],
    "css": []
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.DR-7fWwg.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js"
    ],
    "css": []
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.DqOtv6Mv.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CQ5Thchh.js",
      "__plugin-vue_export-helper.DlAUqK2U.js"
    ],
    "css": []
  },
  "login.Lle0I2X1.css": {
    "file": "login.Lle0I2X1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/redefinirsenha.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "redefinirsenha.uZLM6V7u.js",
    "src": "pages/redefinirsenha.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CQ5Thchh.js",
      "_moment.Cl4UOzQZ.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js"
    ],
    "css": []
  },
  "redefinirsenha.YfbOq0qu.css": {
    "file": "redefinirsenha.YfbOq0qu.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/teste.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste.D-omc6Nu.js",
    "src": "pages/teste.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CISdb4yi.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js",
      "_baseicon.esm.CGrB1CoK.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.DuKrUmcg.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DIzpVI4Z.js",
      "_index.esm.DtJJ9hHs.js",
      "_index.esm.B-rIAkN6.js",
      "_index.esm.E9Klyi4C.js",
      "_overlayeventbus.esm.m9QGNPtL.js",
      "_portal.esm.nA6wwvSp.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CYx0MJyj.js",
      "_index.esm.DCjk9KGe.js",
      "_index.esm.D_m4ZpuH.js",
      "_index.esm.kbjOkWXD.js",
      "_index.esm.BuMUYE-b.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BjDW0YYn.js",
      "_index.esm.BpblEFbZ.js"
    ]
  },
  "pages/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.DZWPmFrJ.js",
    "src": "pages/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/usersettings.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usersettings.CuiUj6fq.js",
    "src": "pages/usersettings.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_portal.esm.nA6wwvSp.js",
      "_basecomponent.esm.CISdb4yi.js",
      "_index.esm.DIzpVI4Z.js",
      "_baseicon.esm.CGrB1CoK.js",
      "_index.esm.BsHdVYtf.js",
      "_index.esm.E9Klyi4C.js",
      "_index.esm.6S9jGzBg.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.ta478DUX.js"
    ],
    "css": []
  },
  "usersettings.7IO3HJw9.css": {
    "file": "usersettings.7IO3HJw9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
