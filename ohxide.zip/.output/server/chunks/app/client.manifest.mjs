const client_manifest = {
  "_Magacrud.5mSkh9Hs.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Magacrud.5mSkh9Hs.js",
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "styles.BPUKciI7.css": {
    "file": "styles.BPUKciI7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeicons.Dk_eWBPK.eot": {
    "file": "primeicons.Dk_eWBPK.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "primeicons.DsZ1W7-Z.woff2": {
    "file": "primeicons.DsZ1W7-Z.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "primeicons.CCFeZR6K.woff": {
    "file": "primeicons.CCFeZR6K.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "primeicons.NDVQFXzF.ttf": {
    "file": "primeicons.NDVQFXzF.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "primeicons.BubJZjaf.svg": {
    "file": "primeicons.BubJZjaf.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "flags_responsive.DbRDn7iy.png": {
    "file": "flags_responsive.DbRDn7iy.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.DlAUqK2U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.DlAUqK2U.js"
  },
  "_basecomponent.esm.BCU9GWHB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "basecomponent.esm.BCU9GWHB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_baseicon.esm.BxUAloUs.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "baseicon.esm.BxUAloUs.js",
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BUWNsk9v.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BUWNsk9v.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.B_aCDI75.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.B_aCDI75.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BcGJ89Bd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BcGJ89Bd.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BozBCT85.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BozBCT85.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.C7C5CN1p.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.C7C5CN1p.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.C7pg56pm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.C7pg56pm.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CNDnTUjd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CNDnTUjd.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CRjnIRoJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CRjnIRoJ.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CpgEZRdc.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CpgEZRdc.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CqQBWDyJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CqQBWDyJ.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DJoubdQt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DJoubdQt.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DLwIvjJz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DLwIvjJz.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DUecc7FE.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DUecc7FE.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DVIGDtoa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DVIGDtoa.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Ddlz4uPH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Ddlz4uPH.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.JzdxMyAK.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.JzdxMyAK.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.m_UMhfWS.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.m_UMhfWS.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.oujAGyGF.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.oujAGyGF.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.sqLh-MVq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.sqLh-MVq.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.x3ROCZSs.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.x3ROCZSs.js",
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo.CFxkJ4wP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.CFxkJ4wP.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_moment.Cl4UOzQZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "moment.Cl4UOzQZ.js"
  },
  "_nuxt-link._mgdc9dl.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link._mgdc9dl.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_overlayeventbus.esm.S6d3tTOn.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlayeventbus.esm.S6d3tTOn.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_portal.esm.ihrgp-7T.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "portal.esm.ihrgp-7T.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_primeflex.!~{02j}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "primeflex.DHMfoBAW.css",
    "src": "_primeflex.!~{02j}~.js"
  },
  "_schemas.CxBbrpqd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "schemas.CxBbrpqd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_styles.!~{02g}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "styles.BPUKciI7.css",
    "src": "_styles.!~{02g}~.js"
  },
  "_vue.f36acd1f.DwxgCE8_.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.DwxgCE8_.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/demo/flags/flags_responsive.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "flags_responsive.DbRDn7iy.png",
    "src": "assets/demo/flags/flags_responsive.png"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.BkYAhwbz.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CFxkJ4wP.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.DJoubdQt.js",
      "_index.esm.CqQBWDyJ.js"
    ],
    "css": []
  },
  "default.CsAO9bYG.css": {
    "file": "default.CsAO9bYG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/defaultadmin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "defaultadmin.Br1UuZPJ.js",
    "src": "layouts/defaultadmin.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CFxkJ4wP.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.DJoubdQt.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.BcGJ89Bd.js"
    ],
    "css": []
  },
  "defaultadmin.D9jIJCFZ.css": {
    "file": "defaultadmin.D9jIJCFZ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeflex.DHMfoBAW.css": {
    "file": "primeflex.DHMfoBAW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.BXFvpMq5.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link._mgdc9dl.js",
      "_vue.f36acd1f.DwxgCE8_.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-404.BChdqdSe.css": {
    "file": "error-404.BChdqdSe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.B_YU6Krb.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_vue.f36acd1f.DwxgCE8_.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.CIofY5-G.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/primevue/autocomplete/autocomplete.esm.js",
      "node_modules/primevue/calendar/calendar.esm.js",
      "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/chips/chips.esm.js",
      "node_modules/primevue/colorpicker/colorpicker.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/floatlabel/floatlabel.esm.js",
      "node_modules/primevue/iconfield/iconfield.esm.js",
      "node_modules/primevue/inputgroup/inputgroup.esm.js",
      "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
      "node_modules/primevue/inputicon/inputicon.esm.js",
      "node_modules/primevue/inputmask/inputmask.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/inputswitch/inputswitch.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/knob/knob.esm.js",
      "node_modules/primevue/listbox/listbox.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/password/password.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/selectbutton/selectbutton.esm.js",
      "node_modules/primevue/slider/slider.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/togglebutton/togglebutton.esm.js",
      "node_modules/primevue/treeselect/treeselect.esm.js",
      "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/speeddial/speeddial.esm.js",
      "node_modules/primevue/splitbutton/splitbutton.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/row/row.esm.js",
      "node_modules/primevue/columngroup/columngroup.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dataview/dataview.esm.js",
      "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
      "node_modules/primevue/orderlist/orderlist.esm.js",
      "node_modules/primevue/organizationchart/organizationchart.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/picklist/picklist.esm.js",
      "node_modules/primevue/tree/tree.esm.js",
      "node_modules/primevue/treetable/treetable.esm.js",
      "node_modules/primevue/timeline/timeline.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
      "node_modules/primevue/divider/divider.esm.js",
      "node_modules/primevue/fieldset/fieldset.esm.js",
      "node_modules/primevue/panel/panel.esm.js",
      "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
      "node_modules/primevue/splitter/splitter.esm.js",
      "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
      "node_modules/primevue/tabview/tabview.esm.js",
      "node_modules/primevue/tabpanel/tabpanel.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
      "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
      "node_modules/primevue/sidebar/sidebar.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
      "node_modules/primevue/contextmenu/contextmenu.esm.js",
      "node_modules/primevue/dock/dock.esm.js",
      "node_modules/primevue/menu/menu.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/primevue/megamenu/megamenu.esm.js",
      "node_modules/primevue/panelmenu/panelmenu.esm.js",
      "node_modules/primevue/steps/steps.esm.js",
      "node_modules/primevue/tabmenu/tabmenu.esm.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/carousel/carousel.esm.js",
      "node_modules/primevue/galleria/galleria.esm.js",
      "node_modules/primevue/image/image.esm.js",
      "node_modules/primevue/avatar/avatar.esm.js",
      "node_modules/primevue/avatargroup/avatargroup.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/blockui/blockui.esm.js",
      "node_modules/primevue/chip/chip.esm.js",
      "node_modules/primevue/inplace/inplace.esm.js",
      "node_modules/primevue/metergroup/metergroup.esm.js",
      "node_modules/primevue/scrolltop/scrolltop.esm.js",
      "node_modules/primevue/skeleton/skeleton.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/tag/tag.esm.js",
      "node_modules/primevue/terminal/terminal.esm.js",
      "layouts/default.vue",
      "layouts/defaultadmin.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "_globalCSS": true
  },
  "node_modules/primeicons/fonts/primeicons.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "primeicons.Dk_eWBPK.eot",
    "src": "node_modules/primeicons/fonts/primeicons.eot"
  },
  "node_modules/primeicons/fonts/primeicons.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "primeicons.BubJZjaf.svg",
    "src": "node_modules/primeicons/fonts/primeicons.svg"
  },
  "node_modules/primeicons/fonts/primeicons.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "primeicons.NDVQFXzF.ttf",
    "src": "node_modules/primeicons/fonts/primeicons.ttf"
  },
  "node_modules/primeicons/fonts/primeicons.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "primeicons.CCFeZR6K.woff",
    "src": "node_modules/primeicons/fonts/primeicons.woff"
  },
  "node_modules/primeicons/fonts/primeicons.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "primeicons.DsZ1W7-Z.woff2",
    "src": "node_modules/primeicons/fonts/primeicons.woff2"
  },
  "node_modules/primevue/accordion/accordion.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordion.esm.BQjKaacM.js",
    "src": "node_modules/primevue/accordion/accordion.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/accordiontab/accordiontab.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordiontab.esm.Cn-gAJUb.js",
    "src": "node_modules/primevue/accordiontab/accordiontab.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/autocomplete/autocomplete.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "autocomplete.esm.ZVwK26Nz.js",
    "src": "node_modules/primevue/autocomplete/autocomplete.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.JzdxMyAK.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/avatar/avatar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.esm.D15MN81h.js",
    "src": "node_modules/primevue/avatar/avatar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/avatargroup/avatargroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatargroup.esm.DBCoVwAb.js",
    "src": "node_modules/primevue/avatargroup/avatargroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/badge/badge.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "badge.esm.BHcJGGrl.js",
    "src": "node_modules/primevue/badge/badge.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/blockui/blockui.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "blockui.esm.CLNUGUVw.js",
    "src": "node_modules/primevue/blockui/blockui.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/breadcrumb/breadcrumb.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "breadcrumb.esm.ahJV8zPL.js",
    "src": "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.m_UMhfWS.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/button/button.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "button.esm.B0azOFN2.js",
    "src": "node_modules/primevue/button/button.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/calendar/calendar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "calendar.esm.BtFWKoc0.js",
    "src": "node_modules/primevue/calendar/calendar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.CNDnTUjd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.Ddlz4uPH.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js"
    ]
  },
  "node_modules/primevue/card/card.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "card.esm.W9JAZZ-E.js",
    "src": "node_modules/primevue/card/card.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/carousel/carousel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "carousel.esm.BDCyagAL.js",
    "src": "node_modules/primevue/carousel/carousel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BUWNsk9v.js",
      "_index.esm.CNDnTUjd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.Ddlz4uPH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/cascadeselect/cascadeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cascadeselect.esm.CRKYY3XH.js",
    "src": "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.x3ROCZSs.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/checkbox/checkbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.esm.DBUAs1xJ.js",
    "src": "node_modules/primevue/checkbox/checkbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.C7pg56pm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/chip/chip.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chip.esm.CfxMHmOy.js",
    "src": "node_modules/primevue/chip/chip.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.JzdxMyAK.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/chips/chips.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chips.esm.eDaz8NE4.js",
    "src": "node_modules/primevue/chips/chips.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.JzdxMyAK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/colorpicker/colorpicker.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "colorpicker.esm.BciG6gys.js",
    "src": "node_modules/primevue/colorpicker/colorpicker.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/column/column.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "column.esm.BE4zi9Do.js",
    "src": "node_modules/primevue/column/column.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/columngroup/columngroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "columngroup.esm.B0lYyhq4.js",
    "src": "node_modules/primevue/columngroup/columngroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/confirmdialog/confirmdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmdialog.esm.n9Ghxb0E.js",
    "src": "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.B_aCDI75.js",
      "_portal.esm.ihrgp-7T.js"
    ]
  },
  "node_modules/primevue/confirmpopup/confirmpopup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmpopup.esm.BStg49QJ.js",
    "src": "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/contextmenu/contextmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contextmenu.esm.DyUFU1In.js",
    "src": "node_modules/primevue/contextmenu/contextmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.BcGJ89Bd.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/datatable/datatable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "datatable.esm.BN4EdVJS.js",
    "src": "node_modules/primevue/datatable/datatable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BozBCT85.js",
      "_portal.esm.ihrgp-7T.js",
      "_index.esm.sqLh-MVq.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.BcGJ89Bd.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.DUecc7FE.js"
    ]
  },
  "node_modules/primevue/dataview/dataview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataview.esm.DTqN1OGZ.js",
    "src": "node_modules/primevue/dataview/dataview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.CpgEZRdc.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.BcGJ89Bd.js"
    ]
  },
  "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataviewlayoutoptions.esm.DdiOa8WQ.js",
    "src": "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DJoubdQt.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/deferredcontent/deferredcontent.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "deferredcontent.esm.CqHVaVwU.js",
    "src": "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dialog/dialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.esm.Cjj2HKNz.js",
    "src": "node_modules/primevue/dialog/dialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.B_aCDI75.js",
      "_baseicon.esm.BxUAloUs.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/divider/divider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.esm.CW_697EP.js",
    "src": "node_modules/primevue/divider/divider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dock/dock.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dock.esm.BG1HqN6Q.js",
    "src": "node_modules/primevue/dock/dock.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dropdown/dropdown.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dropdown.esm.DSiDmf0D.js",
    "src": "node_modules/primevue/dropdown/dropdown.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dynamicdialog.esm.DzH9RiIt.js",
    "src": "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.B_aCDI75.js",
      "_baseicon.esm.BxUAloUs.js",
      "_portal.esm.ihrgp-7T.js"
    ]
  },
  "node_modules/primevue/fieldset/fieldset.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fieldset.esm.Bo1Owkve.js",
    "src": "node_modules/primevue/fieldset/fieldset.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DLwIvjJz.js",
      "_index.esm.BozBCT85.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/fileupload/fileupload.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fileupload.esm.CstFacix.js",
    "src": "node_modules/primevue/fileupload/fileupload.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.B_aCDI75.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.JzdxMyAK.js"
    ]
  },
  "node_modules/primevue/floatlabel/floatlabel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "floatlabel.esm.CdY_EYqv.js",
    "src": "node_modules/primevue/floatlabel/floatlabel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/galleria/galleria.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "galleria.esm.C-wVN8tD.js",
    "src": "node_modules/primevue/galleria/galleria.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.CNDnTUjd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.Ddlz4uPH.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/iconfield/iconfield.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "iconfield.esm.DeXmAgUY.js",
    "src": "node_modules/primevue/iconfield/iconfield.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/image/image.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "image.esm.aouqxu8l.js",
    "src": "node_modules/primevue/image/image.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.oujAGyGF.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.B_aCDI75.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/inlinemessage/inlinemessage.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inlinemessage.esm.E3O7ogZf.js",
    "src": "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.C7pg56pm.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.JzdxMyAK.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/inplace/inplace.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inplace.esm.D3vzzeVh.js",
    "src": "node_modules/primevue/inplace/inplace.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.B_aCDI75.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/inputgroup/inputgroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroup.esm.CRCRaahO.js",
    "src": "node_modules/primevue/inputgroup/inputgroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroupaddon.esm.C5ErG-gj.js",
    "src": "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputicon/inputicon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputicon.esm.5NnOGNKW.js",
    "src": "node_modules/primevue/inputicon/inputicon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputmask/inputmask.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputmask.esm.DD736EKM.js",
    "src": "node_modules/primevue/inputmask/inputmask.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/inputnumber/inputnumber.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputnumber.esm.87SR_xqP.js",
    "src": "node_modules/primevue/inputnumber/inputnumber.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/inputswitch/inputswitch.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputswitch.esm.HnCKYkZ3.js",
    "src": "node_modules/primevue/inputswitch/inputswitch.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputtext/inputtext.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputtext.esm.BOcXOcS3.js",
    "src": "node_modules/primevue/inputtext/inputtext.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/knob/knob.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "knob.esm.DHCUnHWP.js",
    "src": "node_modules/primevue/knob/knob.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/listbox/listbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "listbox.esm.vcTYcFh6.js",
    "src": "node_modules/primevue/listbox/listbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.DUecc7FE.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.x3ROCZSs.js"
    ]
  },
  "node_modules/primevue/megamenu/megamenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "megamenu.esm.tEZ0-IkU.js",
    "src": "node_modules/primevue/megamenu/megamenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DJoubdQt.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/menu/menu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.esm.DIYalR3K.js",
    "src": "node_modules/primevue/menu/menu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/menubar/menubar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menubar.esm.ysqHl18j.js",
    "src": "node_modules/primevue/menubar/menubar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DJoubdQt.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/message/message.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "message.esm.BkIR-PaW.js",
    "src": "node_modules/primevue/message/message.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.C7pg56pm.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/metergroup/metergroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "metergroup.esm.DmX9TwUs.js",
    "src": "node_modules/primevue/metergroup/metergroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/multiselect/multiselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "multiselect.esm.D6tGBP9m.js",
    "src": "node_modules/primevue/multiselect/multiselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/orderlist/orderlist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "orderlist.esm.DzGQ4DBp.js",
    "src": "node_modules/primevue/orderlist/orderlist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DVIGDtoa.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/organizationchart/organizationchart.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "organizationchart.esm.Dm7tgFgF.js",
    "src": "node_modules/primevue/organizationchart/organizationchart.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.Ddlz4uPH.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/overlaypanel/overlaypanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlaypanel.esm.7GEaKbnQ.js",
    "src": "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/paginator/paginator.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "paginator.esm.BioDLz8u.js",
    "src": "node_modules/primevue/paginator/paginator.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.BcGJ89Bd.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/primevue/inputtext/inputtext.esm.js"
    ]
  },
  "node_modules/primevue/panel/panel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panel.esm.C5nh7A1M.js",
    "src": "node_modules/primevue/panel/panel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DLwIvjJz.js",
      "_index.esm.BozBCT85.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/panelmenu/panelmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panelmenu.esm.KUnqaYes.js",
    "src": "node_modules/primevue/panelmenu/panelmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/password/password.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "password.esm.D8pMOU3K.js",
    "src": "node_modules/primevue/password/password.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.oujAGyGF.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/picklist/picklist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "picklist.esm.D7LYHKvT.js",
    "src": "node_modules/primevue/picklist/picklist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DVIGDtoa.js",
      "_index.esm.CpgEZRdc.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/progressbar/progressbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressbar.esm.H_hWSr_a.js",
    "src": "node_modules/primevue/progressbar/progressbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/progressspinner/progressspinner.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressspinner.esm.DiH6qIa-.js",
    "src": "node_modules/primevue/progressspinner/progressspinner.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/radiobutton/radiobutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "radiobutton.esm.CcItWNf1.js",
    "src": "node_modules/primevue/radiobutton/radiobutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/rating/rating.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rating.esm.BtVcKryW.js",
    "src": "node_modules/primevue/rating/rating.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-italic.var.DhD-tpjY.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2"
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-roman.var.C-r5W2Hj.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2"
  },
  "node_modules/primevue/row/row.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "row.esm.6HbhHhP_.js",
    "src": "node_modules/primevue/row/row.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/scrollpanel/scrollpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollpanel.esm.CD7qLDeI.js",
    "src": "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/scrolltop/scrolltop.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrolltop.esm.C4QOK1J9.js",
    "src": "node_modules/primevue/scrolltop/scrolltop.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Ddlz4uPH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/selectbutton/selectbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "selectbutton.esm.DtZGmtBL.js",
    "src": "node_modules/primevue/selectbutton/selectbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/sidebar/sidebar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sidebar.esm.Y3hI89lP.js",
    "src": "node_modules/primevue/sidebar/sidebar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.B_aCDI75.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/skeleton/skeleton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "skeleton.esm.B6dpSUZM.js",
    "src": "node_modules/primevue/skeleton/skeleton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/slider/slider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "slider.esm.DzZO4AV2.js",
    "src": "node_modules/primevue/slider/slider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/speeddial/speeddial.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "speeddial.esm.CFkvqtmx.js",
    "src": "node_modules/primevue/speeddial/speeddial.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BozBCT85.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/splitbutton/splitbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitbutton.esm.c1lD8PjT.js",
    "src": "node_modules/primevue/splitbutton/splitbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BUWNsk9v.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "_index.esm.BcGJ89Bd.js"
    ]
  },
  "node_modules/primevue/splitter/splitter.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitter.esm.CJZ-M_Sx.js",
    "src": "node_modules/primevue/splitter/splitter.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/splitterpanel/splitterpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitterpanel.esm.D3raSdRf.js",
    "src": "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/steps/steps.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "steps.esm.slOyxVRl.js",
    "src": "node_modules/primevue/steps/steps.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/tabmenu/tabmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabmenu.esm.CR5fwVQL.js",
    "src": "node_modules/primevue/tabmenu/tabmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/tabpanel/tabpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabpanel.esm.SW3D_QGe.js",
    "src": "node_modules/primevue/tabpanel/tabpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tabview/tabview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabview.esm.ROsnlLMo.js",
    "src": "node_modules/primevue/tabview/tabview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.CNDnTUjd.js",
      "_index.esm.m_UMhfWS.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/tag/tag.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.esm.hzIXCRkB.js",
    "src": "node_modules/primevue/tag/tag.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/terminal/terminal.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terminal.esm.VD7Rgqlk.js",
    "src": "node_modules/primevue/terminal/terminal.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/textarea/textarea.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "textarea.esm.B1r6hhnq.js",
    "src": "node_modules/primevue/textarea/textarea.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tieredmenu/tieredmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tieredmenu.esm.pXd5O5yr.js",
    "src": "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.BcGJ89Bd.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/timeline/timeline.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "timeline.esm.CViyFCMv.js",
    "src": "node_modules/primevue/timeline/timeline.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/toast/toast.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toast.esm.d-rLqZlS.js",
    "src": "node_modules/primevue/toast/toast.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/togglebutton/togglebutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "togglebutton.esm.C3WZQRCW.js",
    "src": "node_modules/primevue/togglebutton/togglebutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ]
  },
  "node_modules/primevue/toolbar/toolbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toolbar.esm.C9y5l3Y_.js",
    "src": "node_modules/primevue/toolbar/toolbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tree/tree.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tree.esm.JLnd2_5l.js",
    "src": "node_modules/primevue/tree/tree.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DLwIvjJz.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/treeselect/treeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treeselect.esm.Ck8HYd5p.js",
    "src": "node_modules/primevue/treeselect/treeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.BUWNsk9v.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/tree/tree.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DLwIvjJz.js"
    ]
  },
  "node_modules/primevue/treetable/treetable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treetable.esm.n9uUVjpO.js",
    "src": "node_modules/primevue/treetable/treetable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DLwIvjJz.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.BcGJ89Bd.js"
    ]
  },
  "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tristatecheckbox.esm.DnhAArH5.js",
    "src": "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.C7pg56pm.js",
      "_index.esm.B_aCDI75.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "node_modules/primevue/virtualscroller/virtualscroller.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "virtualscroller.esm.ybOunYjj.js",
    "src": "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.x3ROCZSs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_baseicon.esm.BxUAloUs.js"
    ]
  },
  "pages/admin/client_planos.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client_planos.CkDP172a.js",
    "src": "pages/admin/client_planos.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.5mSkh9Hs.js",
      "_schemas.CxBbrpqd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/clients.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clients.CsEd_o_m.js",
    "src": "pages/admin/clients.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.5mSkh9Hs.js",
      "_moment.Cl4UOzQZ.js",
      "_schemas.CxBbrpqd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/config.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.BuEspp_G.js",
    "src": "pages/admin/config.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js"
    ]
  },
  "pages/admin/date.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date.ds6onxh8.js",
    "src": "pages/admin/date.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.elV4tK0J.js",
    "src": "pages/admin/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "_nuxt-link._mgdc9dl.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/index_res.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index_res.BIeih1cN.js",
    "src": "pages/admin/index_res.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.5mSkh9Hs.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.BHvtztbX.js",
    "src": "pages/admin/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CFxkJ4wP.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.BCU9GWHB.js"
    ],
    "css": []
  },
  "login.BH5VzkIW.css": {
    "file": "login.BH5VzkIW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/products.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "products.Do5wXPw3.js",
    "src": "pages/admin/products.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.5mSkh9Hs.js",
      "_schemas.CxBbrpqd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/reports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "reports.Bi9FE2KV.js",
    "src": "pages/admin/reports.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.5mSkh9Hs.js",
      "_schemas.CxBbrpqd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/sendemail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sendemail.DbzXQcsc.js",
    "src": "pages/admin/sendemail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.x3ROCZSs.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.BpRdz4dQ.js",
    "src": "pages/admin/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/users.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "users.BDDNL27e.js",
    "src": "pages/admin/users.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.5mSkh9Hs.js",
      "_schemas.CxBbrpqd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud copy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud copy.BFSZ7-56.js",
    "src": "pages/crud copy.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_index.esm.BozBCT85.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "_index.esm.BcGJ89Bd.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.sqLh-MVq.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud.CsmMNUeR.js",
    "src": "pages/crud.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/download.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "download.BVksddQQ.js",
    "src": "pages/download.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CFxkJ4wP.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js"
    ],
    "css": []
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.JuiH3Vz1.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js"
    ],
    "css": []
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.CVlUOTyT.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.CFxkJ4wP.js",
      "__plugin-vue_export-helper.DlAUqK2U.js"
    ],
    "css": []
  },
  "login.6WDEI6gQ.css": {
    "file": "login.6WDEI6gQ.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/teste.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste.DthctNeI.js",
    "src": "pages/teste.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js",
      "_baseicon.esm.BxUAloUs.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.CpgEZRdc.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.C7pg56pm.js",
      "_index.esm.BUWNsk9v.js",
      "_index.esm.DUecc7FE.js",
      "_index.esm.B_aCDI75.js",
      "_overlayeventbus.esm.S6d3tTOn.js",
      "_portal.esm.ihrgp-7T.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.CqQBWDyJ.js",
      "_index.esm.CRjnIRoJ.js",
      "_index.esm.BcGJ89Bd.js",
      "_index.esm.m_UMhfWS.js",
      "_index.esm.DJoubdQt.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BozBCT85.js",
      "_index.esm.sqLh-MVq.js"
    ]
  },
  "pages/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.B-THx9R6.js",
    "src": "pages/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/usersettings.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "usersettings.D3Wibs9-.js",
    "src": "pages/usersettings.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_portal.esm.ihrgp-7T.js",
      "_basecomponent.esm.BCU9GWHB.js",
      "_index.esm.C7pg56pm.js",
      "_baseicon.esm.BxUAloUs.js",
      "_index.esm.C7C5CN1p.js",
      "_index.esm.B_aCDI75.js",
      "_index.esm.JzdxMyAK.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.x3ROCZSs.js"
    ],
    "css": []
  },
  "usersettings.BLL57TNG.css": {
    "file": "usersettings.BLL57TNG.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
