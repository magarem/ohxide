const client_manifest = {
  "_Magacrud.BGL5X1qt.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Magacrud.BGL5X1qt.js",
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "styles.BPUKciI7.css": {
    "file": "styles.BPUKciI7.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeicons.Dk_eWBPK.eot": {
    "file": "primeicons.Dk_eWBPK.eot",
    "resourceType": "font",
    "mimeType": "font/eot"
  },
  "primeicons.DsZ1W7-Z.woff2": {
    "file": "primeicons.DsZ1W7-Z.woff2",
    "resourceType": "font",
    "mimeType": "font/woff2"
  },
  "primeicons.CCFeZR6K.woff": {
    "file": "primeicons.CCFeZR6K.woff",
    "resourceType": "font",
    "mimeType": "font/woff"
  },
  "primeicons.NDVQFXzF.ttf": {
    "file": "primeicons.NDVQFXzF.ttf",
    "resourceType": "font",
    "mimeType": "font/ttf"
  },
  "primeicons.BubJZjaf.svg": {
    "file": "primeicons.BubJZjaf.svg",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml"
  },
  "flags_responsive.DbRDn7iy.png": {
    "file": "flags_responsive.DbRDn7iy.png",
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png"
  },
  "__plugin-vue_export-helper.DlAUqK2U.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_plugin-vue_export-helper.DlAUqK2U.js"
  },
  "_basecomponent.esm.CyTznDIB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "basecomponent.esm.CyTznDIB.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_baseicon.esm.B3Ytl6si.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "baseicon.esm.B3Ytl6si.js",
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.B3_8kWlh.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.B3_8kWlh.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BZpOZdPJ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BZpOZdPJ.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.BfxD_9hI.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.BfxD_9hI.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Bh4aWecR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Bh4aWecR.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Bt0oTjr7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Bt0oTjr7.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.ByKCMNWd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.ByKCMNWd.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Cd7aLbYV.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Cd7aLbYV.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.CgtiGs4C.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.CgtiGs4C.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Ci1ZlQS9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Ci1ZlQS9.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.Cy207MKX.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.Cy207MKX.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.D6PD5f69.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.D6PD5f69.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DCOELrrB.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DCOELrrB.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DDYYo6BR.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DDYYo6BR.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DnDvkHeo.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DnDvkHeo.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.DtmJ45MP.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.DtmJ45MP.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.___6zrU1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.___6zrU1.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.gAN-PTBG.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.gAN-PTBG.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.n4slPMrO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.n4slPMrO.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.x41ZjSJO.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.x41ZjSJO.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_index.esm.y5XLsYwH.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.esm.y5XLsYwH.js",
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_logo.D9-0wP81.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "logo.D9-0wP81.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_moment.Cl4UOzQZ.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "moment.Cl4UOzQZ.js"
  },
  "_nuxt-link.C8LX3cwq.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.C8LX3cwq.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_overlayeventbus.esm.CvEUYQSw.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlayeventbus.esm.CvEUYQSw.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_portal.esm.BXVn-0Rz.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "portal.esm.BXVn-0Rz.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_primeflex.!~{02i}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "primeflex.DHMfoBAW.css",
    "src": "_primeflex.!~{02i}~.js"
  },
  "_schemas.BRQBlo4Z.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "schemas.BRQBlo4Z.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_styles.!~{02f}~.js": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "styles.BPUKciI7.css",
    "src": "_styles.!~{02f}~.js"
  },
  "_vue.f36acd1f.CWY_szU4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vue.f36acd1f.CWY_szU4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/demo/flags/flags_responsive.png": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/png",
    "file": "flags_responsive.DbRDn7iy.png",
    "src": "assets/demo/flags/flags_responsive.png"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "default.wJtxui9Q.js",
    "src": "layouts/default.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.D9-0wP81.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.Bt0oTjr7.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.___6zrU1.js"
    ],
    "css": []
  },
  "default.BFNGCgF6.css": {
    "file": "default.BFNGCgF6.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "layouts/defaultadmin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "defaultadmin.0pDlo_ZK.js",
    "src": "layouts/defaultadmin.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.D9-0wP81.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.Bt0oTjr7.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.___6zrU1.js"
    ],
    "css": []
  },
  "defaultadmin.JewFq9jO.css": {
    "file": "defaultadmin.JewFq9jO.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "primeflex.DHMfoBAW.css": {
    "file": "primeflex.DHMfoBAW.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-404.ZbPx2xRe.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
    "isDynamicEntry": true,
    "imports": [
      "_nuxt-link.C8LX3cwq.js",
      "_vue.f36acd1f.CWY_szU4.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-404.BChdqdSe.css": {
    "file": "error-404.BChdqdSe.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "error-500.B7XJucwQ.js",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue",
    "isDynamicEntry": true,
    "imports": [
      "_vue.f36acd1f.CWY_szU4.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "css": []
  },
  "error-500.BXQ_YkC0.css": {
    "file": "error-500.BXQ_YkC0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "entry.CCPvuRux.js",
    "src": "node_modules/nuxt/dist/app/entry.js",
    "isEntry": true,
    "dynamicImports": [
      "node_modules/primevue/autocomplete/autocomplete.esm.js",
      "node_modules/primevue/calendar/calendar.esm.js",
      "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/chips/chips.esm.js",
      "node_modules/primevue/colorpicker/colorpicker.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/floatlabel/floatlabel.esm.js",
      "node_modules/primevue/iconfield/iconfield.esm.js",
      "node_modules/primevue/inputgroup/inputgroup.esm.js",
      "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
      "node_modules/primevue/inputicon/inputicon.esm.js",
      "node_modules/primevue/inputmask/inputmask.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/inputswitch/inputswitch.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/knob/knob.esm.js",
      "node_modules/primevue/listbox/listbox.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/password/password.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/selectbutton/selectbutton.esm.js",
      "node_modules/primevue/slider/slider.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/togglebutton/togglebutton.esm.js",
      "node_modules/primevue/treeselect/treeselect.esm.js",
      "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/speeddial/speeddial.esm.js",
      "node_modules/primevue/splitbutton/splitbutton.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/row/row.esm.js",
      "node_modules/primevue/columngroup/columngroup.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dataview/dataview.esm.js",
      "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
      "node_modules/primevue/orderlist/orderlist.esm.js",
      "node_modules/primevue/organizationchart/organizationchart.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/picklist/picklist.esm.js",
      "node_modules/primevue/tree/tree.esm.js",
      "node_modules/primevue/treetable/treetable.esm.js",
      "node_modules/primevue/timeline/timeline.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
      "node_modules/primevue/divider/divider.esm.js",
      "node_modules/primevue/fieldset/fieldset.esm.js",
      "node_modules/primevue/panel/panel.esm.js",
      "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
      "node_modules/primevue/splitter/splitter.esm.js",
      "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
      "node_modules/primevue/tabview/tabview.esm.js",
      "node_modules/primevue/tabpanel/tabpanel.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
      "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
      "node_modules/primevue/sidebar/sidebar.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
      "node_modules/primevue/contextmenu/contextmenu.esm.js",
      "node_modules/primevue/dock/dock.esm.js",
      "node_modules/primevue/menu/menu.esm.js",
      "node_modules/primevue/menubar/menubar.esm.js",
      "node_modules/primevue/megamenu/megamenu.esm.js",
      "node_modules/primevue/panelmenu/panelmenu.esm.js",
      "node_modules/primevue/steps/steps.esm.js",
      "node_modules/primevue/tabmenu/tabmenu.esm.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/carousel/carousel.esm.js",
      "node_modules/primevue/galleria/galleria.esm.js",
      "node_modules/primevue/image/image.esm.js",
      "node_modules/primevue/avatar/avatar.esm.js",
      "node_modules/primevue/avatargroup/avatargroup.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "node_modules/primevue/blockui/blockui.esm.js",
      "node_modules/primevue/chip/chip.esm.js",
      "node_modules/primevue/inplace/inplace.esm.js",
      "node_modules/primevue/metergroup/metergroup.esm.js",
      "node_modules/primevue/scrolltop/scrolltop.esm.js",
      "node_modules/primevue/skeleton/skeleton.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/tag/tag.esm.js",
      "node_modules/primevue/terminal/terminal.esm.js",
      "layouts/default.vue",
      "layouts/defaultadmin.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "_globalCSS": true
  },
  "node_modules/primeicons/fonts/primeicons.eot": {
    "resourceType": "font",
    "mimeType": "font/eot",
    "file": "primeicons.Dk_eWBPK.eot",
    "src": "node_modules/primeicons/fonts/primeicons.eot"
  },
  "node_modules/primeicons/fonts/primeicons.svg": {
    "resourceType": "image",
    "prefetch": true,
    "mimeType": "image/svg+xml",
    "file": "primeicons.BubJZjaf.svg",
    "src": "node_modules/primeicons/fonts/primeicons.svg"
  },
  "node_modules/primeicons/fonts/primeicons.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "primeicons.NDVQFXzF.ttf",
    "src": "node_modules/primeicons/fonts/primeicons.ttf"
  },
  "node_modules/primeicons/fonts/primeicons.woff": {
    "resourceType": "font",
    "mimeType": "font/woff",
    "file": "primeicons.CCFeZR6K.woff",
    "src": "node_modules/primeicons/fonts/primeicons.woff"
  },
  "node_modules/primeicons/fonts/primeicons.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "primeicons.DsZ1W7-Z.woff2",
    "src": "node_modules/primeicons/fonts/primeicons.woff2"
  },
  "node_modules/primevue/accordion/accordion.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordion.esm.C1z68VnU.js",
    "src": "node_modules/primevue/accordion/accordion.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/accordiontab/accordiontab.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "accordiontab.esm.2CQ5do4e.js",
    "src": "node_modules/primevue/accordiontab/accordiontab.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/autocomplete/autocomplete.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "autocomplete.esm.Brzc1ukg.js",
    "src": "node_modules/primevue/autocomplete/autocomplete.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.B3_8kWlh.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/avatar/avatar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatar.esm.9iMXDM2F.js",
    "src": "node_modules/primevue/avatar/avatar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/avatargroup/avatargroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "avatargroup.esm.Bv3dbXmA.js",
    "src": "node_modules/primevue/avatargroup/avatargroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/badge/badge.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "badge.esm.CO2-0YH3.js",
    "src": "node_modules/primevue/badge/badge.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/blockui/blockui.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "blockui.esm.BmIafriF.js",
    "src": "node_modules/primevue/blockui/blockui.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/breadcrumb/breadcrumb.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "breadcrumb.esm.J6s8diO1.js",
    "src": "node_modules/primevue/breadcrumb/breadcrumb.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Bh4aWecR.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/button/button.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "button.esm.CvvNWo_G.js",
    "src": "node_modules/primevue/button/button.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/calendar/calendar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "calendar.esm.CifcrqmW.js",
    "src": "node_modules/primevue/calendar/calendar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.ByKCMNWd.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.y5XLsYwH.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js"
    ]
  },
  "node_modules/primevue/card/card.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "card.esm.BgWNJt7n.js",
    "src": "node_modules/primevue/card/card.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/carousel/carousel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "carousel.esm.CDddC51r.js",
    "src": "node_modules/primevue/carousel/carousel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.D6PD5f69.js",
      "_index.esm.ByKCMNWd.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.y5XLsYwH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/cascadeselect/cascadeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "cascadeselect.esm.ASxyvFzK.js",
    "src": "node_modules/primevue/cascadeselect/cascadeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.___6zrU1.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.gAN-PTBG.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/checkbox/checkbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "checkbox.esm.32eCMAqN.js",
    "src": "node_modules/primevue/checkbox/checkbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.x41ZjSJO.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/chip/chip.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chip.esm.Bx4j9dUQ.js",
    "src": "node_modules/primevue/chip/chip.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.B3_8kWlh.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/chips/chips.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "chips.esm.CRfOe0g8.js",
    "src": "node_modules/primevue/chips/chips.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.B3_8kWlh.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/colorpicker/colorpicker.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "colorpicker.esm.CkxuJYoU.js",
    "src": "node_modules/primevue/colorpicker/colorpicker.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/column/column.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "column.esm.BewrrWn9.js",
    "src": "node_modules/primevue/column/column.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/columngroup/columngroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "columngroup.esm.zbeWBqn5.js",
    "src": "node_modules/primevue/columngroup/columngroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/confirmdialog/confirmdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmdialog.esm.CeUwBepN.js",
    "src": "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.Cy207MKX.js",
      "_portal.esm.BXVn-0Rz.js"
    ]
  },
  "node_modules/primevue/confirmpopup/confirmpopup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "confirmpopup.esm.Bgf8qgP-.js",
    "src": "node_modules/primevue/confirmpopup/confirmpopup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/contextmenu/contextmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contextmenu.esm.DH7XfGgu.js",
    "src": "node_modules/primevue/contextmenu/contextmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.___6zrU1.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/datatable/datatable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "datatable.esm.D35cu-tw.js",
    "src": "node_modules/primevue/datatable/datatable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_portal.esm.BXVn-0Rz.js",
      "_index.esm.DnDvkHeo.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.___6zrU1.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.Ci1ZlQS9.js"
    ]
  },
  "node_modules/primevue/dataview/dataview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataview.esm.B19tn-91.js",
    "src": "node_modules/primevue/dataview/dataview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/paginator/paginator.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.n4slPMrO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.___6zrU1.js"
    ]
  },
  "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dataviewlayoutoptions.esm.JzTgS2Mz.js",
    "src": "node_modules/primevue/dataviewlayoutoptions/dataviewlayoutoptions.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Bt0oTjr7.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/deferredcontent/deferredcontent.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "deferredcontent.esm.CvVS6qIU.js",
    "src": "node_modules/primevue/deferredcontent/deferredcontent.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dialog/dialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dialog.esm.DPqZfEpk.js",
    "src": "node_modules/primevue/dialog/dialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.Cy207MKX.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/divider/divider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "divider.esm.BSGysj43.js",
    "src": "node_modules/primevue/divider/divider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dock/dock.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dock.esm.CcWeFJmf.js",
    "src": "node_modules/primevue/dock/dock.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/dropdown/dropdown.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dropdown.esm.Bse23BFz.js",
    "src": "node_modules/primevue/dropdown/dropdown.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dynamicdialog.esm.B5GqnVlk.js",
    "src": "node_modules/primevue/dynamicdialog/dynamicdialog.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.Cy207MKX.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_portal.esm.BXVn-0Rz.js"
    ]
  },
  "node_modules/primevue/fieldset/fieldset.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fieldset.esm.DqR7ugXV.js",
    "src": "node_modules/primevue/fieldset/fieldset.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Cd7aLbYV.js",
      "_index.esm.BZpOZdPJ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/fileupload/fileupload.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fileupload.esm.BBjr21C6.js",
    "src": "node_modules/primevue/fileupload/fileupload.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.Cy207MKX.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.B3_8kWlh.js"
    ]
  },
  "node_modules/primevue/floatlabel/floatlabel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "floatlabel.esm.OA3tHYIU.js",
    "src": "node_modules/primevue/floatlabel/floatlabel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/galleria/galleria.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "galleria.esm.B2Jg6M_T.js",
    "src": "node_modules/primevue/galleria/galleria.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.ByKCMNWd.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.y5XLsYwH.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/iconfield/iconfield.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "iconfield.esm.CSpvQJzf.js",
    "src": "node_modules/primevue/iconfield/iconfield.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/image/image.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "image.esm.DRSgtjUR.js",
    "src": "node_modules/primevue/image/image.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.DCOELrrB.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.Cy207MKX.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/inlinemessage/inlinemessage.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inlinemessage.esm.vbgXx1pU.js",
    "src": "node_modules/primevue/inlinemessage/inlinemessage.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.x41ZjSJO.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.B3_8kWlh.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/inplace/inplace.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inplace.esm.yN9s6z2c.js",
    "src": "node_modules/primevue/inplace/inplace.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.Cy207MKX.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/inputgroup/inputgroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroup.esm.BF_5CWR5.js",
    "src": "node_modules/primevue/inputgroup/inputgroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputgroupaddon.esm.ZyMlO0a3.js",
    "src": "node_modules/primevue/inputgroupaddon/inputgroupaddon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputicon/inputicon.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputicon.esm.BlR5JQLi.js",
    "src": "node_modules/primevue/inputicon/inputicon.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputmask/inputmask.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputmask.esm.DTHolMUq.js",
    "src": "node_modules/primevue/inputmask/inputmask.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/inputnumber/inputnumber.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputnumber.esm.f-0jT-4X.js",
    "src": "node_modules/primevue/inputnumber/inputnumber.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/inputswitch/inputswitch.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputswitch.esm.DKIDDyyx.js",
    "src": "node_modules/primevue/inputswitch/inputswitch.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/inputtext/inputtext.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "inputtext.esm.C8lEuvRr.js",
    "src": "node_modules/primevue/inputtext/inputtext.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/knob/knob.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "knob.esm.BtfnnRcl.js",
    "src": "node_modules/primevue/knob/knob.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/listbox/listbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "listbox.esm.CWiISlPp.js",
    "src": "node_modules/primevue/listbox/listbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.Ci1ZlQS9.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.gAN-PTBG.js"
    ]
  },
  "node_modules/primevue/megamenu/megamenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "megamenu.esm.C_BU7al3.js",
    "src": "node_modules/primevue/megamenu/megamenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Bt0oTjr7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.___6zrU1.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/menu/menu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menu.esm.CR4hbBBi.js",
    "src": "node_modules/primevue/menu/menu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/menubar/menubar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "menubar.esm.DNukWaGV.js",
    "src": "node_modules/primevue/menubar/menubar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Bt0oTjr7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.___6zrU1.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/message/message.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "message.esm.eNi1xkPK.js",
    "src": "node_modules/primevue/message/message.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.x41ZjSJO.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/metergroup/metergroup.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "metergroup.esm.Ckz0gEiO.js",
    "src": "node_modules/primevue/metergroup/metergroup.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/multiselect/multiselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "multiselect.esm.B0YGimSw.js",
    "src": "node_modules/primevue/multiselect/multiselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/orderlist/orderlist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "orderlist.esm.BJXyjvQ5.js",
    "src": "node_modules/primevue/orderlist/orderlist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DDYYo6BR.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/organizationchart/organizationchart.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "organizationchart.esm.DzKuKylz.js",
    "src": "node_modules/primevue/organizationchart/organizationchart.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.y5XLsYwH.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/overlaypanel/overlaypanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "overlaypanel.esm.CdI-vQzV.js",
    "src": "node_modules/primevue/overlaypanel/overlaypanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/paginator/paginator.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "paginator.esm.DDpH8iYg.js",
    "src": "node_modules/primevue/paginator/paginator.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.___6zrU1.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/primevue/inputtext/inputtext.esm.js"
    ]
  },
  "node_modules/primevue/panel/panel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panel.esm.B0mnXDbS.js",
    "src": "node_modules/primevue/panel/panel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Cd7aLbYV.js",
      "_index.esm.BZpOZdPJ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/panelmenu/panelmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "panelmenu.esm.6O3JAfix.js",
    "src": "node_modules/primevue/panelmenu/panelmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/password/password.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "password.esm.tK3xI6f-.js",
    "src": "node_modules/primevue/password/password.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.DCOELrrB.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/picklist/picklist.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "picklist.esm.Bbfi435S.js",
    "src": "node_modules/primevue/picklist/picklist.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.DDYYo6BR.js",
      "_index.esm.n4slPMrO.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/progressbar/progressbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressbar.esm.z76xe7Jd.js",
    "src": "node_modules/primevue/progressbar/progressbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/progressspinner/progressspinner.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "progressspinner.esm.0t8nE2f1.js",
    "src": "node_modules/primevue/progressspinner/progressspinner.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/radiobutton/radiobutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "radiobutton.esm.CRLI86Mj.js",
    "src": "node_modules/primevue/radiobutton/radiobutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/rating/rating.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "rating.esm.BGnfa4z-.js",
    "src": "node_modules/primevue/rating/rating.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-italic.var.DhD-tpjY.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-italic.var.woff2"
  },
  "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2": {
    "resourceType": "font",
    "mimeType": "font/woff2",
    "file": "Inter-roman.var.C-r5W2Hj.woff2",
    "src": "node_modules/primevue/resources/themes/aura-dark-green/fonts/Inter-roman.var.woff2"
  },
  "node_modules/primevue/row/row.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "row.esm.CMIsZSKe.js",
    "src": "node_modules/primevue/row/row.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/scrollpanel/scrollpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrollpanel.esm.CdP2e7nE.js",
    "src": "node_modules/primevue/scrollpanel/scrollpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/scrolltop/scrolltop.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "scrolltop.esm.Dm2UfqY8.js",
    "src": "node_modules/primevue/scrolltop/scrolltop.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.y5XLsYwH.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/selectbutton/selectbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "selectbutton.esm.BH5b0cIi.js",
    "src": "node_modules/primevue/selectbutton/selectbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/sidebar/sidebar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sidebar.esm.DByn4sES.js",
    "src": "node_modules/primevue/sidebar/sidebar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.Cy207MKX.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/skeleton/skeleton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "skeleton.esm.CLQcZpEc.js",
    "src": "node_modules/primevue/skeleton/skeleton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/slider/slider.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "slider.esm.BFh_xQ_K.js",
    "src": "node_modules/primevue/slider/slider.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/speeddial/speeddial.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "speeddial.esm.BzOJoPBn.js",
    "src": "node_modules/primevue/speeddial/speeddial.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/splitbutton/splitbutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitbutton.esm.BZQXb9DZ.js",
    "src": "node_modules/primevue/splitbutton/splitbutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/button/button.esm.js",
      "_index.esm.D6PD5f69.js",
      "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "_index.esm.___6zrU1.js"
    ]
  },
  "node_modules/primevue/splitter/splitter.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitter.esm.CN-BGyYz.js",
    "src": "node_modules/primevue/splitter/splitter.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/splitterpanel/splitterpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "splitterpanel.esm.B1i2c0yH.js",
    "src": "node_modules/primevue/splitterpanel/splitterpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/steps/steps.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "steps.esm.BWS5O4cv.js",
    "src": "node_modules/primevue/steps/steps.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/tabmenu/tabmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabmenu.esm.Cei3aVA2.js",
    "src": "node_modules/primevue/tabmenu/tabmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/tabpanel/tabpanel.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabpanel.esm.mXJo644y.js",
    "src": "node_modules/primevue/tabpanel/tabpanel.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tabview/tabview.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tabview.esm.D7n98bfD.js",
    "src": "node_modules/primevue/tabview/tabview.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.ByKCMNWd.js",
      "_index.esm.Bh4aWecR.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/tag/tag.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tag.esm.By283nCt.js",
    "src": "node_modules/primevue/tag/tag.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/terminal/terminal.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "terminal.esm.DqTF6le_.js",
    "src": "node_modules/primevue/terminal/terminal.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/textarea/textarea.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "textarea.esm.C0jcKttJ.js",
    "src": "node_modules/primevue/textarea/textarea.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tieredmenu/tieredmenu.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tieredmenu.esm.BXW12qRB.js",
    "src": "node_modules/primevue/tieredmenu/tieredmenu.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.___6zrU1.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/timeline/timeline.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "timeline.esm.DI8_P996.js",
    "src": "node_modules/primevue/timeline/timeline.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/toast/toast.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toast.esm.BRfAbzHy.js",
    "src": "node_modules/primevue/toast/toast.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/togglebutton/togglebutton.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "togglebutton.esm.DpSxNY5p.js",
    "src": "node_modules/primevue/togglebutton/togglebutton.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js"
    ]
  },
  "node_modules/primevue/toolbar/toolbar.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "toolbar.esm.BLbLiYwW.js",
    "src": "node_modules/primevue/toolbar/toolbar.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "node_modules/primevue/tree/tree.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tree.esm.CG1Ud3nr.js",
    "src": "node_modules/primevue/tree/tree.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Cd7aLbYV.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/treeselect/treeselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treeselect.esm.TZNdzK5P.js",
    "src": "node_modules/primevue/treeselect/treeselect.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.D6PD5f69.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/tree/tree.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Cd7aLbYV.js"
    ]
  },
  "node_modules/primevue/treetable/treetable.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "treetable.esm.Duqbz_H3.js",
    "src": "node_modules/primevue/treetable/treetable.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Cd7aLbYV.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.___6zrU1.js"
    ]
  },
  "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "tristatecheckbox.esm.BgAVlsur.js",
    "src": "node_modules/primevue/tristatecheckbox/tristatecheckbox.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.x41ZjSJO.js",
      "_index.esm.Cy207MKX.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "node_modules/primevue/virtualscroller/virtualscroller.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "virtualscroller.esm.Bn7x3oWy.js",
    "src": "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
    "isDynamicEntry": true,
    "imports": [
      "_index.esm.gAN-PTBG.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_baseicon.esm.B3Ytl6si.js"
    ]
  },
  "pages/admin/client_planos.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client_planos.CZ0qaW0f.js",
    "src": "pages/admin/client_planos.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.BGL5X1qt.js",
      "_schemas.BRQBlo4Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/clients.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "clients.CQhJDbGh.js",
    "src": "pages/admin/clients.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.BGL5X1qt.js",
      "_moment.Cl4UOzQZ.js",
      "_schemas.BRQBlo4Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/config.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.Z_8Rl-FB.js",
    "src": "pages/admin/config.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/accordiontab/accordiontab.esm.js",
      "node_modules/primevue/accordion/accordion.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js"
    ]
  },
  "pages/admin/date.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "date.BsODDxTg.js",
    "src": "pages/admin/date.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.BGybKlUE.js",
    "src": "pages/admin/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "_nuxt-link.C8LX3cwq.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/index_res.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index_res.BpjS-cXM.js",
    "src": "pages/admin/index_res.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.BGL5X1qt.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.Dke43kjb.js",
    "src": "pages/admin/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.D9-0wP81.js",
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "_basecomponent.esm.CyTznDIB.js"
    ],
    "css": []
  },
  "login.CmvI9c4k.css": {
    "file": "login.CmvI9c4k.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/products.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "products.NZasaL7q.js",
    "src": "pages/admin/products.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.BGL5X1qt.js",
      "_schemas.BRQBlo4Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/reports.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "reports.Bn5J7FBn.js",
    "src": "pages/admin/reports.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.BGL5X1qt.js",
      "_schemas.BRQBlo4Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/admin/sendemail.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sendemail.B9RZ3DyA.js",
    "src": "pages/admin/sendemail.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/confirmdialog/confirmdialog.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.gAN-PTBG.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/badge/badge.esm.js"
    ]
  },
  "pages/admin/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.BgNYzOwY.js",
    "src": "pages/admin/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "pages/admin/users.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "users.BJzwWXQU.js",
    "src": "pages/admin/users.vue",
    "isDynamicEntry": true,
    "imports": [
      "_Magacrud.BGL5X1qt.js",
      "_schemas.BRQBlo4Z.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/toast/toast.esm.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud copy.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud copy.plMncUm_.js",
    "src": "pages/crud copy.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/fileupload/fileupload.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/rating/rating.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/textarea/textarea.esm.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_index.esm.BZpOZdPJ.js",
      "node_modules/primevue/message/message.esm.js",
      "node_modules/primevue/progressbar/progressbar.esm.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "_index.esm.___6zrU1.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "_index.esm.DnDvkHeo.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/crud.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "crud.DGIh6vxq.js",
    "src": "pages/crud.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/toast/toast.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/toolbar/toolbar.esm.js",
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/dialog/dialog.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_portal.esm.BXVn-0Rz.js",
      "_basecomponent.esm.CyTznDIB.js",
      "_index.esm.x41ZjSJO.js",
      "_baseicon.esm.B3Ytl6si.js",
      "_index.esm.CgtiGs4C.js",
      "_index.esm.Cy207MKX.js",
      "_index.esm.B3_8kWlh.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js"
    ],
    "css": [
      "styles.BPUKciI7.css"
    ],
    "assets": [
      "primeicons.Dk_eWBPK.eot",
      "primeicons.DsZ1W7-Z.woff2",
      "primeicons.CCFeZR6K.woff",
      "primeicons.NDVQFXzF.ttf",
      "primeicons.BubJZjaf.svg",
      "flags_responsive.DbRDn7iy.png"
    ]
  },
  "pages/download.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "download.D1rhqJsM.js",
    "src": "pages/download.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/progressspinner/progressspinner.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.D9-0wP81.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js"
    ],
    "css": []
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.KRYz7wT9.js",
    "src": "pages/index.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_moment.Cl4UOzQZ.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js"
    ],
    "css": []
  },
  "pages/login.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "login.BSpYV8EZ.js",
    "src": "pages/login.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_logo.D9-0wP81.js",
      "__plugin-vue_export-helper.DlAUqK2U.js"
    ],
    "css": []
  },
  "login.BH8asLz8.css": {
    "file": "login.BH8asLz8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/teste.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste.D1CE6SQp.js",
    "src": "pages/teste.vue",
    "isDynamicEntry": true,
    "imports": [
      "node_modules/primevue/inputtext/inputtext.esm.js",
      "node_modules/primevue/button/button.esm.js",
      "node_modules/primevue/column/column.esm.js",
      "node_modules/primevue/datatable/datatable.esm.js",
      "node_modules/primevue/card/card.esm.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_basecomponent.esm.CyTznDIB.js",
      "node_modules/primevue/badge/badge.esm.js",
      "_index.esm.gAN-PTBG.js",
      "_baseicon.esm.B3Ytl6si.js",
      "node_modules/primevue/paginator/paginator.esm.js",
      "_index.esm.n4slPMrO.js",
      "node_modules/primevue/dropdown/dropdown.esm.js",
      "_index.esm.x41ZjSJO.js",
      "_index.esm.D6PD5f69.js",
      "_index.esm.Ci1ZlQS9.js",
      "_index.esm.Cy207MKX.js",
      "_overlayeventbus.esm.CvEUYQSw.js",
      "_portal.esm.BXVn-0Rz.js",
      "node_modules/primevue/virtualscroller/virtualscroller.esm.js",
      "node_modules/primevue/inputnumber/inputnumber.esm.js",
      "_index.esm.DtmJ45MP.js",
      "_index.esm.BfxD_9hI.js",
      "_index.esm.___6zrU1.js",
      "_index.esm.Bh4aWecR.js",
      "_index.esm.Bt0oTjr7.js",
      "node_modules/primevue/checkbox/checkbox.esm.js",
      "node_modules/primevue/radiobutton/radiobutton.esm.js",
      "_index.esm.BZpOZdPJ.js",
      "_index.esm.DnDvkHeo.js"
    ]
  },
  "pages/teste2.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "teste2.ByCIk_Vq.js",
    "src": "pages/teste2.vue",
    "isDynamicEntry": true,
    "imports": [
      "__plugin-vue_export-helper.DlAUqK2U.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
