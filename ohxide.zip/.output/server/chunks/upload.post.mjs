import { d as defineEventHandler, g as getQuery } from './nitro/node-server.mjs';
import formidable from 'formidable';
import fs from 'fs';
import path from 'node:path';
import 'node:http';
import 'node:https';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

// src/index.ts
async function readFiles(event, options) {
  const form = formidable(options);
  options?.getForm?.(form);
  const [fields, files] = await form.parse(event.node.req);
  return {
    fields,
    files,
    form
  };
}

const upload_post = defineEventHandler(async (event) => {
  const { dir } = getQuery(event);
  console.log(dir);
  const { files: { photo: [{ originalFilename, filepath, mimetype }] } } = await readFiles(event, {
    includeFields: true
  });
  console.log("name::::::", originalFilename);
  let imageName = String(Date.now()) + String(Math.round(Math.random() * 1e7)) + "." + mimetype.split("/")[1];
  let newPath = path.join("upload", imageName);
  fs.copyFileSync(filepath, newPath);
  return imageName;
});

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map
