import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import { writeFile } from 'node:fs';
import { Buffer } from 'node:buffer';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:url';

const save = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const save = (body2) => {
    if (body2.txt == "" || !body2.txt)
      return "";
    console.log(body2);
    const bodyTxt = new Uint8Array(Buffer.from(body2.txt));
    writeFile("public/" + body2.filename, bodyTxt, (err) => {
      if (err)
        throw err;
      console.log("The file has been saved!");
    });
    return "ok";
  };
  return save(body);
});

export { save as default };
//# sourceMappingURL=save.mjs.map
