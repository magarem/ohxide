import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import fs from 'fs';
import { MailerSend, Sender, Recipient, Attachment, EmailParams } from 'mailersend';
import 'node:http';
import 'node:https';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

const mailersend = defineEventHandler(async (event) => {
  const req = await readBody(event);
  console.log("req:", req);
  const mailerSend = new MailerSend({
    // apiKey: "mlsn.813418e9d77877ab64f06d6b1893af5758740d58099fafd6f837ed9dee78ce43",
    apiKey: "mlsn.e3810944fb803ad0e17de4f76a0d40861a11e94ea44f060e1c78534b1553ce69"
  });
  const sentFrom = new Sender("ohxide@ohxide.com.br", "Ohxide");
  const recipients = [
    new Recipient(req.to, req.destinatario)
  ];
  if (req.attach) {
    let attachments = [
      new Attachment(
        fs.readFileSync(req.attach, { encoding: "base64" }),
        req.attach.split(/[\s\/]+/).at(-1),
        "attachment"
      )
    ];
    const emailParams = new EmailParams().setFrom(sentFrom).setTo(recipients).setReplyTo(sentFrom).setAttachments(attachments).setSubject(req.subject).setHtml(req.html);
    await mailerSend.email.send(emailParams);
  } else {
    const emailParams = new EmailParams().setFrom(sentFrom).setTo(recipients).setReplyTo(sentFrom).setSubject(req.subject).setHtml(req.html);
    await mailerSend.email.send(emailParams);
  }
});

export { mailersend as default };
//# sourceMappingURL=mailersend.mjs.map
