import { d as defineEventHandler, r as readBody } from './nitro/node-server.mjs';
import Database from 'better-sqlite3';
import 'node:http';
import 'node:https';
import 'fs';
import 'path';
import 'vue';
import 'node:fs';
import 'node:url';

function generateToken(n) {
  var chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  var token = "";
  for (var i = 0; i < n; i++) {
    token += chars[Math.floor(Math.random() * chars.length)];
  }
  return token;
}
const login_do = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const type = body.type;
  const email = body.email;
  const password = body.password;
  const sql = `select * from ${type} where email like '${email}' and password like '${password}' `;
  console.log("sql", sql);
  const db = new Database("database.db");
  const data = db.prepare(sql).all();
  db.close();
  console.log("db---------->", data);
  if (data.length > 0) {
    const userObj = {
      ...data[0],
      type,
      token: generateToken(360)
    };
    console.log("userObj:", userObj);
    return userObj;
  } else {
    return null;
  }
});

export { login_do as default };
//# sourceMappingURL=login_do.mjs.map
