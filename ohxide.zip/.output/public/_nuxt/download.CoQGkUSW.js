import U from"./progressspinner.esm.Ch3bDywO.js";import $ from"./button.esm.DMVjoE1n.js";import{r as d,x as A,z as _,A as S,y as B,K as D,n as R,c as b,a as f,t as y,u as t,q as g,G as h,w as q,s as v,Q as G,o as p,b as P}from"./entry.CoTUwW6Z.js";import{_ as T}from"./logo.C2Hbj41X.js";/* empty css                  */import"./basecomponent.esm.D_VPvtcm.js";import"./badge.esm.DG0HFrMB.js";import"./index.esm.BQfSFLZj.js";import"./baseicon.esm.DtkkUEDV.js";const E={class:"text-center",style:{"margin-top":"80px"}},V=f("img",{src:T,style:{width:"200px"}},null,-1),W={__name:"download",async setup(z){let o,m;d("products"),A();const{logUserOut:J,authenticateUser:w}=_(),{authenticated:u}=S(_());B("dataUser");let s=d();const i=D(),l=i.query.year,c=i.query.month,C=i.query.client,e=([o,m]=R(()=>v.get(`select * from clients where id like '${C}'`)),o=await o,m(),o),k=async()=>{console.log({type:"clients",username:e[0].username,password:e[0].password.toString()});const r=await w({type:"clients",username:e[0].username,password:e[0].password.toString()});console.log("r:",r),console.log("authenticated:",u.value),u.value?(console.log("Usuario identificado!!"),N()):console.log("erro login!!")},N=async()=>{const r=`
  select 
      COUNT(reports.id), 
      reports.year, 
      reports.month, 
      GROUP_CONCAT(reports.name) as nome, 
      GROUP_CONCAT(reports.file) as files, 
      GROUP_CONCAT(products.name) as tags 
  from 
      reports, 
      products, 
      clients 
  where 
      reports.tag = products.id AND 
      instr(clients.tags, reports.tag) > 0 AND
      clients.id like '${e[0].id}'
  GROUP BY 
      reports.year, 
      reports.month 
  order by 
      year DESC, 
      month DESC 
`;let a=await $fetch("/api/dbservices?sql="+r.replace(/\s+/g," ").trim());a=a.filter(n=>n.year==l&&n.month==c),s.value=await $fetch(`/api/shell?year=${l}&month=${c}&client=${JSON.stringify(e[0])}&files=${a[0].files}`)};return k(),(r,a)=>{const n=U,O=$,x=G("router-link");return p(),b("div",E,[V,f("h3",null,"Download relatório "+y(t(c))+"/"+y(t(l)),1),t(s)?h("",!0):(p(),g(n,{key:0})),t(s)?(p(),g(x,{key:1,to:"/upload/reports/"+t(s),target:"_blank",rel:"noopener"},{default:q(()=>[P(O,{style:{"margin-top":"20px"},label:"Baixar relatório",icon:"pi pi-cloud-download"})]),_:1},8,["to"])):h("",!0)])}}};export{W as default};
