import{r as u,n as _,c as d,d as E,t as N,u as T,F as g,a as O,s as m,o as j}from"./entry.CVyNHP-b.js";const I=O("h1",null,"teste",-1),v={__name:"teste2",async setup(S){let e,t,n=u([]),p=u([]),o,r,l=[];n.value=([e,t]=_(()=>m.get("select * from clients")),e=await e,t(),e),n.value.map((a,i)=>{o="("+Object.keys(a).join(",")+")",r="("+Object.values(a).map(s=>s=="null"?s:s=="2224"?"'top'":"'"+s+"'").join(",")+")",l[i]=`
         INSERT INTO clients
         ${o}
         VALUES
         ${r};
      `}),console.log(l);let c=`
   
   BEGIN TRANSACTION;

   DELETE FROM clients;
  
   ${l.join("")}

   COMMIT;
  `;console.log(c);let f=([e,t]=_(()=>m.exec(c)),e=await e,t(),e);return console.log("ret:",f),(a,i)=>(j(),d(g,null,[I,E(" "+N(T(p)),1)],64))}};export{v as default};
