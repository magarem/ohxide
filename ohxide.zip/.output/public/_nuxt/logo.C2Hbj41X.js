import"./entry.CoTUwW6Z.js";const s=""+globalThis.__publicAssetsURL("img/logo.jpeg");export{s as _};
