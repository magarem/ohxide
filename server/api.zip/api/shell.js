import shell from "shelljs"

export default defineEventHandler((event) => {

    const req = getQuery(event)
    const client = JSON.parse(req.client)
    console.log('req.client:', client.name);
    console.log('req.year:', req.year);
    console.log('req.month:', req.month);
    console.log('req.files:', req.files);

    async function merge_pdfs(pdfFiles, outputFile) {
        // await shell.exec("pwd")
        const { stdout, stderr } = await shell.exec(`deno run --allow-read --allow-write --allow-net --allow-run deno.ts ${client.id} ${req.year} ${req.month} '${client.empresa}' ${pdfFiles}`)
        console.log('stdout:', stdout)
        console.log('stderr:', stderr)
        return stdout
    }
         
    // const pdfFiles = req.files//['public/upload/reports/CRLV_QQQ2H08.pdf', 'public/upload/reports/Alice.pdf']
    const outputFile = 'new_merged.pdf'
    console.log("----", req.files.split(',').map(x=>'public/upload/reports/'+x).join(','));
    return merge_pdfs(req.files.split(',').map(x=>'public/upload/reports/'+x).join(','), outputFile)
     
})