import nodemailer from 'nodemailer';
import Database from 'better-sqlite3';

export default defineEventHandler(async (event) => {
  const db = new Database('database.db');
  let ret = []
  // db.pragma('journal_mode = WAL');
  let req = await readBody(event)

  const url = getRequestURL(event)
  
  console.log('url::>', url.origin);
  
  const clientsIds = req.clients.map(x=>`'${x}'`).join(',')
  console.log('clientsIds:', clientsIds);
  
  const getData = (sql) => {
      const selectData = db.prepare(sql).all()
      // const ret_ = selectData.run() 
      console.log('selectData:', selectData);
      
      return selectData
  }

    var transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'magawebtec@gmail.com',
            pass: 'gkvv trye yzrp bxmp'
        }
    });


    const clients = getData(`select * from clients where id in (${clientsIds})`)
    console.log(clients);
    console.log(clients);
    clients.forEach(x=>{
      let message = req.message
      message = message.replaceAll("[nome]", x.name)
      message = message.replaceAll("[empresa]", x.empresa)
      message = message.replaceAll("[email]", x.email)
      ret.push(`Email enviado para: ${x.email}`)
      const link = `<a href="${url.origin}/download?year=${req.year}&month=${req.month}&client=${x.id}">${req.linktext}</a>`
      var mailOptions = {
        from: 'magawebtec@gmail.com',
        to: x.email,
        subject: req.subject,
        html: `
          <img src="${url.origin}/img/logo.jpeg" style="width: 70px;"/><br/>
          ${message.replaceAll("\n", "<br/>")}
          <br/>
          ${link}
          `
      };
      
      console.log('mailOptions', mailOptions);
      
      transporter.sendMail(mailOptions, function(error, info){
        if (error) {
          console.log(error);
        } else {
          console.log('Email sent: ' + info.response);
          return 'Email eviado: ' + info.response
        }
      });


    })

    return ret

})