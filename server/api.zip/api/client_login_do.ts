import data from '../../public/demo/data/users.json'
let dataObj = null
function generateToken(n) {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var token = '';
    for(var i = 0; i < n; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
    return token;
}
export default defineEventHandler(async (event) => {
    // const query = getQuery(event)
    const body = await readBody(event)

    const username = body.username
    const password = body.password
    console.log('username:', username);
    console.log('password:', password);
    console.log('data:', data.title);
    dataObj = data.data.find(x=>x.username==username&&x.password==password)
    console.log('dataObj:', dataObj);

    if (JSON.stringify(dataObj)!=="") {
        dataObj.token = generateToken(360)
        return dataObj;
    }else{
        return null;
    }
})