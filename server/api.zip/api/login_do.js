import * as fs from "node:fs"
import {db} from "@/data/db_cmds"


// let dataObj = null

function generateToken(n) {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var token = '';
    for(var i = 0; i < n; i++) {
        token += chars[Math.floor(Math.random() * chars.length)];
    }
    return token;
}


export default defineEventHandler(async (event) => {
    // const query = getQuery(event)
    const body = await readBody(event)
    const type = body.type
    const username = body.username
    const password = body.password

    // db.get("select * from users").then(x=>{
    //     console.log('db---------->', x)
    // })

    const data = await db.get(`select * from ${type} where username like '${username}' and password like '${password}' `)
    console.log('db---------->', data)


    if (data.length>0){

        const userObj = {
            ...data[0],
            type: type,
            token: generateToken(360)
        }

        console.log('userObj:', userObj);
        return userObj;
    }else{
        return null;
    }
   
    // console.log('data:>>', data);
    // console.log('type:', type);
    // console.log('username:', username);
    // console.log('password:', password);
    // console.log('data:', data.data);

    // dataObj = data.data.find(x=>x.username==username&&x.password==password)
    // console.log('dataObj:', dataObj);

    // if (JSON.stringify(dataObj)!=="") {
    //     dataObj.token = generateToken(360)
    //     return dataObj;
    // }else{
    //     return null;
    // }
})