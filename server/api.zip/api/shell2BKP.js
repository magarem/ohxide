import shell from "shelljs"
import Database from 'better-sqlite3';
import download from 'download'
// Url of the image 
// const file = 'GFG.jpeg'; 
// Path at which image will get downloaded 
// const filePath = `${__dirname}/files`; 

// download(file,filePath) 
// .then(() => { 
// 	console.log('Download Completed'); 
// })

const db = new Database('/home/maga/dev/ohxide/database.db');
// db.pragma('journal_mode = WAL');

const getData = (sql) => {
    const selectData = db.prepare(sql).all()
    // const ret_ = selectData.run() 
    console.log('selectData:', selectData);
    
    return selectData
}

export default defineEventHandler((event) => {

    const req = getQuery(event)
    const client = req.client
    const year = req.year
    const month = req.month
    console.log('req.client:', client);
    console.log('req.year:', req.year);
    console.log('req.month:', req.month);
    const sql = `
        select 
            COUNT(reports.id), 
            clients.id,
            clients.empresa as empresa,
            reports.year, 
            reports.month, 
            GROUP_CONCAT(reports.name) as nome, 
            GROUP_CONCAT(reports.file) as files, 
            GROUP_CONCAT(products.name) as tags 
        from 
            reports, 
            products, 
            clients 
        where 
            reports.tag = products.id AND 
            instr(clients.tags, reports.tag) > 0 AND
            clients.id like '${client}' AND
            reports.year = ${year} AND
            reports.month = ${month}
        GROUP BY 
            reports.year, 
            reports.month 
        order by 
            year DESC, 
            month DESC 
        ` 
    const sqlReturn = getData(sql)
   
    // return sqlReturn[0].files.split(',').map(x=>'/upload/reports/'+x)
    async function merge_pdfs(clientID, empresa, year, month, files) {
        await shell.exec("pwd")
        const { stdout, stderr } = await shell.exec(`deno run --allow-read --allow-write --allow-net --allow-run deno.ts ${clientID} ${year} ${month} '${empresa}' ${files}`)
        console.log('stdout:', stdout)
        console.log('stderr:', stderr)
        return stdout
    }

    const file = merge_pdfs(client, sqlReturn[0].empresa, year, month, sqlReturn[0].files.split(',').map(x=>'public/upload/reports/'+x))
    return file
    // Url of the image 
    // const file = 'GFG.jpeg'; 
    // Path at which image will get downloaded 
    // const filePath = `/home/maga/dev/ohxide/public/upload/reports`; 
    
    // download(file, filePath) 
    // .then(() => { 
    //     console.log('Download Completed'); 
    // })

    // return sqlReturn 
    // const pdfFiles = req.files//['public/upload/reports/CRLV_QQQ2H08.pdf', 'public/upload/reports/Alice.pdf']
    // const outputFile = 'new_merged.pdf'
    // console.log("----", req.files.split(',').map(x=>'public/upload/reports/'+x).join(','));
    // return merge_pdfs(req.files.split(',').map(x=>'public/upload/reports/'+x).join(','), outputFile)
     
})