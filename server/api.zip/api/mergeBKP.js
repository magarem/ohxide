import PDFMerger from 'pdf-merger-js';
import { readFileAsync } from 'node:fs';
import { Buffer } from 'node:buffer';
import * as path from 'node:path'
import * as fs from 'node:fs'
// import path from 'path';
import {db} from "@/data/db_cmds" 
// import PDFWatermark from 'pdf-watermark';
import { degrees, PDFDocument, rgb, StandardFonts } from 'pdf-lib';

export default defineEventHandler(async (event) => {
    var merger = new PDFMerger();
    const req = getQuery(event)
    const client = JSON.parse(req.client)
    console.log('req.client:', client.name);
    console.log('req.year:', req.year);
    console.log('req.month:', req.month);
    console.log('req.files:', req.files);
    // const filePath = path.join(process.cwd(), 'public', 'upload', 'reports', 'pdf1.pdf')
    (async () => {
        // await merger.add("/home/maga/dev/ohxide/public/upload/reports/CRLV_QQQ2H08.pdf");  //merge all pages. parameter is the path to file and filename.
        // await merger.add("/home/maga/dev/ohxide/public/upload/reports/Leviata autor Thomas Hobbes.pdf");  //merge all pages. parameter is the path to file and filename.
        // await merger.add("/home/maga/dev/ohxide/public/upload/reports/Alice no País das Maravilhas autor Lewis Carroll.pdf");  //merge all pages. parameter is the path to file and filename.
        
        // req.files.split(',').forEach(async element => {
        //      console.log('x file:', "/home/maga/dev/ohxide/public/upload/reports/" + element);
        //      await merger.add("/home/maga/dev/ohxide/public/upload/reports/" + element);  //merge all pages. parameter is the path to file and filename.
        // });

        // await merger.add("/home/maga/dev/ohxide/public/upload/reports/pdf2.pdf");  //merge all pages. parameter is the path to file and filename.
        //   await merger.add('pdf2.pdf', 2); // merge only page 2
        //   await merger.add('pdf2.pdf', [1, 3]); // merge the pages 1 and 3
        //   await merger.add('pdf2.pdf', '4, 7, 8'); // merge the pages 4, 7 and 8
        //   await merger.add('pdf3.pdf', '3 to 5'); //merge pages 3 to 5 (3,4,5)
        //   await merger.add('pdf3.pdf', '3-5'); //merge pages 3 to 5 (3,4,5)

        // Set metadata
        // await merger.setMetadata({
        //     producer: "pdf-merger-js based script",
        //     author: "John Doe",
        //     creator: "John Doe",
        //     title: "My live as John Doe"
        // });

        // await merger.save("/home/maga/dev/ohxide/public/upload/reports/merged.pdf"); //save under given name and reset the internal document
    })();
    // await PDFWatermark({
    //     pdf_path: "/home/maga/dev/ohxide/public/upload/reports/merged.pdf", 
    //     // image_path: "./everest.png",
    //     text: "Gentech", 
    //     textOption:{
    //         size: 100,
    //         diagonally:true
    //     },
    //     output_dir: "/home/maga/dev/ohxide/public/upload/reports/merged2.pdf", // remove to override file
    //   });

    // const ret = await db.insert({
    //     table: "reports",
    //     data: {
    //         id: "d8811",
    //         year: "2024",
    //         month: 2,
    //         name: "merged pdf",
    //         file: "merged.pdf",
    //         tag: "merged"
    //     }
    // })
    // console.log(' ret merged insert:', ret);

    // console.log('clients222', clients);
    // Export the merged PDF as a nodejs Buffer
    // const mergedPdfBuffer = await merger.saveAsBuffer();
    // fs.writeSync('merged.pdf', mergedPdfBuffer);
   
   
    // console.log('read_file:', read('/home/maga/dev/ohxide/public/upload/reports/merged.pdf'));

    async function copyPages() {
        const url1 = 'http://localhost:3000/upload/reports/Leviata%20autor%20Thomas%20Hobbes.pdf'
        const url2 = 'http://localhost:3000/upload/reports/CRLV_QQQ2H08.pdf'
      
        const firstDonorPdfBytes = await fetch(url1).then(res => res.arrayBuffer())
        const secondDonorPdfBytes = await fetch(url2).then(res => res.arrayBuffer())
      
        const firstDonorPdfDoc = await PDFDocument.load(firstDonorPdfBytes)
        const secondDonorPdfDoc = await PDFDocument.load(secondDonorPdfBytes)
      
        const pdfDoc = await PDFDocument.create();
      
        const [firstDonorPage] = await pdfDoc.copyPages(firstDonorPdfDoc, [0, 1])
        const [secondDonorPage] = await pdfDoc.copyPages(secondDonorPdfDoc, [0])
      
        pdfDoc.addPage(firstDonorPage)
        pdfDoc.insertPage(0, secondDonorPage)
      
        const pdfBytes = await pdfDoc.save()
        fs.writeFileSync("/home/maga/dev/ohxide/public/upload/reports/merged2.pdf", pdfBytes);
       
      }
      copyPages()

    async function modifyPdf() {
        // const pdfDoc1 = await PDFDocument.create();
        // for (const file of req.files.split(',')) {
        //     const indices = [];
        //     for (let i = 0; i < file.getPageCount(); i++)
        //         indices.push(i);
        //     const pages = await pdfDoc1.copyPages(file, indices);

        // for (const page of pages) {
        //         pdfDoc1.addPage(page);
        //     }
        // }
        // const pdfBytes1 = await pdfDoc.save()
        // fs.writeFileSync("/home/maga/dev/ohxide/public/upload/reports/merged.pdf", pdfBytes1);
     
        const url = 'http://localhost:3000/upload/reports/merged.pdf'
        const existingPdfBytes = await fetch(url).then(res => res.arrayBuffer())
        // const existingPdfBytes = read('/home/maga/dev/ohxide/public/upload/reports/merged.pdf')
      
        const pdfDoc = await PDFDocument.load(existingPdfBytes)
        const helveticaFont = await pdfDoc.embedFont(StandardFonts.Helvetica)
      
        const pages = pdfDoc.getPages()
        const firstPage = pages[0]
        const { width, height } = firstPage.getSize()
        firstPage.drawText(client.name, {
          x: 5,
          y: height / 2 + 300,
          size: 50,
          font: helveticaFont,
          color: rgb(0.95, 0.1, 0.1),
          rotate: degrees(-45),
        })
      
        const pdfBytes = await pdfDoc.save()
        fs.writeFileSync("/home/maga/dev/ohxide/public/upload/reports/teste.pdf", pdfBytes);
        console.log(pdfBytes);
    }

    // modifyPdf()
})